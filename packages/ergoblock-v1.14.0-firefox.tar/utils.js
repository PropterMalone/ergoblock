// src/utils.ts
var LOG_LEVEL_PRIORITY = {
  debug: 0,
  info: 1,
  warn: 2,
  error: 3
};
var currentLogLevel = "info";
function setLogLevel(level) {
  currentLogLevel = level;
}
function getLogLevel() {
  return currentLogLevel;
}
var logger = {
  debug: (message, ...args) => {
    if (LOG_LEVEL_PRIORITY[currentLogLevel] <= LOG_LEVEL_PRIORITY.debug) {
      console.debug(`[ErgoBlock] ${message}`, ...args);
    }
  },
  info: (message, ...args) => {
    if (LOG_LEVEL_PRIORITY[currentLogLevel] <= LOG_LEVEL_PRIORITY.info) {
      console.log(`[ErgoBlock] ${message}`, ...args);
    }
  },
  warn: (message, ...args) => {
    if (LOG_LEVEL_PRIORITY[currentLogLevel] <= LOG_LEVEL_PRIORITY.warn) {
      console.warn(`[ErgoBlock] ${message}`, ...args);
    }
  },
  error: (message, ...args) => {
    if (LOG_LEVEL_PRIORITY[currentLogLevel] <= LOG_LEVEL_PRIORITY.error) {
      console.error(`[ErgoBlock] ${message}`, ...args);
    }
  }
};
var RateLimiter = class {
  constructor(options = {}) {
    this.lastActionTime = 0;
    this.actionCount = 0;
    this.windowMs = options.windowMs ?? 1e4;
    this.maxActions = options.maxActions ?? 5;
    this.cooldownMs = options.cooldownMs ?? 2e3;
  }
  /**
   * Check if an action is allowed
   * @returns true if allowed, false if rate limited
   */
  canPerformAction() {
    const now = Date.now();
    if (now - this.lastActionTime > this.windowMs) {
      this.actionCount = 0;
    }
    if (now - this.lastActionTime < this.cooldownMs) {
      return false;
    }
    if (this.actionCount >= this.maxActions) {
      return false;
    }
    return true;
  }
  /**
   * Record an action
   */
  recordAction() {
    const now = Date.now();
    if (now - this.lastActionTime > this.windowMs) {
      this.actionCount = 0;
    }
    this.lastActionTime = now;
    this.actionCount++;
  }
  /**
   * Get time until next action is allowed (in ms)
   */
  getWaitTime() {
    const now = Date.now();
    const cooldownRemaining = Math.max(0, this.cooldownMs - (now - this.lastActionTime));
    if (this.actionCount >= this.maxActions) {
      const windowRemaining = Math.max(0, this.windowMs - (now - this.lastActionTime));
      return Math.max(cooldownRemaining, windowRemaining);
    }
    return cooldownRemaining;
  }
};
var actionRateLimiter = new RateLimiter({
  windowMs: 1e4,
  // 10 seconds
  maxActions: 5,
  // Max 5 blocks/mutes per 10 seconds
  cooldownMs: 1e3
  // 1 second minimum between actions
});
var CircuitBreaker = class {
  constructor(options = {}) {
    this.state = "closed";
    this.failures = 0;
    this.lastFailureTime = 0;
    this.successesSinceHalfOpen = 0;
    this.failureThreshold = options.failureThreshold ?? 5;
    this.resetTimeoutMs = options.resetTimeoutMs ?? 6e4;
    this.halfOpenSuccessThreshold = options.halfOpenSuccessThreshold ?? 2;
  }
  /**
   * Get current circuit state
   */
  getState() {
    this.updateState();
    return this.state;
  }
  /**
   * Check if circuit allows requests
   */
  isAllowed() {
    this.updateState();
    return this.state !== "open";
  }
  /**
   * Record a successful operation
   */
  recordSuccess() {
    this.updateState();
    if (this.state === "half-open") {
      this.successesSinceHalfOpen++;
      if (this.successesSinceHalfOpen >= this.halfOpenSuccessThreshold) {
        this.reset();
      }
    } else if (this.state === "closed") {
      this.failures = Math.max(0, this.failures - 1);
    }
  }
  /**
   * Record a failed operation
   */
  recordFailure() {
    this.updateState();
    if (this.state === "half-open") {
      this.trip();
    } else if (this.state === "closed") {
      this.failures++;
      this.lastFailureTime = Date.now();
      if (this.failures >= this.failureThreshold) {
        this.trip();
      }
    }
  }
  /**
   * Manually reset the circuit
   */
  reset() {
    this.state = "closed";
    this.failures = 0;
    this.successesSinceHalfOpen = 0;
    logger.info("Circuit breaker reset to closed");
  }
  trip() {
    this.state = "open";
    this.lastFailureTime = Date.now();
    logger.warn(`Circuit breaker opened after ${this.failures} failures`);
  }
  updateState() {
    if (this.state === "open") {
      const now = Date.now();
      if (now - this.lastFailureTime >= this.resetTimeoutMs) {
        this.state = "half-open";
        this.successesSinceHalfOpen = 0;
        logger.info("Circuit breaker entering half-open state");
      }
    }
  }
};
var apiCircuitBreaker = new CircuitBreaker({
  failureThreshold: 5,
  resetTimeoutMs: 6e4,
  // 1 minute
  halfOpenSuccessThreshold: 2
});
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
function isValidDid(did) {
  if (!did || typeof did !== "string") return false;
  return /^did:(plc|web):[a-zA-Z0-9._:%-]+$/.test(did);
}
function isValidDuration(durationMs) {
  if (typeof durationMs !== "number") return false;
  if (!Number.isFinite(durationMs)) return false;
  if (durationMs <= 0) return false;
  const ONE_YEAR_MS = 365 * 24 * 60 * 60 * 1e3;
  if (durationMs > ONE_YEAR_MS) return false;
  return true;
}
function isValidHandle(handle) {
  if (!handle || typeof handle !== "string") return false;
  if (handle.length > 253) return false;
  return /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?)+$/.test(
    handle
  );
}
function isValidAtUri(uri) {
  if (!uri || typeof uri !== "string") return false;
  return /^at:\/\/did:(plc|web):[a-zA-Z0-9._:%-]+\/[a-zA-Z0-9.]+\/[a-zA-Z0-9._~-]+$/.test(uri);
}
function normalizeAtUri(uri) {
  if (!uri || typeof uri !== "string") return uri;
  uri = uri.replace(/\/+$/, "");
  const match = uri.match(/^at:\/\/(did:[a-z]+:[^/]+)(\/.*)?$/i);
  if (match) {
    const did = match[1].toLowerCase();
    const path = match[2] || "";
    return `at://${did}${path}`;
  }
  return uri;
}
var ALLOWED_PDS_PATTERNS = [
  /^https:\/\/[a-zA-Z0-9-]+\.bsky\.network$/,
  /^https:\/\/bsky\.social$/,
  /^https:\/\/[a-zA-Z0-9-]+\.bsky\.social$/,
  /^https:\/\/[a-zA-Z0-9-]+\.host\.bsky\.network$/,
  // Self-hosted PDS on standard ports
  /^https:\/\/[a-zA-Z0-9][a-zA-Z0-9.-]*\.[a-zA-Z]{2,}(:\d+)?$/
];
function validatePdsUrl(url) {
  if (!url || typeof url !== "string") return null;
  let normalized = url.trim();
  normalized = normalized.replace(/\/+$/, "");
  if (!normalized.startsWith("http://") && !normalized.startsWith("https://")) {
    normalized = "https://" + normalized;
  }
  if (normalized.startsWith("http://")) {
    if (!normalized.includes("localhost") && !normalized.includes("127.0.0.1")) {
      logger.warn("Rejecting non-HTTPS PDS URL:", normalized);
      return null;
    }
  }
  let parsed;
  try {
    parsed = new URL(normalized);
  } catch {
    logger.warn("Invalid PDS URL format:", normalized);
    return null;
  }
  if (parsed.pathname !== "/" && parsed.pathname !== "") {
    logger.warn("PDS URL should not have a path:", normalized);
    return null;
  }
  if (parsed.search || parsed.hash) {
    logger.warn("PDS URL should not have query or hash:", normalized);
    return null;
  }
  const isAllowed = ALLOWED_PDS_PATTERNS.some((pattern) => pattern.test(normalized));
  const isLocalhost = parsed.hostname === "localhost" || parsed.hostname === "127.0.0.1" || parsed.hostname.endsWith(".localhost");
  if (!isAllowed && !isLocalhost) {
    logger.warn("PDS URL not in known patterns, allowing with caution:", normalized);
  }
  return `${parsed.protocol}//${parsed.host}`;
}
function isValidTimestamp(timestamp) {
  if (typeof timestamp !== "number") return false;
  if (!Number.isFinite(timestamp)) return false;
  if (timestamp <= 0) return false;
  const MIN_TS = (/* @__PURE__ */ new Date("2020-01-01")).getTime();
  const MAX_TS = (/* @__PURE__ */ new Date("2100-01-01")).getTime();
  return timestamp >= MIN_TS && timestamp <= MAX_TS;
}
function generateId(prefix) {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
}
function isRetryableError(error) {
  const message = error.message.toLowerCase();
  if (message.includes("network") || message.includes("fetch") || message.includes("timeout") || message.includes("econnreset") || message.includes("enotfound")) {
    return true;
  }
  if (message.includes("429") || message.includes("rate limit")) {
    return true;
  }
  if (message.includes("500") || message.includes("502") || message.includes("503") || message.includes("504")) {
    return true;
  }
  if (message.includes("401") || message.includes("auth error")) {
    return false;
  }
  if (message.includes("expiredtoken") || message.includes("token has expired") || message.includes("expired token")) {
    return false;
  }
  if (message.includes("400") || message.includes("403") || message.includes("404")) {
    return false;
  }
  return false;
}
async function withRetry(fn, options = {}) {
  if (typeof fn !== "function") {
    throw new TypeError("withRetry: first argument must be a function");
  }
  const {
    maxRetries = 3,
    initialDelayMs = 1e3,
    maxDelayMs = 3e4,
    backoffMultiplier = 2,
    isRetryable = isRetryableError,
    onRetry
  } = options;
  if (maxRetries < 0 || !Number.isFinite(maxRetries)) {
    throw new TypeError("withRetry: maxRetries must be a non-negative finite number");
  }
  let lastError;
  let delay = initialDelayMs;
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const result = fn();
      if (result && typeof result.then === "function") {
        return await result;
      }
      return result;
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));
      if (attempt === maxRetries || !isRetryable(lastError)) {
        throw lastError;
      }
      const jitter = delay * 0.1 * (Math.random() * 2 - 1);
      const actualDelay = Math.min(delay + jitter, maxDelayMs);
      onRetry?.(attempt + 1, lastError, actualDelay);
      logger.info(
        `Retry ${attempt + 1}/${maxRetries} after ${Math.round(actualDelay)}ms: ${lastError.message}`
      );
      await sleep(actualDelay);
      delay = Math.min(delay * backoffMultiplier, maxDelayMs);
    }
  }
  throw lastError || new Error("Retry failed");
}
var Mutex = class {
  constructor() {
    this._locked = false;
    this._queue = [];
  }
  /**
   * Check if the mutex is currently locked (for diagnostics only)
   */
  get isLocked() {
    return this._locked;
  }
  /**
   * Acquire the mutex lock. Returns a release function.
   * If the mutex is already locked, waits until it becomes available.
   */
  async acquire() {
    return new Promise((resolve) => {
      const tryAcquire = () => {
        if (!this._locked) {
          this._locked = true;
          resolve(() => this.release());
        } else {
          this._queue.push(tryAcquire);
        }
      };
      tryAcquire();
    });
  }
  /**
   * Release the mutex lock, allowing the next waiter to proceed.
   */
  release() {
    if (this._queue.length > 0) {
      const next = this._queue.shift();
      if (next) {
        queueMicrotask(next);
      }
    } else {
      this._locked = false;
    }
  }
  /**
   * Execute a function with the mutex held.
   * Automatically releases the mutex when done (even on error).
   */
  async runExclusive(fn) {
    const release = await this.acquire();
    try {
      return await fn();
    } finally {
      release();
    }
  }
};
var LRUCache = class {
  /**
   * @param maxSize - Maximum number of entries (default: 1000)
   * @param ttlMs - Time-to-live in ms, null for no expiry (default: null)
   */
  constructor(maxSize = 1e3, ttlMs = null) {
    this.cache = /* @__PURE__ */ new Map();
    this.maxSize = maxSize;
    this.ttlMs = ttlMs;
  }
  /**
   * Get a value from the cache.
   * Returns undefined if not found or expired.
   */
  get(key) {
    const entry = this.cache.get(key);
    if (!entry) {
      return void 0;
    }
    if (this.ttlMs !== null && Date.now() - entry.timestamp > this.ttlMs) {
      this.cache.delete(key);
      return void 0;
    }
    this.cache.delete(key);
    this.cache.set(key, entry);
    return entry.value;
  }
  /**
   * Set a value in the cache.
   * Evicts oldest entry if at capacity.
   */
  set(key, value) {
    this.cache.delete(key);
    if (this.cache.size >= this.maxSize) {
      const oldestKey = this.cache.keys().next().value;
      if (oldestKey !== void 0) {
        this.cache.delete(oldestKey);
      }
    }
    this.cache.set(key, { value, timestamp: Date.now() });
  }
  /**
   * Check if a key exists (and is not expired).
   */
  has(key) {
    return this.get(key) !== void 0;
  }
  /**
   * Delete a key from the cache.
   */
  delete(key) {
    return this.cache.delete(key);
  }
  /**
   * Clear all entries from the cache.
   */
  clear() {
    this.cache.clear();
  }
  /**
   * Get current cache size.
   */
  get size() {
    return this.cache.size;
  }
  /**
   * Remove all expired entries (useful for periodic cleanup).
   */
  prune() {
    if (this.ttlMs === null) {
      return 0;
    }
    const now = Date.now();
    let pruned = 0;
    for (const [key, entry] of this.cache.entries()) {
      if (now - entry.timestamp > this.ttlMs) {
        this.cache.delete(key);
        pruned++;
      }
    }
    return pruned;
  }
};
function isValidRkey(rkey) {
  if (!rkey || typeof rkey !== "string") return false;
  if (rkey.length > 512) return false;
  return /^[a-zA-Z0-9._~-]+$/.test(rkey);
}
function extractRkeyFromUri(uri) {
  if (!uri || typeof uri !== "string") return null;
  const match = uri.match(/^at:\/\/did:[^/]+\/[^/]+\/([^/?#]+)$/);
  if (!match) return null;
  const rkey = match[1];
  if (!isValidRkey(rkey)) {
    logger.warn("Invalid rkey extracted from URI:", uri);
    return null;
  }
  return rkey;
}
function textContainsMention(text, handle) {
  if (!text || !handle || typeof text !== "string" || typeof handle !== "string") {
    return false;
  }
  const normalizedText = text.toLowerCase();
  const normalizedHandle = handle.toLowerCase();
  const escapedHandle = normalizedHandle.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const mentionRegex = new RegExp(`@${escapedHandle}(?=[\\s.,!?;:'"\\)\\]}>]|$)`, "i");
  return mentionRegex.test(normalizedText);
}
var RequestCoalescer = class {
  constructor() {
    this.pending = /* @__PURE__ */ new Map();
  }
  /**
   * Execute a function, deduplicating concurrent calls with the same key.
   * @param key - Unique key for deduplication
   * @param fn - Async function to execute
   * @returns Result of the function
   */
  async execute(key, fn) {
    const existing = this.pending.get(key);
    if (existing) {
      return existing;
    }
    const promise = fn().finally(() => {
      this.pending.delete(key);
    });
    this.pending.set(key, promise);
    return promise;
  }
  /**
   * Check if a request is currently pending for a key.
   */
  isPending(key) {
    return this.pending.has(key);
  }
  /**
   * Get count of pending requests.
   */
  get pendingCount() {
    return this.pending.size;
  }
};
export {
  CircuitBreaker,
  LRUCache,
  Mutex,
  RateLimiter,
  RequestCoalescer,
  actionRateLimiter,
  apiCircuitBreaker,
  extractRkeyFromUri,
  generateId,
  getLogLevel,
  isRetryableError,
  isValidAtUri,
  isValidDid,
  isValidDuration,
  isValidHandle,
  isValidRkey,
  isValidTimestamp,
  logger,
  normalizeAtUri,
  setLogLevel,
  sleep,
  textContainsMention,
  validatePdsUrl,
  withRetry
};
