// src/clearskyCache.ts
var DB_NAME = "ergoblock-clearsky-cache";
var DB_VERSION = 1;
var STORES = {
  BLOCKED_BY: "blockedBy",
  QUEUE: "fetchQueue"
};
var dbPromise = null;
function openDatabase() {
  if (dbPromise) {
    return dbPromise;
  }
  dbPromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onerror = () => {
      console.error("[ClearskyCache] Failed to open database:", request.error);
      dbPromise = null;
      reject(request.error);
    };
    request.onsuccess = () => {
      resolve(request.result);
    };
    request.onupgradeneeded = (event) => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains(STORES.BLOCKED_BY)) {
        db.createObjectStore(STORES.BLOCKED_BY, { keyPath: "targetDid" });
      }
      if (!db.objectStoreNames.contains(STORES.QUEUE)) {
        const queueStore = db.createObjectStore(STORES.QUEUE, { keyPath: "targetDid" });
        queueStore.createIndex("status", "status", { unique: false });
        queueStore.createIndex("priority", "priority", { unique: false });
      }
    };
  });
  return dbPromise;
}
async function getBlockedByCache(targetDid) {
  try {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.BLOCKED_BY, "readonly");
      const request = tx.objectStore(STORES.BLOCKED_BY).get(targetDid);
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error("[ClearskyCache] Failed to get blocked-by cache:", error);
    return null;
  }
}
async function saveBlockedByCache(data) {
  try {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.BLOCKED_BY, "readwrite");
      const request = tx.objectStore(STORES.BLOCKED_BY).put(data);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error("[ClearskyCache] Failed to save blocked-by cache:", error);
    throw error;
  }
}
async function invalidateBlockedByCache(targetDid) {
  try {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.BLOCKED_BY, "readwrite");
      const request = tx.objectStore(STORES.BLOCKED_BY).delete(targetDid);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error("[ClearskyCache] Failed to invalidate cache:", error);
    throw error;
  }
}
async function getAllBlockedByCache() {
  try {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.BLOCKED_BY, "readonly");
      const request = tx.objectStore(STORES.BLOCKED_BY).getAll();
      request.onsuccess = () => resolve(request.result || []);
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error("[ClearskyCache] Failed to get all blocked-by cache:", error);
    return [];
  }
}
async function clearAllBlockedByCache() {
  try {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.BLOCKED_BY, "readwrite");
      const request = tx.objectStore(STORES.BLOCKED_BY).clear();
      request.onsuccess = () => {
        console.log("[ClearskyCache] Cleared all blocked-by cache");
        resolve();
      };
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error("[ClearskyCache] Failed to clear blocked-by cache:", error);
    throw error;
  }
}
async function queueForFetch(targetDid, priority = 10) {
  try {
    const db = await openDatabase();
    const existing = await getQueueEntry(targetDid);
    if (existing && (existing.status === "pending" || existing.status === "in_progress")) {
      return;
    }
    const entry = {
      targetDid,
      priority,
      queuedAt: Date.now(),
      status: "pending",
      retryCount: existing?.retryCount || 0
    };
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.QUEUE, "readwrite");
      const request = tx.objectStore(STORES.QUEUE).put(entry);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error("[ClearskyCache] Failed to queue for fetch:", error);
    throw error;
  }
}
async function getQueueEntry(targetDid) {
  try {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.QUEUE, "readonly");
      const request = tx.objectStore(STORES.QUEUE).get(targetDid);
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error("[ClearskyCache] Failed to get queue entry:", error);
    return null;
  }
}
async function getPendingQueue() {
  try {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.QUEUE, "readonly");
      const store = tx.objectStore(STORES.QUEUE);
      const index = store.index("status");
      const request = index.getAll("pending");
      request.onsuccess = () => {
        const entries = request.result || [];
        entries.sort((a, b) => {
          if (a.priority !== b.priority) return a.priority - b.priority;
          return a.queuedAt - b.queuedAt;
        });
        resolve(entries);
      };
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error("[ClearskyCache] Failed to get pending queue:", error);
    return [];
  }
}
async function updateQueueStatus(targetDid, status, error) {
  try {
    const db = await openDatabase();
    const existing = await getQueueEntry(targetDid);
    if (!existing) return;
    const updated = {
      ...existing,
      status,
      lastError: error,
      retryCount: status === "failed" ? existing.retryCount + 1 : existing.retryCount
    };
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.QUEUE, "readwrite");
      const request = tx.objectStore(STORES.QUEUE).put(updated);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch (error2) {
    console.error("[ClearskyCache] Failed to update queue status:", error2);
    throw error2;
  }
}
async function removeFromQueue(targetDid) {
  try {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.QUEUE, "readwrite");
      const request = tx.objectStore(STORES.QUEUE).delete(targetDid);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error("[ClearskyCache] Failed to remove from queue:", error);
    throw error;
  }
}
async function clearCompletedQueue() {
  try {
    const db = await openDatabase();
    const tx = db.transaction(STORES.QUEUE, "readwrite");
    const store = tx.objectStore(STORES.QUEUE);
    return new Promise((resolve, reject) => {
      const request = store.openCursor();
      request.onsuccess = () => {
        const cursor = request.result;
        if (cursor) {
          const entry = cursor.value;
          if (entry.status === "completed" || entry.status === "failed") {
            cursor.delete();
          }
          cursor.continue();
        } else {
          resolve();
        }
      };
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error("[ClearskyCache] Failed to clear completed queue:", error);
    throw error;
  }
}
async function clearClearskyCache() {
  try {
    const db = await openDatabase();
    const tx = db.transaction([STORES.BLOCKED_BY, STORES.QUEUE], "readwrite");
    await Promise.all([
      new Promise((resolve, reject) => {
        const request = tx.objectStore(STORES.BLOCKED_BY).clear();
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      }),
      new Promise((resolve, reject) => {
        const request = tx.objectStore(STORES.QUEUE).clear();
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      })
    ]);
    console.log("[ClearskyCache] Cleared all cache");
  } catch (error) {
    console.error("[ClearskyCache] Failed to clear cache:", error);
    throw error;
  }
}
async function getClearskyStats() {
  try {
    const db = await openDatabase();
    const tx = db.transaction([STORES.BLOCKED_BY, STORES.QUEUE], "readonly");
    const [blockedByEntries, queueEntries] = await Promise.all([
      new Promise((resolve, reject) => {
        const request = tx.objectStore(STORES.BLOCKED_BY).getAll();
        request.onsuccess = () => resolve(request.result || []);
        request.onerror = () => reject(request.error);
      }),
      new Promise((resolve, reject) => {
        const request = tx.objectStore(STORES.QUEUE).getAll();
        request.onsuccess = () => resolve(request.result || []);
        request.onerror = () => reject(request.error);
      })
    ]);
    return {
      cachedTargets: blockedByEntries.length,
      totalBlockers: blockedByEntries.reduce((sum, e) => sum + e.blockerDids.length, 0),
      queuedPending: queueEntries.filter((e) => e.status === "pending").length,
      queuedFailed: queueEntries.filter((e) => e.status === "failed").length
    };
  } catch (error) {
    console.error("[ClearskyCache] Failed to get stats:", error);
    return { cachedTargets: 0, totalBlockers: 0, queuedPending: 0, queuedFailed: 0 };
  }
}
export {
  clearAllBlockedByCache,
  clearClearskyCache,
  clearCompletedQueue,
  getAllBlockedByCache,
  getBlockedByCache,
  getClearskyStats,
  getPendingQueue,
  getQueueEntry,
  invalidateBlockedByCache,
  queueForFetch,
  removeFromQueue,
  saveBlockedByCache,
  updateQueueStatus
};
