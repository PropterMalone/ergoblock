// src/types.ts
var DEFAULT_OPTIONS = {
  defaultDuration: 864e5,
  // 24 hours
  quickBlockDuration: 36e5,
  // 1 hour
  notificationsEnabled: true,
  notificationSound: false,
  checkInterval: 1,
  showBadgeCount: true,
  theme: "auto",
  // Screenshot defaults
  screenshotEnabled: true,
  screenshotQuality: 0.7,
  screenshotRetentionDays: 30
};

// src/storage.ts
var STORAGE_KEYS = {
  TEMP_BLOCKS: "tempBlocks",
  TEMP_MUTES: "tempMutes",
  OPTIONS: "extensionOptions",
  ACTION_HISTORY: "actionHistory",
  LAST_TAB: "lastActiveTab",
  SCREENSHOTS: "screenshots"
};
var DEFAULT_DURATION_MS = 24 * 60 * 60 * 1e3;
async function getOptions() {
  const result = await chrome.storage.local.get(STORAGE_KEYS.OPTIONS);
  return result[STORAGE_KEYS.OPTIONS] || DEFAULT_OPTIONS;
}
var MAX_SCREENSHOT_STORAGE_MB = 5;
var MAX_SCREENSHOT_STORAGE_BYTES = MAX_SCREENSHOT_STORAGE_MB * 1024 * 1024;
async function getScreenshots() {
  const result = await chrome.storage.local.get(STORAGE_KEYS.SCREENSHOTS);
  return result[STORAGE_KEYS.SCREENSHOTS] || [];
}
async function addScreenshot(screenshot) {
  const screenshots = await getScreenshots();
  screenshots.unshift(screenshot);
  let totalSize = 0;
  const trimmed = [];
  for (const s of screenshots) {
    const sizeEstimate = s.imageData.length * 0.75;
    if (totalSize + sizeEstimate <= MAX_SCREENSHOT_STORAGE_BYTES) {
      trimmed.push(s);
      totalSize += sizeEstimate;
    }
  }
  await chrome.storage.local.set({ [STORAGE_KEYS.SCREENSHOTS]: trimmed });
}

// src/screenshot.ts
var POST_SELECTORS = [
  '[data-testid*="feedItem"]',
  '[data-testid*="postThreadItem"]',
  "article",
  '[data-testid*="post"]'
];
function findPostContainer(element) {
  if (!element) return null;
  for (const selector of POST_SELECTORS) {
    const container = element.closest(selector);
    if (container) return container;
  }
  return null;
}
function extractPostText(postContainer) {
  const textSelectors = [
    '[data-testid*="postText"]',
    '[data-testid="postContent"]',
    ".post-text",
    "p"
  ];
  for (const selector of textSelectors) {
    const el = postContainer.querySelector(selector);
    if (el?.textContent?.trim()) {
      return el.textContent.trim().slice(0, 500);
    }
  }
  return void 0;
}
function extractPostUrl(postContainer) {
  const postLink = postContainer.querySelector('a[href*="/post/"]');
  return postLink?.href;
}
function generateScreenshotId() {
  return `ss_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
}
async function requestScreenshotFromBackground() {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage({ type: "CAPTURE_SCREENSHOT" }, (response) => {
      if (chrome.runtime.lastError) {
        console.warn("[ErgoBlock] Screenshot request failed:", chrome.runtime.lastError);
        resolve(null);
        return;
      }
      if (response?.success && response.imageData) {
        resolve(response.imageData);
      } else {
        console.warn("[ErgoBlock] Screenshot capture failed:", response?.error);
        resolve(null);
      }
    });
  });
}
async function capturePostScreenshot(postContainer, handle, did, actionType, permanent, preCapturedImageData) {
  const options = await getOptions();
  if (!options.screenshotEnabled) {
    console.log("[ErgoBlock] Screenshot capture disabled");
    return null;
  }
  try {
    let imageData = null;
    if (preCapturedImageData) {
      console.log("[ErgoBlock] Using pre-captured screenshot");
      imageData = preCapturedImageData;
    } else {
      console.log("[ErgoBlock] Requesting screenshot capture (fallback)...");
      imageData = await requestScreenshotFromBackground();
    }
    if (!imageData) {
      console.warn("[ErgoBlock] No screenshot data received");
      return null;
    }
    const postText = extractPostText(postContainer);
    const postUrl = extractPostUrl(postContainer);
    const screenshot = {
      id: generateScreenshotId(),
      imageData,
      handle,
      did,
      actionType,
      permanent,
      timestamp: Date.now(),
      postText,
      postUrl
    };
    await addScreenshot(screenshot);
    console.log("[ErgoBlock] Screenshot captured and stored:", screenshot.id);
    return screenshot;
  } catch (error) {
    console.error("[ErgoBlock] Screenshot capture failed:", error);
    return null;
  }
}
export {
  capturePostScreenshot,
  findPostContainer
};
