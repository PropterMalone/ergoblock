// node_modules/@atcute/uint8array/dist/index.js
var textEncoder = new TextEncoder();
var textDecoder = new TextDecoder();
var subtle = crypto.subtle;
var alloc = (size) => {
  return new Uint8Array(size);
};
var allocUnsafe = alloc;
var _fromCharCode = String.fromCharCode;
var _shortString = (from, p, length) => {
  if (length < 4) {
    if (length < 2) {
      if (length === 0)
        return "";
      const a3 = from[p];
      if (a3 & 128)
        return null;
      return _fromCharCode(a3);
    }
    const a2 = from[p];
    const b2 = from[p + 1];
    if ((a2 | b2) & 128)
      return null;
    if (length === 2)
      return _fromCharCode(a2, b2);
    const c2 = from[p + 2];
    if (c2 & 128)
      return null;
    return _fromCharCode(a2, b2, c2);
  }
  const a = from[p];
  const b = from[p + 1];
  const c = from[p + 2];
  const d = from[p + 3];
  if ((a | b | c | d) & 128)
    return null;
  if (length < 8) {
    if (length === 4)
      return _fromCharCode(a, b, c, d);
    const e2 = from[p + 4];
    if (e2 & 128)
      return null;
    if (length === 5)
      return _fromCharCode(a, b, c, d, e2);
    const f2 = from[p + 5];
    if (f2 & 128)
      return null;
    if (length === 6)
      return _fromCharCode(a, b, c, d, e2, f2);
    const g2 = from[p + 6];
    if (g2 & 128)
      return null;
    return _fromCharCode(a, b, c, d, e2, f2, g2);
  }
  const e = from[p + 4];
  const f = from[p + 5];
  const g = from[p + 6];
  const h = from[p + 7];
  if ((e | f | g | h) & 128)
    return null;
  if (length < 12) {
    if (length === 8)
      return _fromCharCode(a, b, c, d, e, f, g, h);
    const i2 = from[p + 8];
    if (i2 & 128)
      return null;
    if (length === 9)
      return _fromCharCode(a, b, c, d, e, f, g, h, i2);
    const j2 = from[p + 9];
    if (j2 & 128)
      return null;
    if (length === 10)
      return _fromCharCode(a, b, c, d, e, f, g, h, i2, j2);
    const k2 = from[p + 10];
    if (k2 & 128)
      return null;
    return _fromCharCode(a, b, c, d, e, f, g, h, i2, j2, k2);
  }
  const i = from[p + 8];
  const j = from[p + 9];
  const k = from[p + 10];
  const l = from[p + 11];
  if ((i | j | k | l) & 128)
    return null;
  if (length === 12)
    return _fromCharCode(a, b, c, d, e, f, g, h, i, j, k, l);
  const m = from[p + 12];
  if (m & 128)
    return null;
  if (length === 13)
    return _fromCharCode(a, b, c, d, e, f, g, h, i, j, k, l, m);
  const n = from[p + 13];
  if (n & 128)
    return null;
  if (length === 14)
    return _fromCharCode(a, b, c, d, e, f, g, h, i, j, k, l, m, n);
  const o = from[p + 14];
  if (o & 128)
    return null;
  return _fromCharCode(a, b, c, d, e, f, g, h, i, j, k, l, m, n, o);
};
var decodeUtf8From = (from, offset = 0, length = from.length) => {
  if (length <= 15) {
    const result = _shortString(from, offset, length);
    if (result !== null)
      return result;
  }
  return textDecoder.decode(from.subarray(offset, offset + length));
};

// node_modules/@atcute/multibase/dist/utils.js
var createRfc4648Encode = (alphabet, bitsPerChar, pad) => {
  return (bytes) => {
    const mask = (1 << bitsPerChar) - 1;
    let str = "";
    let bits = 0;
    let buffer = 0;
    for (let i = 0; i < bytes.length; ++i) {
      buffer = buffer << 8 | bytes[i];
      bits += 8;
      while (bits > bitsPerChar) {
        bits -= bitsPerChar;
        str += alphabet[mask & buffer >> bits];
      }
    }
    if (bits !== 0) {
      str += alphabet[mask & buffer << bitsPerChar - bits];
    }
    if (pad) {
      while ((str.length * bitsPerChar & 7) !== 0) {
        str += "=";
      }
    }
    return str;
  };
};
var createRfc4648Decode = (alphabet, bitsPerChar, pad) => {
  const codes = {};
  for (let i = 0; i < alphabet.length; ++i) {
    codes[alphabet[i]] = i;
  }
  return (str) => {
    let end = str.length;
    while (pad && str[end - 1] === "=") {
      --end;
    }
    const bytes = allocUnsafe(end * bitsPerChar / 8 | 0);
    let bits = 0;
    let buffer = 0;
    let written = 0;
    for (let i = 0; i < end; ++i) {
      const value = codes[str[i]];
      if (value === void 0) {
        throw new SyntaxError(`invalid base string`);
      }
      buffer = buffer << bitsPerChar | value;
      bits += bitsPerChar;
      if (bits >= 8) {
        bits -= 8;
        bytes[written++] = 255 & buffer >> bits;
      }
    }
    if (bits >= bitsPerChar || (255 & buffer << 8 - bits) !== 0) {
      throw new SyntaxError("unexpected end of data");
    }
    return bytes;
  };
};

// node_modules/@atcute/multibase/dist/bases/base64-web-native.js
var fromBase64 = (str) => {
  return Uint8Array.fromBase64(str, { alphabet: "base64", lastChunkHandling: "loose" });
};
var toBase64 = (bytes) => {
  return bytes.toBase64({ alphabet: "base64", omitPadding: true });
};

// node_modules/@atcute/multibase/dist/bases/base64-web-polyfill.js
var BASE64_CHARSET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
var fromBase642 = /* @__PURE__ */ createRfc4648Decode(BASE64_CHARSET, 6, false);
var toBase642 = /* @__PURE__ */ createRfc4648Encode(BASE64_CHARSET, 6, false);

// node_modules/@atcute/multibase/dist/bases/base64-web.js
var HAS_NATIVE_SUPPORT = "fromBase64" in Uint8Array;
var fromBase643 = !HAS_NATIVE_SUPPORT ? fromBase642 : fromBase64;
var toBase643 = !HAS_NATIVE_SUPPORT ? toBase642 : toBase64;

// node_modules/@atcute/multibase/dist/bases/base32.js
var BASE32_CHARSET = "abcdefghijklmnopqrstuvwxyz234567";
var toBase32 = /* @__PURE__ */ createRfc4648Encode(BASE32_CHARSET, 5, false);

// node_modules/@atcute/cid/dist/codec.js
var CID_VERSION = 1;
var HASH_SHA256 = 18;
var CODEC_RAW = 85;
var CODEC_DCBOR = 113;
var CID_STRINGIFY_CACHE = /* @__PURE__ */ new WeakMap();
var decodeFirst = (bytes) => {
  const length = bytes.length;
  if (length < 4) {
    throw new RangeError(`cid too short`);
  }
  const version = bytes[0];
  const codec = bytes[1];
  const digestType = bytes[2];
  const digestSize = bytes[3];
  if (version !== CID_VERSION) {
    throw new RangeError(`incorrect cid version (got v${version})`);
  }
  if (codec !== CODEC_DCBOR && codec !== CODEC_RAW) {
    throw new RangeError(`incorrect cid codec (got 0x${codec.toString(16)})`);
  }
  if (digestType !== HASH_SHA256) {
    throw new RangeError(`incorrect cid digest codec (got 0x${digestType.toString(16)})`);
  }
  if (digestSize !== 32 && digestSize !== 0) {
    throw new RangeError(`incorrect cid digest size (got ${digestSize})`);
  }
  if (length < 4 + digestSize) {
    throw new RangeError(`cid too short`);
  }
  const cid = {
    version: CID_VERSION,
    codec,
    digest: {
      codec: digestType,
      contents: bytes.subarray(4, 4 + digestSize)
    },
    bytes: bytes.subarray(0, 4 + digestSize)
  };
  return [cid, bytes.subarray(4 + digestSize)];
};
var decode = (bytes) => {
  const [cid, remainder] = decodeFirst(bytes);
  if (remainder.length !== 0) {
    throw new RangeError(`cid bytes includes remainder`);
  }
  return cid;
};
var toString = (cid) => {
  let str = CID_STRINGIFY_CACHE.get(cid);
  if (str === void 0) {
    str = `b${toBase32(cid.bytes)}`;
    CID_STRINGIFY_CACHE.set(cid, str);
  }
  return str;
};
var fromBinary = (input) => {
  if (input.length !== 37 && input.length !== 5) {
    throw new RangeError(`cid bytes too short`);
  }
  if (input[0] !== 0) {
    throw new SyntaxError(`incorrect binary cid`);
  }
  const bytes = input.subarray(1);
  return decode(bytes);
};

// node_modules/@atcute/cid/dist/cid-link.js
var CID_LINK_SYMBOL = /* @__PURE__ */ Symbol.for("@atcute/cid-link-wrapper");
var CIDLINK_STRINGIFY_CACHE = /* @__PURE__ */ new WeakMap();
var CidLinkWrapper = class {
  /** @internal */
  [CID_LINK_SYMBOL] = true;
  bytes;
  constructor(bytes) {
    this.bytes = bytes;
  }
  get $link() {
    let str = CIDLINK_STRINGIFY_CACHE.get(this);
    if (str === void 0) {
      str = `b${toBase32(this.bytes)}`;
      CIDLINK_STRINGIFY_CACHE.set(this, str);
    }
    return str;
  }
  toJSON() {
    return { $link: this.$link };
  }
};
var isCidLink = (value) => {
  const val = value;
  return val instanceof CidLinkWrapper || val !== null && typeof val === "object" && typeof val.$link === "string";
};

// node_modules/@atcute/cbor/dist/bytes.js
var BYTES_SYMBOL = /* @__PURE__ */ Symbol.for("@atcute/bytes-wrapper");
var BytesWrapper = class {
  buf;
  /** @internal */
  [BYTES_SYMBOL] = true;
  constructor(buf) {
    this.buf = buf;
  }
  get $bytes() {
    return toBase643(this.buf);
  }
  toJSON() {
    return { $bytes: this.$bytes };
  }
};
var isBytes = (value) => {
  const val = value;
  return val instanceof BytesWrapper || val !== null && typeof val === "object" && typeof val.$bytes === "string";
};
var toBytes = (buf) => {
  return new BytesWrapper(buf);
};
var fromBytes = (bytes) => {
  if (bytes instanceof BytesWrapper) {
    return bytes.buf;
  }
  return fromBase643(bytes.$bytes);
};

// node_modules/@atcute/cbor/dist/decode.js
var readArgument = (state, info) => {
  if (info < 24) {
    return info;
  }
  let arg;
  switch (info) {
    case 24: {
      arg = readUint8(state);
      if (arg < 24) {
        throw new TypeError(`non-canonical argument encoding`);
      }
      break;
    }
    case 25: {
      arg = readUint16(state);
      if (arg < 256) {
        throw new TypeError(`non-canonical argument encoding`);
      }
      break;
    }
    case 26: {
      arg = readUint32(state);
      if (arg < 65536) {
        throw new TypeError(`non-canonical argument encoding`);
      }
      break;
    }
    case 27: {
      arg = readUint53(state);
      if (arg < 4294967296) {
        throw new TypeError(`non-canonical argument encoding`);
      }
      break;
    }
    default: {
      throw new Error(`invalid argument encoding; got ${info}`);
    }
  }
  return arg;
};
var readFloat64 = (state) => {
  const view = state.v ??= new DataView(state.b.buffer, state.b.byteOffset, state.b.byteLength);
  const value = view.getFloat64(state.p);
  state.p += 8;
  return value;
};
var readUint8 = (state) => {
  return state.b[state.p++];
};
var readUint16 = (state) => {
  let pos = state.p;
  const buf = state.b;
  const value = buf[pos++] << 8 | buf[pos++];
  state.p = pos;
  return value;
};
var readUint32 = (state) => {
  let pos = state.p;
  const buf = state.b;
  const value = (buf[pos++] << 24 | buf[pos++] << 16 | buf[pos++] << 8 | buf[pos++]) >>> 0;
  state.p = pos;
  return value;
};
var readUint53 = (state) => {
  const hi = readUint32(state);
  const lo = readUint32(state);
  if (hi > 2097151) {
    throw new RangeError(`can't decode integers beyond safe integer range`);
  }
  return hi * 2 ** 32 + lo;
};
var readString = (state, length) => {
  const string = decodeUtf8From(state.b, state.p, length);
  state.p += length;
  return string;
};
var readBytes = (state, length) => {
  const slice = state.b.subarray(state.p, state.p += length);
  return toBytes(slice);
};
var readCid = (state, length) => {
  const cid = fromBinary(state.b.subarray(state.p, state.p += length));
  return new CidLinkWrapper(cid.bytes);
};
var compareKeys = (a, b) => {
  return a.length - b.length || (a < b ? -1 : a > b ? 1 : 0);
};
var decodeStringKey = (state) => {
  const prelude = readUint8(state);
  const type = prelude >> 5;
  if (type !== 3) {
    throw new TypeError(`expected map to only have string keys; got type ${type}`);
  }
  const info = prelude & 31;
  const length = readArgument(state, info);
  return readString(state, length);
};
var decodeFirst2 = (buf) => {
  const len = buf.length;
  const state = {
    b: buf,
    v: null,
    p: 0
  };
  let stack = null;
  let value;
  jump: while (state.p < len) {
    const prelude = readUint8(state);
    const type = prelude >> 5;
    const info = prelude & 31;
    const arg = type === 7 ? 0 : readArgument(state, info);
    switch (type) {
      case 0: {
        value = arg;
        break;
      }
      case 1: {
        value = -1 - arg;
        break;
      }
      case 2: {
        value = readBytes(state, arg);
        break;
      }
      case 3: {
        value = readString(state, arg);
        break;
      }
      case 4: {
        if (arg > 0) {
          stack = { t: 1, c: value = new Array(arg), k: null, r: arg, n: stack };
          continue jump;
        }
        value = [];
        break;
      }
      case 5: {
        value = {};
        if (arg > 0) {
          const first = decodeStringKey(state);
          stack = { t: 0, c: value, k: first, r: arg, n: stack };
          continue jump;
        }
        break;
      }
      case 6: {
        switch (arg) {
          case 42: {
            const prelude2 = readUint8(state);
            const type2 = prelude2 >> 5;
            const info2 = prelude2 & 31;
            if (type2 !== 2) {
              throw new TypeError(`expected cid-link to be type 2 (bytes); got type ${type2}`);
            }
            const len2 = readArgument(state, info2);
            value = readCid(state, len2);
            break;
          }
          default: {
            throw new TypeError(`unsupported tag; got ${arg}`);
          }
        }
        break;
      }
      case 7: {
        switch (info) {
          case 20:
          case 21: {
            value = info === 21;
            break;
          }
          case 22: {
            value = null;
            break;
          }
          case 27: {
            value = readFloat64(state);
            break;
          }
          default: {
            throw new Error(`invalid simple value; got ${info}`);
          }
        }
        break;
      }
      default: {
        throw new TypeError(`invalid type; got ${type}`);
      }
    }
    while (stack !== null) {
      switch (stack.t) {
        case 0: {
          const obj = stack.c;
          const key = stack.k;
          if (key === "__proto__") {
            Object.defineProperty(obj, key, { enumerable: true, configurable: true, writable: true });
          }
          obj[key] = value;
          break;
        }
        case 1: {
          const arr = stack.c;
          const index = arr.length - stack.r;
          arr[index] = value;
          break;
        }
      }
      if (--stack.r) {
        if (!stack.t) {
          const prevKey = stack.k;
          stack.k = decodeStringKey(state);
          if (compareKeys(stack.k, prevKey) <= 0) {
            throw new TypeError(`map keys are not in canonical order or contain duplicates`);
          }
        }
        continue jump;
      }
      value = stack.c;
      stack = stack.n;
    }
    break;
  }
  return [value, buf.subarray(state.p)];
};
var decode2 = (buf) => {
  const [value, remainder] = decodeFirst2(buf);
  if (remainder.length !== 0) {
    throw new Error(`decoded value contains remainder`);
  }
  return value;
};

// node_modules/@atcute/repo/dist/types.js
var RepoEntry = class {
  collection;
  rkey;
  cid;
  carEntry;
  /** @internal */
  constructor(collection, rkey, cid, carEntry) {
    this.collection = collection;
    this.rkey = rkey;
    this.cid = cid;
    this.carEntry = carEntry;
  }
  /**
   * raw contents of this record
   */
  get bytes() {
    return this.carEntry.bytes;
  }
  /**
   * decoded contents of this record
   */
  get record() {
    return decode2(this.bytes);
  }
};
var isCommit = (value) => {
  if (value === null || typeof value !== "object") {
    return false;
  }
  const obj = value;
  return obj.version === 3 && typeof obj.did === "string" && isCidLink(obj.data) && typeof obj.rev === "string" && (obj.prev === null || isCidLink(obj.prev)) && isBytes(obj.sig);
};

// node_modules/@atcute/varint/dist/index.js
var MSB = 128;
var REST = 127;
var MSBALL = ~REST;
var INT = 2 ** 31;
var N1 = 2 ** 7;
var N2 = 2 ** 14;
var N3 = 2 ** 21;
var N4 = 2 ** 28;
var N5 = 2 ** 35;
var N6 = 2 ** 42;
var N7 = 2 ** 49;
var N8 = 2 ** 56;
var N9 = 2 ** 63;
var decode3 = (buf, offset = 0) => {
  let l = buf.length;
  let res = 0;
  let shift = 0;
  let counter = offset;
  let b;
  do {
    if (counter >= l) {
      throw new RangeError("could not decode varint");
    }
    b = buf[counter++];
    res += shift < 28 ? (b & REST) << shift : (b & REST) * Math.pow(2, shift);
    shift += 7;
  } while (b >= MSB);
  return [res, counter - offset];
};

// node_modules/@atcute/car/dist/types.js
var isCarV1Header = (value) => {
  if (value === null || typeof value !== "object") {
    return false;
  }
  const { version, roots } = value;
  return version === 1 && Array.isArray(roots) && roots.every((root) => root instanceof CidLinkWrapper);
};

// node_modules/@atcute/car/dist/reader.js
var fromUint8Array = (buffer) => {
  const reader = createUint8Reader(buffer);
  const header = readHeader(reader);
  return {
    header,
    roots: header.data.roots,
    *iterate() {
      while (reader.upto(8 + 36).length > 0) {
        const entryStart = reader.pos;
        const entrySize = readVarint(reader, 8);
        const cidStart = reader.pos;
        const cid = readCid2(reader);
        const bytesStart = reader.pos;
        const bytesSize = entrySize - (bytesStart - cidStart);
        const bytes = reader.exactly(bytesSize, true);
        const cidEnd = bytesStart;
        const bytesEnd = reader.pos;
        const entryEnd = bytesEnd;
        yield {
          cid,
          bytes,
          entryStart,
          entryEnd,
          cidStart,
          cidEnd,
          bytesStart,
          bytesEnd
        };
      }
    },
    [Symbol.iterator]() {
      return this.iterate();
    }
  };
};
var createUint8Reader = (buf) => {
  let pos = 0;
  return {
    get pos() {
      return pos;
    },
    seek(size) {
      if (size > buf.length - pos) {
        throw new RangeError("unexpected end of data");
      }
      pos += size;
    },
    upto(size) {
      return buf.subarray(pos, pos + size);
    },
    exactly(size, seek) {
      if (size > buf.length - pos) {
        throw new RangeError("unexpected end of data");
      }
      const slice = buf.subarray(pos, pos + size);
      if (seek) {
        pos += size;
      }
      return slice;
    }
  };
};
var readVarint = (reader, size) => {
  const buf = reader.upto(size);
  if (buf.length === 0) {
    throw new RangeError(`unexpected end of data`);
  }
  const [int, read] = decode3(buf);
  reader.seek(read);
  return int;
};
var readHeader = (reader) => {
  const headerStart = reader.pos;
  const length = readVarint(reader, 8);
  if (length === 0) {
    throw new RangeError(`invalid car header; length=0`);
  }
  const dataStart = reader.pos;
  const rawHeader = reader.exactly(length, true);
  const data = decode2(rawHeader);
  if (!isCarV1Header(data)) {
    throw new TypeError(`expected a car v1 archive`);
  }
  const dataEnd = reader.pos;
  const headerEnd = dataEnd;
  return { data, headerStart, headerEnd, dataStart, dataEnd };
};
var readCid2 = (reader) => {
  const head = reader.exactly(4, false);
  const version = head[0];
  const codec = head[1];
  const digestType = head[2];
  const digestSize = head[3];
  if (version !== CID_VERSION) {
    throw new RangeError(`incorrect cid version (got v${version})`);
  }
  if (codec !== CODEC_DCBOR && codec !== CODEC_RAW) {
    throw new RangeError(`incorrect cid codec (got 0x${codec.toString(16)})`);
  }
  if (digestType !== HASH_SHA256) {
    throw new RangeError(`incorrect cid digest type (got 0x${digestType.toString(16)})`);
  }
  if (digestSize !== 32 && digestSize !== 0) {
    throw new RangeError(`incorrect cid digest size (got ${digestSize})`);
  }
  const bytes = reader.exactly(4 + digestSize, true);
  const digest = bytes.subarray(4, 4 + digestSize);
  const cid = {
    version,
    codec,
    digest: {
      codec: digestType,
      contents: digest
    },
    bytes
  };
  return cid;
};

// node_modules/@atcute/mst/dist/types.js
var isTreeEntry = (value) => {
  if (value === null || typeof value !== "object") {
    return false;
  }
  const obj = value;
  return typeof obj.p === "number" && isBytes(obj.k) && isCidLink(obj.v) && (obj.t === null || isCidLink(obj.t));
};
var isNodeData = (value) => {
  if (value === null || typeof value !== "object") {
    return false;
  }
  const obj = value;
  return (obj.l === null || isCidLink(obj.l)) && Array.isArray(obj.e) && obj.e.every(isTreeEntry);
};

// node_modules/@atcute/repo/dist/utils.js
var assert = (condition, message) => {
  if (!condition) {
    throw new Error(message);
  }
};

// node_modules/@atcute/repo/dist/reader.js
function* fromUint8Array2(buf) {
  const car = fromUint8Array(buf);
  const roots = car.roots;
  assert(roots.length === 1, `expected only 1 root in the car archive; got=${roots.length}`);
  const map = /* @__PURE__ */ new Map();
  for (const entry of car) {
    map.set(toString(entry.cid), entry);
  }
  assert(map.size >= 2, `expected at least 2 blocks in the archive; got=${map.size}`);
  const commit = readEntry(map, roots[0], isCommit);
  for (const { key, cid } of walkMstEntries(map, commit.data)) {
    const [collection, rkey] = key.split("/");
    const carEntry = map.get(cid.$link);
    assert(carEntry != null, `cid not found in blockmap; cid=${cid}`);
    yield new RepoEntry(collection, rkey, cid, carEntry);
  }
}
var readEntry = (map, link, validate) => {
  const cid = link.$link;
  const entry = map.get(cid);
  assert(entry != null, `cid not found in blockmap; cid=${cid}`);
  const data = decode2(entry.bytes);
  assert(validate(data), `validation failed for cid=${cid}`);
  return data;
};
function* walkMstEntries(map, pointer) {
  const data = readEntry(map, pointer, isNodeData);
  const entries = data.e;
  let lastKey = "";
  if (data.l !== null) {
    yield* walkMstEntries(map, data.l);
  }
  for (let i = 0, il = entries.length; i < il; i++) {
    const entry = entries[i];
    const key_str = decodeUtf8From(fromBytes(entry.k));
    const key = lastKey.slice(0, entry.p) + key_str;
    lastKey = key;
    yield { key, cid: entry.v };
    if (entry.t !== null) {
      yield* walkMstEntries(map, entry.t);
    }
  }
}

// src/utils.ts
var LOG_LEVEL_PRIORITY = {
  debug: 0,
  info: 1,
  warn: 2,
  error: 3
};
var currentLogLevel = "info";
var logger = {
  debug: (message, ...args) => {
    if (LOG_LEVEL_PRIORITY[currentLogLevel] <= LOG_LEVEL_PRIORITY.debug) {
      console.debug(`[ErgoBlock] ${message}`, ...args);
    }
  },
  info: (message, ...args) => {
    if (LOG_LEVEL_PRIORITY[currentLogLevel] <= LOG_LEVEL_PRIORITY.info) {
      console.log(`[ErgoBlock] ${message}`, ...args);
    }
  },
  warn: (message, ...args) => {
    if (LOG_LEVEL_PRIORITY[currentLogLevel] <= LOG_LEVEL_PRIORITY.warn) {
      console.warn(`[ErgoBlock] ${message}`, ...args);
    }
  },
  error: (message, ...args) => {
    if (LOG_LEVEL_PRIORITY[currentLogLevel] <= LOG_LEVEL_PRIORITY.error) {
      console.error(`[ErgoBlock] ${message}`, ...args);
    }
  }
};
var RateLimiter = class {
  constructor(options = {}) {
    this.lastActionTime = 0;
    this.actionCount = 0;
    this.windowMs = options.windowMs ?? 1e4;
    this.maxActions = options.maxActions ?? 5;
    this.cooldownMs = options.cooldownMs ?? 2e3;
  }
  /**
   * Check if an action is allowed
   * @returns true if allowed, false if rate limited
   */
  canPerformAction() {
    const now = Date.now();
    if (now - this.lastActionTime > this.windowMs) {
      this.actionCount = 0;
    }
    if (now - this.lastActionTime < this.cooldownMs) {
      return false;
    }
    if (this.actionCount >= this.maxActions) {
      return false;
    }
    return true;
  }
  /**
   * Record an action
   */
  recordAction() {
    const now = Date.now();
    if (now - this.lastActionTime > this.windowMs) {
      this.actionCount = 0;
    }
    this.lastActionTime = now;
    this.actionCount++;
  }
  /**
   * Get time until next action is allowed (in ms)
   */
  getWaitTime() {
    const now = Date.now();
    const cooldownRemaining = Math.max(0, this.cooldownMs - (now - this.lastActionTime));
    if (this.actionCount >= this.maxActions) {
      const windowRemaining = Math.max(0, this.windowMs - (now - this.lastActionTime));
      return Math.max(cooldownRemaining, windowRemaining);
    }
    return cooldownRemaining;
  }
};
var actionRateLimiter = new RateLimiter({
  windowMs: 1e4,
  // 10 seconds
  maxActions: 5,
  // Max 5 blocks/mutes per 10 seconds
  cooldownMs: 1e3
  // 1 second minimum between actions
});
var CircuitBreaker = class {
  constructor(options = {}) {
    this.state = "closed";
    this.failures = 0;
    this.lastFailureTime = 0;
    this.successesSinceHalfOpen = 0;
    this.failureThreshold = options.failureThreshold ?? 5;
    this.resetTimeoutMs = options.resetTimeoutMs ?? 6e4;
    this.halfOpenSuccessThreshold = options.halfOpenSuccessThreshold ?? 2;
  }
  /**
   * Get current circuit state
   */
  getState() {
    this.updateState();
    return this.state;
  }
  /**
   * Check if circuit allows requests
   */
  isAllowed() {
    this.updateState();
    return this.state !== "open";
  }
  /**
   * Record a successful operation
   */
  recordSuccess() {
    this.updateState();
    if (this.state === "half-open") {
      this.successesSinceHalfOpen++;
      if (this.successesSinceHalfOpen >= this.halfOpenSuccessThreshold) {
        this.reset();
      }
    } else if (this.state === "closed") {
      this.failures = Math.max(0, this.failures - 1);
    }
  }
  /**
   * Record a failed operation
   */
  recordFailure() {
    this.updateState();
    if (this.state === "half-open") {
      this.trip();
    } else if (this.state === "closed") {
      this.failures++;
      this.lastFailureTime = Date.now();
      if (this.failures >= this.failureThreshold) {
        this.trip();
      }
    }
  }
  /**
   * Manually reset the circuit
   */
  reset() {
    this.state = "closed";
    this.failures = 0;
    this.successesSinceHalfOpen = 0;
    logger.info("Circuit breaker reset to closed");
  }
  trip() {
    this.state = "open";
    this.lastFailureTime = Date.now();
    logger.warn(`Circuit breaker opened after ${this.failures} failures`);
  }
  updateState() {
    if (this.state === "open") {
      const now = Date.now();
      if (now - this.lastFailureTime >= this.resetTimeoutMs) {
        this.state = "half-open";
        this.successesSinceHalfOpen = 0;
        logger.info("Circuit breaker entering half-open state");
      }
    }
  }
};
var apiCircuitBreaker = new CircuitBreaker({
  failureThreshold: 5,
  resetTimeoutMs: 6e4,
  // 1 minute
  halfOpenSuccessThreshold: 2
});
function generateId(prefix) {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
}

// src/carRepo.ts
var BSKY_RELAY = "https://bsky.network";
var CAR_DOWNLOAD_TIMEOUT_MS = 12e4;
function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
async function downloadCarFile(did, pdsUrl, onProgress, timeoutMs = CAR_DOWNLOAD_TIMEOUT_MS) {
  onProgress?.("Downloading repository...");
  const controller = new AbortController();
  const timeoutId = setTimeout(() => {
    controller.abort();
    onProgress?.("Download timed out");
  }, timeoutMs);
  try {
    if (pdsUrl) {
      try {
        const response = await fetch(
          `${pdsUrl}/xrpc/com.atproto.sync.getRepo?did=${encodeURIComponent(did)}`,
          { signal: controller.signal }
        );
        if (response.ok) {
          return await streamResponseToUint8Array(response, onProgress, controller.signal);
        }
        console.warn(`[ErgoBlock CAR] PDS fetch failed: ${response.status}, trying relay`);
      } catch (error) {
        if (error && typeof error === "object" && error.name === "AbortError") {
          throw new Error(`CAR download timed out after ${timeoutMs}ms`);
        }
        console.warn(`[ErgoBlock CAR] PDS fetch error, trying relay:`, error);
      }
    }
    const relayResponse = await fetch(
      `${BSKY_RELAY}/xrpc/com.atproto.sync.getRepo?did=${encodeURIComponent(did)}`,
      { signal: controller.signal }
    );
    if (!relayResponse.ok) {
      throw new Error(`Failed to download repo: ${relayResponse.status}`);
    }
    return await streamResponseToUint8Array(relayResponse, onProgress, controller.signal);
  } catch (error) {
    if (error && typeof error === "object" && error.name === "AbortError") {
      throw new Error(`CAR download timed out after ${timeoutMs}ms`);
    }
    throw error;
  } finally {
    clearTimeout(timeoutId);
  }
}
async function streamResponseToUint8Array(response, onProgress, abortSignal) {
  const contentLength = response.headers.get("content-length");
  const totalBytes = contentLength ? parseInt(contentLength, 10) : null;
  const reader = response.body?.getReader();
  if (!reader) {
    throw new Error("Failed to get response reader");
  }
  const chunks = [];
  let receivedBytes = 0;
  try {
    while (true) {
      if (abortSignal?.aborted) {
        reader.cancel();
        throw new Error("Download aborted");
      }
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(value);
      receivedBytes += value.length;
      if (totalBytes) {
        const percent = Math.round(receivedBytes / totalBytes * 100);
        onProgress?.(
          `Downloading... ${formatBytes(receivedBytes)} / ${formatBytes(totalBytes)} (${percent}%)`
        );
      } else {
        onProgress?.(`Downloading... ${formatBytes(receivedBytes)}`);
      }
    }
  } catch (error) {
    reader.cancel();
    throw error;
  }
  const result = new Uint8Array(receivedBytes);
  let offset = 0;
  for (const chunk of chunks) {
    result.set(chunk, offset);
    offset += chunk.length;
  }
  return result;
}
function parseCarForBlocks(carData) {
  const repo = fromUint8Array2(carData);
  const blocks = [];
  for (const entry of repo) {
    if (entry.collection !== "app.bsky.graph.block") {
      continue;
    }
    try {
      const record = decode2(entry.bytes);
      if (record.$type === "app.bsky.graph.block") {
        const block = record;
        if (block.subject) {
          blocks.push(block.subject);
        }
      }
    } catch (error) {
      console.warn("[ErgoBlock CAR] Failed to decode block entry:", error);
    }
  }
  return blocks;
}
async function fetchBlocksFromCar(did, pdsUrl) {
  const carData = await downloadCarFile(did, pdsUrl);
  return parseCarForBlocks(carData);
}
function parseCarForLists(carData, creatorDid, targetListUris) {
  const repo = fromUint8Array2(carData);
  const listMetadata = {};
  const listItems = {};
  for (const entry of repo) {
    try {
      if (entry.collection === "app.bsky.graph.list") {
        const record = decode2(entry.bytes);
        if (record.$type === "app.bsky.graph.list") {
          const list = record;
          const listUri = `at://${creatorDid}/app.bsky.graph.list/${entry.rkey}`;
          if (targetListUris && !targetListUris.has(listUri)) {
            continue;
          }
          listMetadata[listUri] = {
            name: list.name,
            description: list.description,
            purpose: list.purpose,
            createdAt: new Date(list.createdAt).getTime(),
            rkey: entry.rkey
          };
          listItems[listUri] = [];
        }
      } else if (entry.collection === "app.bsky.graph.listitem") {
        const record = decode2(entry.bytes);
        if (record.$type === "app.bsky.graph.listitem") {
          const item = record;
          if (targetListUris && !targetListUris.has(item.list)) {
            continue;
          }
          if (!listItems[item.list]) {
            listItems[item.list] = [];
          }
          listItems[item.list].push(item.subject);
        }
      }
    } catch (error) {
      console.warn("[ErgoBlock CAR] Failed to decode list entry:", error);
    }
  }
  const lists = {};
  for (const [uri, metadata] of Object.entries(listMetadata)) {
    lists[uri] = {
      uri,
      name: metadata.name,
      description: metadata.description,
      purpose: metadata.purpose,
      createdAt: metadata.createdAt,
      members: listItems[uri] || []
    };
  }
  for (const [uri, members] of Object.entries(listItems)) {
    if (!lists[uri] && members.length > 0) {
      lists[uri] = {
        uri,
        name: "Unknown List",
        purpose: "app.bsky.graph.defs#curatelist",
        createdAt: 0,
        members
      };
    }
  }
  return { lists, creatorDid };
}
function parseCarForListsWithTimestamps(carData, creatorDid, targetListUris) {
  const repo = fromUint8Array2(carData);
  const listMetadata = {};
  const listItems = {};
  for (const entry of repo) {
    try {
      if (entry.collection === "app.bsky.graph.list") {
        const record = decode2(entry.bytes);
        if (record.$type === "app.bsky.graph.list") {
          const list = record;
          const listUri = `at://${creatorDid}/app.bsky.graph.list/${entry.rkey}`;
          if (targetListUris && !targetListUris.has(listUri)) {
            continue;
          }
          listMetadata[listUri] = {
            name: list.name,
            description: list.description,
            rkey: entry.rkey
          };
          listItems[listUri] = [];
        }
      } else if (entry.collection === "app.bsky.graph.listitem") {
        const record = decode2(entry.bytes);
        if (record.$type === "app.bsky.graph.listitem") {
          const item = record;
          if (targetListUris && !targetListUris.has(item.list)) {
            continue;
          }
          if (!listItems[item.list]) {
            listItems[item.list] = [];
          }
          listItems[item.list].push({
            did: item.subject,
            addedAt: new Date(item.createdAt).getTime(),
            rkey: entry.rkey
          });
        }
      }
    } catch (error) {
      console.warn("[ErgoBlock CAR] Failed to decode list entry:", error);
    }
  }
  const lists = {};
  for (const [uri, metadata] of Object.entries(listMetadata)) {
    lists[uri] = {
      uri,
      name: metadata.name,
      description: metadata.description,
      members: listItems[uri] || []
    };
  }
  for (const [uri, members] of Object.entries(listItems)) {
    if (!lists[uri] && members.length > 0) {
      lists[uri] = {
        uri,
        name: "Unknown List",
        members
      };
    }
  }
  return { lists, creatorDid };
}
async function fetchListsFromCarWithTimestamps(did, pdsUrl, targetListUris, onProgress) {
  const carData = await downloadCarFile(did, pdsUrl, onProgress);
  onProgress?.("Parsing lists...");
  return parseCarForListsWithTimestamps(carData, did, targetListUris);
}
async function fetchListsFromCar(did, pdsUrl, targetListUris, onProgress) {
  const carData = await downloadCarFile(did, pdsUrl, onProgress);
  onProgress?.("Parsing lists...");
  return parseCarForLists(carData, did, targetListUris);
}
async function getLatestCommit(did, pdsUrl) {
  const endpoints = [
    pdsUrl ? `${pdsUrl}/xrpc/com.atproto.sync.getLatestCommit?did=${encodeURIComponent(did)}` : null,
    `${BSKY_RELAY}/xrpc/com.atproto.sync.getLatestCommit?did=${encodeURIComponent(did)}`
  ].filter(Boolean);
  for (const url of endpoints) {
    try {
      const response = await fetch(url);
      if (response.ok) {
        const data = await response.json();
        return data;
      }
    } catch {
    }
  }
  return null;
}
async function downloadCarFileIncremental(did, pdsUrl, since, onProgress, timeoutMs = CAR_DOWNLOAD_TIMEOUT_MS) {
  const sinceParam = since ? `&since=${encodeURIComponent(since)}` : "";
  onProgress?.(since ? "Downloading changes..." : "Downloading repository...");
  const controller = new AbortController();
  const timeoutId = setTimeout(() => {
    controller.abort();
    onProgress?.("Download timed out");
  }, timeoutMs);
  try {
    if (pdsUrl) {
      try {
        const response = await fetch(
          `${pdsUrl}/xrpc/com.atproto.sync.getRepo?did=${encodeURIComponent(did)}${sinceParam}`,
          { signal: controller.signal }
        );
        if (response.ok) {
          return await streamResponseToUint8Array(response, onProgress, controller.signal);
        }
        if (response.status === 400 && since) {
          console.warn(
            `[ErgoBlock CAR] PDS doesn't support incremental sync, will do full download`
          );
          throw new Error("Incremental not supported");
        }
        console.warn(`[ErgoBlock CAR] PDS fetch failed: ${response.status}, trying relay`);
      } catch (error) {
        if (error instanceof Error && error.message === "Incremental not supported") {
          throw error;
        }
        if (error && typeof error === "object" && error.name === "AbortError") {
          throw new Error(`CAR download timed out after ${timeoutMs}ms`);
        }
        console.warn(`[ErgoBlock CAR] PDS fetch error, trying relay:`, error);
      }
    }
    const relayResponse = await fetch(
      `${BSKY_RELAY}/xrpc/com.atproto.sync.getRepo?did=${encodeURIComponent(did)}${sinceParam}`,
      { signal: controller.signal }
    );
    if (!relayResponse.ok) {
      if (relayResponse.status === 400 && since) {
        throw new Error("Incremental not supported");
      }
      throw new Error(`Failed to download repo: ${relayResponse.status}`);
    }
    return await streamResponseToUint8Array(relayResponse, onProgress, controller.signal);
  } catch (error) {
    if (error && typeof error === "object" && error.name === "AbortError") {
      throw new Error(`CAR download timed out after ${timeoutMs}ms`);
    }
    throw error;
  } finally {
    clearTimeout(timeoutId);
  }
}
function parseIncrementalCarForBlocks(carData, existingBlocks) {
  const repo = fromUint8Array2(carData);
  const newBlocks = new Set(existingBlocks);
  for (const entry of repo) {
    if (entry.collection !== "app.bsky.graph.block") {
      continue;
    }
    try {
      if (entry.bytes.length === 0) {
        continue;
      }
      const record = decode2(entry.bytes);
      if (record.$type === "app.bsky.graph.block") {
        const block = record;
        if (block.subject) {
          newBlocks.add(block.subject);
        }
      }
    } catch (error) {
      console.warn("[ErgoBlock CAR] Failed to decode incremental block entry:", error);
    }
  }
  return Array.from(newBlocks);
}
async function fetchBlocksFromCarIncremental(did, pdsUrl, cachedRev, cachedBlocks) {
  const latestCommit = await getLatestCommit(did, pdsUrl);
  if (!latestCommit) {
    const blocks2 = await fetchBlocksFromCar(did, pdsUrl);
    return { blocks: blocks2, rev: "", wasIncremental: false };
  }
  if (cachedRev && cachedRev === latestCommit.rev && cachedBlocks) {
    console.log(`[ErgoBlock CAR] Repo unchanged for ${did}, skipping download`);
    return { blocks: cachedBlocks, rev: latestCommit.rev, wasIncremental: true };
  }
  if (cachedRev && cachedBlocks) {
    try {
      const incrementalData = await downloadCarFileIncremental(did, pdsUrl, cachedRev);
      const mergedBlocks = parseIncrementalCarForBlocks(incrementalData, cachedBlocks);
      console.log(
        `[ErgoBlock CAR] Incremental sync for ${did}: ${cachedBlocks.length} -> ${mergedBlocks.length} blocks`
      );
      return { blocks: mergedBlocks, rev: latestCommit.rev, wasIncremental: true };
    } catch (error) {
      console.warn(
        `[ErgoBlock CAR] Incremental sync failed for ${did}, doing full download:`,
        error
      );
    }
  }
  const carData = await downloadCarFile(did, pdsUrl);
  const blocks = parseCarForBlocks(carData);
  return { blocks, rev: latestCommit.rev, wasIncremental: false };
}
function parseCarForPosts(carData, did) {
  const repo = fromUint8Array2(carData);
  const posts = [];
  for (const entry of repo) {
    if (entry.collection !== "app.bsky.feed.post") {
      continue;
    }
    try {
      const record = decode2(entry.bytes);
      if (record.$type === "app.bsky.feed.post") {
        const post = record;
        posts.push({
          uri: `at://${did}/app.bsky.feed.post/${entry.rkey}`,
          cid: "",
          text: post.text || "",
          createdAt: post.createdAt,
          reply: post.reply ? {
            parent: { uri: post.reply.parent.uri },
            root: post.reply.root ? { uri: post.reply.root.uri } : void 0
          } : void 0,
          embed: post.embed ? {
            $type: post.embed.$type,
            record: post.embed.record ? { uri: post.embed.record.uri } : void 0
          } : void 0
        });
      }
    } catch (error) {
      console.warn("[ErgoBlock CAR] Failed to decode entry:", error);
    }
  }
  return { posts, creatorDid: did };
}
function parseCarForPostsInternal(carData, did) {
  const repo = fromUint8Array2(carData);
  const posts = [];
  for (const entry of repo) {
    if (entry.collection !== "app.bsky.feed.post") {
      continue;
    }
    try {
      const record = decode2(entry.bytes);
      if (record.$type === "app.bsky.feed.post") {
        const post = record;
        posts.push({
          uri: `at://${did}/app.bsky.feed.post/${entry.rkey}`,
          cid: "",
          // CID not needed for interaction detection
          text: post.text || "",
          createdAt: post.createdAt,
          reply: post.reply ? {
            parent: { uri: post.reply.parent.uri },
            root: post.reply.root ? { uri: post.reply.root.uri } : void 0
          } : void 0,
          embed: post.embed ? {
            $type: post.embed.$type,
            record: post.embed.record ? { uri: post.embed.record.uri } : void 0
          } : void 0
        });
      }
    } catch (error) {
      console.warn("[ErgoBlock CAR] Failed to decode entry:", error);
    }
  }
  return posts;
}
async function fetchAndParseRepo(did, pdsUrl, onProgress) {
  const carData = await downloadCarFile(did, pdsUrl, onProgress);
  onProgress?.("Parsing repository...");
  const posts = parseCarForPostsInternal(carData, did);
  const blocks = parseCarForBlocks(carData);
  onProgress?.(`Found ${posts.length} posts, ${blocks.length} blocks`);
  return {
    posts,
    blocks,
    fetchedAt: Date.now()
  };
}
async function getRecordCountsFromCar(did, pdsUrl, onProgress) {
  const carData = await downloadCarFile(did, pdsUrl, onProgress);
  onProgress?.("Counting records...");
  const counts = {
    "app.bsky.graph.follow": 0,
    "app.bsky.graph.block": 0,
    "app.bsky.graph.listitem": 0,
    "app.bsky.graph.list": 0,
    "app.bsky.feed.post": 0,
    "app.bsky.feed.like": 0,
    "app.bsky.feed.repost": 0,
    "app.bsky.actor.profile": 0
  };
  const repo = fromUint8Array2(carData);
  for (const entry of repo) {
    const collection = entry.collection;
    if (collection in counts) {
      counts[collection]++;
    } else {
      counts[collection] = (counts[collection] || 0) + 1;
    }
  }
  onProgress?.("Done");
  return counts;
}
async function getCarFileSize(did, pdsUrl) {
  const endpoints = [
    pdsUrl ? `${pdsUrl}/xrpc/com.atproto.sync.getRepo?did=${encodeURIComponent(did)}` : null,
    `${BSKY_RELAY}/xrpc/com.atproto.sync.getRepo?did=${encodeURIComponent(did)}`
  ].filter(Boolean);
  for (const url of endpoints) {
    try {
      const response = await fetch(url, { method: "HEAD" });
      if (response.ok) {
        const contentLength = response.headers.get("content-length");
        if (contentLength) {
          return parseInt(contentLength, 10);
        }
      }
    } catch {
    }
  }
  return null;
}
function parseCarForAllGraphOperations(carData, creatorDid) {
  const repo = fromUint8Array2(carData);
  const blocks = [];
  const follows = [];
  const listitems = [];
  const listNames = {};
  for (const entry of repo) {
    try {
      if (entry.collection === "app.bsky.graph.list") {
        const record = decode2(entry.bytes);
        if (record.$type === "app.bsky.graph.list") {
          const list = record;
          const listUri = `at://${creatorDid}/app.bsky.graph.list/${entry.rkey}`;
          listNames[listUri] = list.name;
        }
      }
    } catch {
    }
  }
  const repo2 = fromUint8Array2(carData);
  for (const entry of repo2) {
    try {
      if (entry.collection === "app.bsky.graph.block") {
        const record = decode2(entry.bytes);
        if (record.$type === "app.bsky.graph.block") {
          const block = record;
          if (block.subject && block.createdAt) {
            blocks.push({
              type: "block",
              did: block.subject,
              rkey: entry.rkey,
              createdAt: new Date(block.createdAt).getTime()
            });
          }
        }
      } else if (entry.collection === "app.bsky.graph.follow") {
        const record = decode2(entry.bytes);
        if (record.$type === "app.bsky.graph.follow") {
          const follow = record;
          if (follow.subject && follow.createdAt) {
            follows.push({
              type: "follow",
              did: follow.subject,
              rkey: entry.rkey,
              createdAt: new Date(follow.createdAt).getTime()
            });
          }
        }
      } else if (entry.collection === "app.bsky.graph.listitem") {
        const record = decode2(entry.bytes);
        if (record.$type === "app.bsky.graph.listitem") {
          const item = record;
          if (item.subject && item.createdAt) {
            listitems.push({
              type: "listitem",
              did: item.subject,
              rkey: entry.rkey,
              createdAt: new Date(item.createdAt).getTime(),
              listUri: item.list,
              listName: listNames[item.list] || "Unknown List"
            });
          }
        }
      }
    } catch (error) {
      console.warn("[ErgoBlock CAR] Failed to decode graph operation:", error);
    }
  }
  return { blocks, follows, listitems };
}
function detectMassOperations(operations, settings) {
  const clusters = [];
  const timeWindowMs = settings.timeWindowMinutes * 60 * 1e3;
  const operationGroups = [
    { type: "block", ops: operations.blocks },
    { type: "follow", ops: operations.follows },
    { type: "listitem", ops: operations.listitems }
  ];
  for (const group of operationGroups) {
    if (group.ops.length < settings.minOperationCount) {
      continue;
    }
    const sorted = [...group.ops].sort((a, b) => a.createdAt - b.createdAt);
    const used = /* @__PURE__ */ new Set();
    for (let i = 0; i < sorted.length; i++) {
      if (used.has(sorted[i].rkey)) {
        continue;
      }
      const windowStart = sorted[i].createdAt;
      const windowEnd = windowStart + timeWindowMs;
      const windowOps = [];
      for (let j = i; j < sorted.length && sorted[j].createdAt <= windowEnd; j++) {
        if (!used.has(sorted[j].rkey)) {
          windowOps.push(sorted[j]);
        }
      }
      if (windowOps.length >= settings.minOperationCount) {
        for (const op of windowOps) {
          used.add(op.rkey);
        }
        clusters.push({
          id: generateId("cluster"),
          type: group.type,
          operations: windowOps,
          startTime: windowOps[0].createdAt,
          endTime: windowOps[windowOps.length - 1].createdAt,
          count: windowOps.length
        });
      }
    }
  }
  clusters.sort((a, b) => b.startTime - a.startTime);
  return clusters;
}
async function scanForMassOperations(did, pdsUrl, settings, onProgress) {
  const carData = await downloadCarFile(did, pdsUrl, onProgress);
  onProgress?.("Parsing operations...");
  const operations = parseCarForAllGraphOperations(carData, did);
  onProgress?.("Detecting mass operations...");
  const clusters = detectMassOperations(operations, settings);
  onProgress?.(
    clusters.length > 0 ? `Found ${clusters.length} mass operation clusters` : "No mass operations detected"
  );
  return {
    clusters,
    operationCounts: {
      blocks: operations.blocks.length,
      follows: operations.follows.length,
      listitems: operations.listitems.length
    }
  };
}
function parseCarForFollowsAndBlocks(carData) {
  const repo = fromUint8Array2(carData);
  const follows = [];
  const blocks = [];
  for (const entry of repo) {
    try {
      if (entry.collection === "app.bsky.graph.follow") {
        const record = decode2(entry.bytes);
        if (record.$type === "app.bsky.graph.follow") {
          const follow = record;
          if (follow.subject) {
            follows.push(follow.subject);
          }
        }
      } else if (entry.collection === "app.bsky.graph.block") {
        const record = decode2(entry.bytes);
        if (record.$type === "app.bsky.graph.block") {
          const block = record;
          if (block.subject) {
            blocks.push(block.subject);
          }
        }
      }
    } catch (error) {
      console.warn("[ErgoBlock CAR] Failed to decode graph entry:", error);
    }
  }
  return { follows, blocks };
}
async function fetchExternalUserGraph(did, pdsUrl, onProgress) {
  const carData = await downloadCarFile(did, pdsUrl, onProgress);
  onProgress?.("Parsing follows and blocks...");
  return parseCarForFollowsAndBlocks(carData);
}
export {
  detectMassOperations,
  fetchAndParseRepo,
  fetchBlocksFromCar,
  fetchBlocksFromCarIncremental,
  fetchExternalUserGraph,
  fetchListsFromCar,
  fetchListsFromCarWithTimestamps,
  getCarFileSize,
  getLatestCommit,
  getRecordCountsFromCar,
  parseCarForAllGraphOperations,
  parseCarForBlocks,
  parseCarForFollowsAndBlocks,
  parseCarForLists,
  parseCarForListsWithTimestamps,
  parseCarForPosts,
  scanForMassOperations
};
