// src/clearskyCache.ts
var DB_NAME = "ergoblock-clearsky-cache";
var DB_VERSION = 1;
var STORES = {
  BLOCKED_BY: "blockedBy",
  QUEUE: "fetchQueue"
};
var dbPromise = null;
function openDatabase() {
  if (dbPromise) {
    return dbPromise;
  }
  dbPromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onerror = () => {
      console.error("[ClearskyCache] Failed to open database:", request.error);
      dbPromise = null;
      reject(request.error);
    };
    request.onsuccess = () => {
      resolve(request.result);
    };
    request.onupgradeneeded = (event) => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains(STORES.BLOCKED_BY)) {
        db.createObjectStore(STORES.BLOCKED_BY, { keyPath: "targetDid" });
      }
      if (!db.objectStoreNames.contains(STORES.QUEUE)) {
        const queueStore = db.createObjectStore(STORES.QUEUE, { keyPath: "targetDid" });
        queueStore.createIndex("status", "status", { unique: false });
        queueStore.createIndex("priority", "priority", { unique: false });
      }
    };
  });
  return dbPromise;
}
async function getBlockedByCache(targetDid) {
  try {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.BLOCKED_BY, "readonly");
      const request = tx.objectStore(STORES.BLOCKED_BY).get(targetDid);
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error("[ClearskyCache] Failed to get blocked-by cache:", error);
    return null;
  }
}
async function saveBlockedByCache(data) {
  try {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.BLOCKED_BY, "readwrite");
      const request = tx.objectStore(STORES.BLOCKED_BY).put(data);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error("[ClearskyCache] Failed to save blocked-by cache:", error);
    throw error;
  }
}
async function queueForFetch(targetDid, priority = 10) {
  try {
    const db = await openDatabase();
    const existing = await getQueueEntry(targetDid);
    if (existing && (existing.status === "pending" || existing.status === "in_progress")) {
      return;
    }
    const entry = {
      targetDid,
      priority,
      queuedAt: Date.now(),
      status: "pending",
      retryCount: existing?.retryCount || 0
    };
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.QUEUE, "readwrite");
      const request = tx.objectStore(STORES.QUEUE).put(entry);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error("[ClearskyCache] Failed to queue for fetch:", error);
    throw error;
  }
}
async function getQueueEntry(targetDid) {
  try {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.QUEUE, "readonly");
      const request = tx.objectStore(STORES.QUEUE).get(targetDid);
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error("[ClearskyCache] Failed to get queue entry:", error);
    return null;
  }
}
async function getPendingQueue() {
  try {
    const db = await openDatabase();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.QUEUE, "readonly");
      const store = tx.objectStore(STORES.QUEUE);
      const index = store.index("status");
      const request = index.getAll("pending");
      request.onsuccess = () => {
        const entries = request.result || [];
        entries.sort((a, b) => {
          if (a.priority !== b.priority) return a.priority - b.priority;
          return a.queuedAt - b.queuedAt;
        });
        resolve(entries);
      };
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error("[ClearskyCache] Failed to get pending queue:", error);
    return [];
  }
}
async function updateQueueStatus(targetDid, status, error) {
  try {
    const db = await openDatabase();
    const existing = await getQueueEntry(targetDid);
    if (!existing) return;
    const updated = {
      ...existing,
      status,
      lastError: error,
      retryCount: status === "failed" ? existing.retryCount + 1 : existing.retryCount
    };
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES.QUEUE, "readwrite");
      const request = tx.objectStore(STORES.QUEUE).put(updated);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch (error2) {
    console.error("[ClearskyCache] Failed to update queue status:", error2);
    throw error2;
  }
}

// src/utils.ts
var LOG_LEVEL_PRIORITY = {
  debug: 0,
  info: 1,
  warn: 2,
  error: 3
};
var currentLogLevel = "info";
var logger = {
  debug: (message, ...args) => {
    if (LOG_LEVEL_PRIORITY[currentLogLevel] <= LOG_LEVEL_PRIORITY.debug) {
      console.debug(`[ErgoBlock] ${message}`, ...args);
    }
  },
  info: (message, ...args) => {
    if (LOG_LEVEL_PRIORITY[currentLogLevel] <= LOG_LEVEL_PRIORITY.info) {
      console.log(`[ErgoBlock] ${message}`, ...args);
    }
  },
  warn: (message, ...args) => {
    if (LOG_LEVEL_PRIORITY[currentLogLevel] <= LOG_LEVEL_PRIORITY.warn) {
      console.warn(`[ErgoBlock] ${message}`, ...args);
    }
  },
  error: (message, ...args) => {
    if (LOG_LEVEL_PRIORITY[currentLogLevel] <= LOG_LEVEL_PRIORITY.error) {
      console.error(`[ErgoBlock] ${message}`, ...args);
    }
  }
};
var RateLimiter = class {
  constructor(options = {}) {
    this.lastActionTime = 0;
    this.actionCount = 0;
    this.windowMs = options.windowMs ?? 1e4;
    this.maxActions = options.maxActions ?? 5;
    this.cooldownMs = options.cooldownMs ?? 2e3;
  }
  /**
   * Check if an action is allowed
   * @returns true if allowed, false if rate limited
   */
  canPerformAction() {
    const now = Date.now();
    if (now - this.lastActionTime > this.windowMs) {
      this.actionCount = 0;
    }
    if (now - this.lastActionTime < this.cooldownMs) {
      return false;
    }
    if (this.actionCount >= this.maxActions) {
      return false;
    }
    return true;
  }
  /**
   * Record an action
   */
  recordAction() {
    const now = Date.now();
    if (now - this.lastActionTime > this.windowMs) {
      this.actionCount = 0;
    }
    this.lastActionTime = now;
    this.actionCount++;
  }
  /**
   * Get time until next action is allowed (in ms)
   */
  getWaitTime() {
    const now = Date.now();
    const cooldownRemaining = Math.max(0, this.cooldownMs - (now - this.lastActionTime));
    if (this.actionCount >= this.maxActions) {
      const windowRemaining = Math.max(0, this.windowMs - (now - this.lastActionTime));
      return Math.max(cooldownRemaining, windowRemaining);
    }
    return cooldownRemaining;
  }
};
var actionRateLimiter = new RateLimiter({
  windowMs: 1e4,
  // 10 seconds
  maxActions: 5,
  // Max 5 blocks/mutes per 10 seconds
  cooldownMs: 1e3
  // 1 second minimum between actions
});
var CircuitBreaker = class {
  constructor(options = {}) {
    this.state = "closed";
    this.failures = 0;
    this.lastFailureTime = 0;
    this.successesSinceHalfOpen = 0;
    this.failureThreshold = options.failureThreshold ?? 5;
    this.resetTimeoutMs = options.resetTimeoutMs ?? 6e4;
    this.halfOpenSuccessThreshold = options.halfOpenSuccessThreshold ?? 2;
  }
  /**
   * Get current circuit state
   */
  getState() {
    this.updateState();
    return this.state;
  }
  /**
   * Check if circuit allows requests
   */
  isAllowed() {
    this.updateState();
    return this.state !== "open";
  }
  /**
   * Record a successful operation
   */
  recordSuccess() {
    this.updateState();
    if (this.state === "half-open") {
      this.successesSinceHalfOpen++;
      if (this.successesSinceHalfOpen >= this.halfOpenSuccessThreshold) {
        this.reset();
      }
    } else if (this.state === "closed") {
      this.failures = Math.max(0, this.failures - 1);
    }
  }
  /**
   * Record a failed operation
   */
  recordFailure() {
    this.updateState();
    if (this.state === "half-open") {
      this.trip();
    } else if (this.state === "closed") {
      this.failures++;
      this.lastFailureTime = Date.now();
      if (this.failures >= this.failureThreshold) {
        this.trip();
      }
    }
  }
  /**
   * Manually reset the circuit
   */
  reset() {
    this.state = "closed";
    this.failures = 0;
    this.successesSinceHalfOpen = 0;
    logger.info("Circuit breaker reset to closed");
  }
  trip() {
    this.state = "open";
    this.lastFailureTime = Date.now();
    logger.warn(`Circuit breaker opened after ${this.failures} failures`);
  }
  updateState() {
    if (this.state === "open") {
      const now = Date.now();
      if (now - this.lastFailureTime >= this.resetTimeoutMs) {
        this.state = "half-open";
        this.successesSinceHalfOpen = 0;
        logger.info("Circuit breaker entering half-open state");
      }
    }
  }
};
var apiCircuitBreaker = new CircuitBreaker({
  failureThreshold: 5,
  resetTimeoutMs: 6e4,
  // 1 minute
  halfOpenSuccessThreshold: 2
});
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// src/clearskyService.ts
var CLEARSKY_API_BASE = "https://public.api.clearsky.services";
var CACHE_TTL_MS = 24 * 60 * 60 * 1e3;
var REQUEST_DELAY_MS = 500;
var RATE_LIMIT_BACKOFF_MS = 5e3;
var MAX_RETRIES = 3;
var MAX_PAGES = 100;
async function fetchBlockedByFromClearsky(targetDidOrHandle, onProgress) {
  const blockerDids = [];
  let offset = 0;
  let pageCount = 0;
  const PAGE_SIZE = 100;
  try {
    let hasMore = true;
    while (hasMore && pageCount < MAX_PAGES) {
      const url = offset > 0 ? `${CLEARSKY_API_BASE}/api/v1/anon/single-blocklist/${encodeURIComponent(targetDidOrHandle)}?cursor=${offset}` : `${CLEARSKY_API_BASE}/api/v1/anon/single-blocklist/${encodeURIComponent(targetDidOrHandle)}`;
      const response = await fetch(url);
      if (!response.ok) {
        if (response.status === 404) {
          console.log(`[Clearsky] User not found: ${targetDidOrHandle}`);
          return { blockerDids: [], complete: true };
        }
        if (response.status === 429) {
          console.warn(`[Clearsky] Rate limited, waiting ${RATE_LIMIT_BACKOFF_MS / 1e3}s...`);
          await sleep(RATE_LIMIT_BACKOFF_MS);
          continue;
        }
        throw new Error(`Clearsky API error: ${response.status}`);
      }
      const data = await response.json();
      const entriesThisPage = data.data?.blocklist?.length || 0;
      if (data.data?.blocklist) {
        for (const entry of data.data.blocklist) {
          blockerDids.push(entry.did);
        }
        onProgress?.(blockerDids.length);
      }
      pageCount++;
      if (entriesThisPage >= PAGE_SIZE) {
        offset = blockerDids.length;
        await sleep(REQUEST_DELAY_MS);
      } else {
        hasMore = false;
      }
    }
    const complete = !hasMore;
    console.log(
      `[Clearsky] Fetched ${blockerDids.length} blockers for ${targetDidOrHandle} (${pageCount} pages, complete: ${complete})`,
      blockerDids.slice(0, 5)
    );
    return { blockerDids, complete };
  } catch (error) {
    console.error("[Clearsky] Failed to fetch blocked-by:", error);
    throw error;
  }
}
async function getCachedBlockedBy(targetDid) {
  const cached = await getBlockedByCache(targetDid);
  if (!cached) return null;
  if (Date.now() - cached.fetchedAt > CACHE_TTL_MS) {
    console.log(`[Clearsky] Cache expired for ${targetDid}`);
    return null;
  }
  return cached;
}
async function getFollowsWhoBlock(targetDid, myFollowDids, forceRefresh = false) {
  if (!forceRefresh) {
    const cached = await getCachedBlockedBy(targetDid);
    if (cached) {
      const blockerSet2 = new Set(cached.blockerDids);
      const followsWhoBlock2 = [...myFollowDids].filter((did) => blockerSet2.has(did));
      return {
        count: followsWhoBlock2.length,
        dids: followsWhoBlock2,
        totalBlockers: cached.totalCount,
        cached: true,
        fetchedAt: cached.fetchedAt
      };
    }
  }
  const { blockerDids, complete } = await fetchBlockedByFromClearsky(targetDid);
  const cacheEntry = {
    targetDid,
    blockerDids,
    totalCount: blockerDids.length,
    fetchedAt: Date.now(),
    complete
  };
  await saveBlockedByCache(cacheEntry);
  const blockerSet = new Set(blockerDids);
  const followSet = new Set(myFollowDids);
  const followsWhoBlock = [];
  if (followSet.size <= blockerSet.size) {
    for (const did of followSet) {
      if (blockerSet.has(did)) {
        followsWhoBlock.push(did);
      }
    }
  } else {
    for (const did of blockerSet) {
      if (followSet.has(did)) {
        followsWhoBlock.push(did);
      }
    }
  }
  return {
    count: followsWhoBlock.length,
    dids: followsWhoBlock,
    totalBlockers: blockerDids.length,
    cached: false,
    fetchedAt: cacheEntry.fetchedAt
  };
}
async function hasValidCache(targetDid) {
  const cached = await getCachedBlockedBy(targetDid);
  return cached !== null;
}
async function getFollowsWhoBlockCached(targetDid, myFollowDids) {
  const cached = await getCachedBlockedBy(targetDid);
  if (!cached) return null;
  const blockerSet = new Set(cached.blockerDids);
  const followsWhoBlock = [...myFollowDids].filter((did) => blockerSet.has(did));
  return {
    count: followsWhoBlock.length,
    dids: followsWhoBlock,
    totalBlockers: cached.totalCount,
    cached: true,
    fetchedAt: cached.fetchedAt
  };
}
async function queueBlockedByFetch(targetDids, priority = 10) {
  for (const did of targetDids) {
    const cached = await getCachedBlockedBy(did);
    if (cached) continue;
    await queueForFetch(did, priority);
  }
  console.log(`[Clearsky] Queued ${targetDids.length} targets for background fetch`);
}
async function processBlockedByQueue(maxItems = 5) {
  const pending = await getPendingQueue();
  const toProcess = pending.slice(0, maxItems);
  if (toProcess.length === 0) {
    return 0;
  }
  console.log(`[Clearsky] Processing ${toProcess.length} queued fetches`);
  let processed = 0;
  for (const entry of toProcess) {
    try {
      await updateQueueStatus(entry.targetDid, "in_progress");
      const cached = await getCachedBlockedBy(entry.targetDid);
      if (cached) {
        await updateQueueStatus(entry.targetDid, "completed");
        processed++;
        continue;
      }
      const { blockerDids, complete } = await fetchBlockedByFromClearsky(entry.targetDid);
      await saveBlockedByCache({
        targetDid: entry.targetDid,
        blockerDids,
        totalCount: blockerDids.length,
        fetchedAt: Date.now(),
        complete
      });
      await updateQueueStatus(entry.targetDid, "completed");
      processed++;
      await sleep(REQUEST_DELAY_MS * 2);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      console.error(`[Clearsky] Failed to fetch ${entry.targetDid}:`, errorMessage);
      if (entry.retryCount >= MAX_RETRIES) {
        await updateQueueStatus(entry.targetDid, "failed", errorMessage);
      } else {
        await updateQueueStatus(entry.targetDid, "pending", errorMessage);
      }
    }
  }
  return processed;
}
async function hasQueuedItems() {
  const pending = await getPendingQueue();
  return pending.length > 0;
}
async function prewarmBlockedByCache(targetDids, highPriority = false) {
  let queued = 0;
  let alreadyCached = 0;
  for (const did of targetDids) {
    const cached = await getCachedBlockedBy(did);
    if (cached) {
      alreadyCached++;
    } else {
      await queueForFetch(did, highPriority ? 1 : 10);
      queued++;
    }
  }
  console.log(`[Clearsky] Prewarm: ${queued} queued, ${alreadyCached} already cached`);
  return { queued, alreadyCached };
}
async function getBatchBlockedByCounts(targetDids, myFollowDids) {
  const results = /* @__PURE__ */ new Map();
  for (const did of targetDids) {
    const cached = await getCachedBlockedBy(did);
    if (cached) {
      const blockerSet = new Set(cached.blockerDids);
      const count = [...myFollowDids].filter((d) => blockerSet.has(d)).length;
      results.set(did, { count, cached: true });
    } else {
      results.set(did, { count: -1, cached: false });
    }
  }
  return results;
}
export {
  fetchBlockedByFromClearsky,
  getBatchBlockedByCounts,
  getFollowsWhoBlock,
  getFollowsWhoBlockCached,
  hasQueuedItems,
  hasValidCache,
  prewarmBlockedByCache,
  processBlockedByQueue,
  queueBlockedByFetch
};
