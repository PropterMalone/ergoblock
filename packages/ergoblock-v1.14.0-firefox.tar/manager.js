var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/webextension-polyfill/dist/browser-polyfill.js
var require_browser_polyfill = __commonJS({
  "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
    (function(global, factory) {
      if (typeof define === "function" && define.amd) {
        define("webextension-polyfill", ["module"], factory);
      } else if (typeof exports !== "undefined") {
        factory(module);
      } else {
        var mod = {
          exports: {}
        };
        factory(mod);
        global.browser = mod.exports;
      }
    })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
      "use strict";
      if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
        throw new Error("This script should only be loaded in a browser extension.");
      }
      if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
        const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
        const wrapAPIs = (extensionAPIs) => {
          const apiMetadata = {
            "alarms": {
              "clear": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "clearAll": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "get": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "getAll": {
                "minArgs": 0,
                "maxArgs": 0
              }
            },
            "bookmarks": {
              "create": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "get": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getChildren": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getRecent": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getSubTree": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getTree": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "move": {
                "minArgs": 2,
                "maxArgs": 2
              },
              "remove": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeTree": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "search": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "update": {
                "minArgs": 2,
                "maxArgs": 2
              }
            },
            "browserAction": {
              "disable": {
                "minArgs": 0,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "enable": {
                "minArgs": 0,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "getBadgeBackgroundColor": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getBadgeText": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getPopup": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getTitle": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "openPopup": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "setBadgeBackgroundColor": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "setBadgeText": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "setIcon": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "setPopup": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "setTitle": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              }
            },
            "browsingData": {
              "remove": {
                "minArgs": 2,
                "maxArgs": 2
              },
              "removeCache": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeCookies": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeDownloads": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeFormData": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeHistory": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeLocalStorage": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removePasswords": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removePluginData": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "settings": {
                "minArgs": 0,
                "maxArgs": 0
              }
            },
            "commands": {
              "getAll": {
                "minArgs": 0,
                "maxArgs": 0
              }
            },
            "contextMenus": {
              "remove": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeAll": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "update": {
                "minArgs": 2,
                "maxArgs": 2
              }
            },
            "cookies": {
              "get": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getAll": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getAllCookieStores": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "remove": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "set": {
                "minArgs": 1,
                "maxArgs": 1
              }
            },
            "devtools": {
              "inspectedWindow": {
                "eval": {
                  "minArgs": 1,
                  "maxArgs": 2,
                  "singleCallbackArg": false
                }
              },
              "panels": {
                "create": {
                  "minArgs": 3,
                  "maxArgs": 3,
                  "singleCallbackArg": true
                },
                "elements": {
                  "createSidebarPane": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              }
            },
            "downloads": {
              "cancel": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "download": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "erase": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getFileIcon": {
                "minArgs": 1,
                "maxArgs": 2
              },
              "open": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "pause": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeFile": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "resume": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "search": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "show": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              }
            },
            "extension": {
              "isAllowedFileSchemeAccess": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "isAllowedIncognitoAccess": {
                "minArgs": 0,
                "maxArgs": 0
              }
            },
            "history": {
              "addUrl": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "deleteAll": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "deleteRange": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "deleteUrl": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getVisits": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "search": {
                "minArgs": 1,
                "maxArgs": 1
              }
            },
            "i18n": {
              "detectLanguage": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getAcceptLanguages": {
                "minArgs": 0,
                "maxArgs": 0
              }
            },
            "identity": {
              "launchWebAuthFlow": {
                "minArgs": 1,
                "maxArgs": 1
              }
            },
            "idle": {
              "queryState": {
                "minArgs": 1,
                "maxArgs": 1
              }
            },
            "management": {
              "get": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getAll": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "getSelf": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "setEnabled": {
                "minArgs": 2,
                "maxArgs": 2
              },
              "uninstallSelf": {
                "minArgs": 0,
                "maxArgs": 1
              }
            },
            "notifications": {
              "clear": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "create": {
                "minArgs": 1,
                "maxArgs": 2
              },
              "getAll": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "getPermissionLevel": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "update": {
                "minArgs": 2,
                "maxArgs": 2
              }
            },
            "pageAction": {
              "getPopup": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getTitle": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "hide": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "setIcon": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "setPopup": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "setTitle": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "show": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              }
            },
            "permissions": {
              "contains": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getAll": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "remove": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "request": {
                "minArgs": 1,
                "maxArgs": 1
              }
            },
            "runtime": {
              "getBackgroundPage": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "getPlatformInfo": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "openOptionsPage": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "requestUpdateCheck": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "sendMessage": {
                "minArgs": 1,
                "maxArgs": 3
              },
              "sendNativeMessage": {
                "minArgs": 2,
                "maxArgs": 2
              },
              "setUninstallURL": {
                "minArgs": 1,
                "maxArgs": 1
              }
            },
            "sessions": {
              "getDevices": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "getRecentlyClosed": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "restore": {
                "minArgs": 0,
                "maxArgs": 1
              }
            },
            "storage": {
              "local": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getBytesInUse": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "managed": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getBytesInUse": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "sync": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getBytesInUse": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              }
            },
            "tabs": {
              "captureVisibleTab": {
                "minArgs": 0,
                "maxArgs": 2
              },
              "create": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "detectLanguage": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "discard": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "duplicate": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "executeScript": {
                "minArgs": 1,
                "maxArgs": 2
              },
              "get": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getCurrent": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "getZoom": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "getZoomSettings": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "goBack": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "goForward": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "highlight": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "insertCSS": {
                "minArgs": 1,
                "maxArgs": 2
              },
              "move": {
                "minArgs": 2,
                "maxArgs": 2
              },
              "query": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "reload": {
                "minArgs": 0,
                "maxArgs": 2
              },
              "remove": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeCSS": {
                "minArgs": 1,
                "maxArgs": 2
              },
              "sendMessage": {
                "minArgs": 2,
                "maxArgs": 3
              },
              "setZoom": {
                "minArgs": 1,
                "maxArgs": 2
              },
              "setZoomSettings": {
                "minArgs": 1,
                "maxArgs": 2
              },
              "update": {
                "minArgs": 1,
                "maxArgs": 2
              }
            },
            "topSites": {
              "get": {
                "minArgs": 0,
                "maxArgs": 0
              }
            },
            "webNavigation": {
              "getAllFrames": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getFrame": {
                "minArgs": 1,
                "maxArgs": 1
              }
            },
            "webRequest": {
              "handlerBehaviorChanged": {
                "minArgs": 0,
                "maxArgs": 0
              }
            },
            "windows": {
              "create": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "get": {
                "minArgs": 1,
                "maxArgs": 2
              },
              "getAll": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "getCurrent": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "getLastFocused": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "remove": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "update": {
                "minArgs": 2,
                "maxArgs": 2
              }
            }
          };
          if (Object.keys(apiMetadata).length === 0) {
            throw new Error("api-metadata.json has not been included in browser-polyfill");
          }
          class DefaultWeakMap extends WeakMap {
            constructor(createItem, items = void 0) {
              super(items);
              this.createItem = createItem;
            }
            get(key) {
              if (!this.has(key)) {
                this.set(key, this.createItem(key));
              }
              return super.get(key);
            }
          }
          const isThenable = (value) => {
            return value && typeof value === "object" && typeof value.then === "function";
          };
          const makeCallback = (promise, metadata) => {
            return (...callbackArgs) => {
              if (extensionAPIs.runtime.lastError) {
                promise.reject(new Error(extensionAPIs.runtime.lastError.message));
              } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                promise.resolve(callbackArgs[0]);
              } else {
                promise.resolve(callbackArgs);
              }
            };
          };
          const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
          const wrapAsyncFunction = (name, metadata) => {
            return function asyncFunctionWrapper(target, ...args) {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                if (metadata.fallbackToNoCallback) {
                  try {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  } catch (cbError) {
                    console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                    target[name](...args);
                    metadata.fallbackToNoCallback = false;
                    metadata.noCallback = true;
                    resolve();
                  }
                } else if (metadata.noCallback) {
                  target[name](...args);
                  resolve();
                } else {
                  target[name](...args, makeCallback({
                    resolve,
                    reject
                  }, metadata));
                }
              });
            };
          };
          const wrapMethod = (target, method, wrapper) => {
            return new Proxy(method, {
              apply(targetMethod, thisObj, args) {
                return wrapper.call(thisObj, target, ...args);
              }
            });
          };
          let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
          const wrapObject = (target, wrappers = {}, metadata = {}) => {
            let cache = /* @__PURE__ */ Object.create(null);
            let handlers = {
              has(proxyTarget2, prop) {
                return prop in target || prop in cache;
              },
              get(proxyTarget2, prop, receiver) {
                if (prop in cache) {
                  return cache[prop];
                }
                if (!(prop in target)) {
                  return void 0;
                }
                let value = target[prop];
                if (typeof value === "function") {
                  if (typeof wrappers[prop] === "function") {
                    value = wrapMethod(target, target[prop], wrappers[prop]);
                  } else if (hasOwnProperty(metadata, prop)) {
                    let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                    value = wrapMethod(target, target[prop], wrapper);
                  } else {
                    value = value.bind(target);
                  }
                } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                  value = wrapObject(value, wrappers[prop], metadata[prop]);
                } else if (hasOwnProperty(metadata, "*")) {
                  value = wrapObject(value, wrappers[prop], metadata["*"]);
                } else {
                  Object.defineProperty(cache, prop, {
                    configurable: true,
                    enumerable: true,
                    get() {
                      return target[prop];
                    },
                    set(value2) {
                      target[prop] = value2;
                    }
                  });
                  return value;
                }
                cache[prop] = value;
                return value;
              },
              set(proxyTarget2, prop, value, receiver) {
                if (prop in cache) {
                  cache[prop] = value;
                } else {
                  target[prop] = value;
                }
                return true;
              },
              defineProperty(proxyTarget2, prop, desc) {
                return Reflect.defineProperty(cache, prop, desc);
              },
              deleteProperty(proxyTarget2, prop) {
                return Reflect.deleteProperty(cache, prop);
              }
            };
            let proxyTarget = Object.create(target);
            return new Proxy(proxyTarget, handlers);
          };
          const wrapEvent = (wrapperMap) => ({
            addListener(target, listener, ...args) {
              target.addListener(wrapperMap.get(listener), ...args);
            },
            hasListener(target, listener) {
              return target.hasListener(wrapperMap.get(listener));
            },
            removeListener(target, listener) {
              target.removeListener(wrapperMap.get(listener));
            }
          });
          const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
            if (typeof listener !== "function") {
              return listener;
            }
            return function onRequestFinished(req) {
              const wrappedReq = wrapObject(req, {}, {
                getContent: {
                  minArgs: 0,
                  maxArgs: 0
                }
              });
              listener(wrappedReq);
            };
          });
          const onMessageWrappers = new DefaultWeakMap((listener) => {
            if (typeof listener !== "function") {
              return listener;
            }
            return function onMessage(message, sender, sendResponse) {
              let didCallSendResponse = false;
              let wrappedSendResponse;
              let sendResponsePromise = new Promise((resolve) => {
                wrappedSendResponse = function(response) {
                  didCallSendResponse = true;
                  resolve(response);
                };
              });
              let result;
              try {
                result = listener(message, sender, wrappedSendResponse);
              } catch (err) {
                result = Promise.reject(err);
              }
              const isResultThenable = result !== true && isThenable(result);
              if (result !== true && !isResultThenable && !didCallSendResponse) {
                return false;
              }
              const sendPromisedResult = (promise) => {
                promise.then((msg) => {
                  sendResponse(msg);
                }, (error) => {
                  let message2;
                  if (error && (error instanceof Error || typeof error.message === "string")) {
                    message2 = error.message;
                  } else {
                    message2 = "An unexpected error occurred";
                  }
                  sendResponse({
                    __mozWebExtensionPolyfillReject__: true,
                    message: message2
                  });
                }).catch((err) => {
                  console.error("Failed to send onMessage rejected reply", err);
                });
              };
              if (isResultThenable) {
                sendPromisedResult(result);
              } else {
                sendPromisedResult(sendResponsePromise);
              }
              return true;
            };
          });
          const wrappedSendMessageCallback = ({
            reject,
            resolve
          }, reply) => {
            if (extensionAPIs.runtime.lastError) {
              if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                resolve();
              } else {
                reject(new Error(extensionAPIs.runtime.lastError.message));
              }
            } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
              reject(new Error(reply.message));
            } else {
              resolve(reply);
            }
          };
          const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
            if (args.length < metadata.minArgs) {
              throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
            }
            if (args.length > metadata.maxArgs) {
              throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
            }
            return new Promise((resolve, reject) => {
              const wrappedCb = wrappedSendMessageCallback.bind(null, {
                resolve,
                reject
              });
              args.push(wrappedCb);
              apiNamespaceObj.sendMessage(...args);
            });
          };
          const staticWrappers = {
            devtools: {
              network: {
                onRequestFinished: wrapEvent(onRequestFinishedWrappers)
              }
            },
            runtime: {
              onMessage: wrapEvent(onMessageWrappers),
              onMessageExternal: wrapEvent(onMessageWrappers),
              sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                minArgs: 1,
                maxArgs: 3
              })
            },
            tabs: {
              sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                minArgs: 2,
                maxArgs: 3
              })
            }
          };
          const settingMetadata = {
            clear: {
              minArgs: 1,
              maxArgs: 1
            },
            get: {
              minArgs: 1,
              maxArgs: 1
            },
            set: {
              minArgs: 1,
              maxArgs: 1
            }
          };
          apiMetadata.privacy = {
            network: {
              "*": settingMetadata
            },
            services: {
              "*": settingMetadata
            },
            websites: {
              "*": settingMetadata
            }
          };
          return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
        };
        module2.exports = wrapAPIs(chrome);
      } else {
        module2.exports = globalThis.browser;
      }
    });
  }
});

// node_modules/preact/dist/preact.module.js
var n;
var l;
var u;
var t;
var i;
var o;
var r;
var e;
var f;
var c;
var s;
var a;
var h;
var p = {};
var v = [];
var y = /acit|ex(?:s|g|n|p|$)|rph|grid|ows|mnc|ntw|ine[ch]|zoo|^ord|itera/i;
var d = Array.isArray;
function w(n3, l5) {
  for (var u5 in l5) n3[u5] = l5[u5];
  return n3;
}
function g(n3) {
  n3 && n3.parentNode && n3.parentNode.removeChild(n3);
}
function _(l5, u5, t4) {
  var i4, o4, r4, e4 = {};
  for (r4 in u5) "key" == r4 ? i4 = u5[r4] : "ref" == r4 ? o4 = u5[r4] : e4[r4] = u5[r4];
  if (arguments.length > 2 && (e4.children = arguments.length > 3 ? n.call(arguments, 2) : t4), "function" == typeof l5 && null != l5.defaultProps) for (r4 in l5.defaultProps) void 0 === e4[r4] && (e4[r4] = l5.defaultProps[r4]);
  return m(l5, e4, i4, o4, null);
}
function m(n3, t4, i4, o4, r4) {
  var e4 = { type: n3, props: t4, key: i4, ref: o4, __k: null, __: null, __b: 0, __e: null, __c: null, constructor: void 0, __v: null == r4 ? ++u : r4, __i: -1, __u: 0 };
  return null == r4 && null != l.vnode && l.vnode(e4), e4;
}
function k(n3) {
  return n3.children;
}
function x(n3, l5) {
  this.props = n3, this.context = l5;
}
function S(n3, l5) {
  if (null == l5) return n3.__ ? S(n3.__, n3.__i + 1) : null;
  for (var u5; l5 < n3.__k.length; l5++) if (null != (u5 = n3.__k[l5]) && null != u5.__e) return u5.__e;
  return "function" == typeof n3.type ? S(n3) : null;
}
function C(n3) {
  var l5, u5;
  if (null != (n3 = n3.__) && null != n3.__c) {
    for (n3.__e = n3.__c.base = null, l5 = 0; l5 < n3.__k.length; l5++) if (null != (u5 = n3.__k[l5]) && null != u5.__e) {
      n3.__e = n3.__c.base = u5.__e;
      break;
    }
    return C(n3);
  }
}
function M(n3) {
  (!n3.__d && (n3.__d = true) && i.push(n3) && !$.__r++ || o != l.debounceRendering) && ((o = l.debounceRendering) || r)($);
}
function $() {
  for (var n3, u5, t4, o4, r4, f5, c4, s4 = 1; i.length; ) i.length > s4 && i.sort(e), n3 = i.shift(), s4 = i.length, n3.__d && (t4 = void 0, o4 = void 0, r4 = (o4 = (u5 = n3).__v).__e, f5 = [], c4 = [], u5.__P && ((t4 = w({}, o4)).__v = o4.__v + 1, l.vnode && l.vnode(t4), O(u5.__P, t4, o4, u5.__n, u5.__P.namespaceURI, 32 & o4.__u ? [r4] : null, f5, null == r4 ? S(o4) : r4, !!(32 & o4.__u), c4), t4.__v = o4.__v, t4.__.__k[t4.__i] = t4, N(f5, t4, c4), o4.__e = o4.__ = null, t4.__e != r4 && C(t4)));
  $.__r = 0;
}
function I(n3, l5, u5, t4, i4, o4, r4, e4, f5, c4, s4) {
  var a4, h5, y5, d4, w4, g4, _4, m4 = t4 && t4.__k || v, b3 = l5.length;
  for (f5 = P(u5, l5, m4, f5, b3), a4 = 0; a4 < b3; a4++) null != (y5 = u5.__k[a4]) && (h5 = -1 == y5.__i ? p : m4[y5.__i] || p, y5.__i = a4, g4 = O(n3, y5, h5, i4, o4, r4, e4, f5, c4, s4), d4 = y5.__e, y5.ref && h5.ref != y5.ref && (h5.ref && B(h5.ref, null, y5), s4.push(y5.ref, y5.__c || d4, y5)), null == w4 && null != d4 && (w4 = d4), (_4 = !!(4 & y5.__u)) || h5.__k === y5.__k ? f5 = A(y5, f5, n3, _4) : "function" == typeof y5.type && void 0 !== g4 ? f5 = g4 : d4 && (f5 = d4.nextSibling), y5.__u &= -7);
  return u5.__e = w4, f5;
}
function P(n3, l5, u5, t4, i4) {
  var o4, r4, e4, f5, c4, s4 = u5.length, a4 = s4, h5 = 0;
  for (n3.__k = new Array(i4), o4 = 0; o4 < i4; o4++) null != (r4 = l5[o4]) && "boolean" != typeof r4 && "function" != typeof r4 ? ("string" == typeof r4 || "number" == typeof r4 || "bigint" == typeof r4 || r4.constructor == String ? r4 = n3.__k[o4] = m(null, r4, null, null, null) : d(r4) ? r4 = n3.__k[o4] = m(k, { children: r4 }, null, null, null) : void 0 === r4.constructor && r4.__b > 0 ? r4 = n3.__k[o4] = m(r4.type, r4.props, r4.key, r4.ref ? r4.ref : null, r4.__v) : n3.__k[o4] = r4, f5 = o4 + h5, r4.__ = n3, r4.__b = n3.__b + 1, e4 = null, -1 != (c4 = r4.__i = L(r4, u5, f5, a4)) && (a4--, (e4 = u5[c4]) && (e4.__u |= 2)), null == e4 || null == e4.__v ? (-1 == c4 && (i4 > s4 ? h5-- : i4 < s4 && h5++), "function" != typeof r4.type && (r4.__u |= 4)) : c4 != f5 && (c4 == f5 - 1 ? h5-- : c4 == f5 + 1 ? h5++ : (c4 > f5 ? h5-- : h5++, r4.__u |= 4))) : n3.__k[o4] = null;
  if (a4) for (o4 = 0; o4 < s4; o4++) null != (e4 = u5[o4]) && 0 == (2 & e4.__u) && (e4.__e == t4 && (t4 = S(e4)), D(e4, e4));
  return t4;
}
function A(n3, l5, u5, t4) {
  var i4, o4;
  if ("function" == typeof n3.type) {
    for (i4 = n3.__k, o4 = 0; i4 && o4 < i4.length; o4++) i4[o4] && (i4[o4].__ = n3, l5 = A(i4[o4], l5, u5, t4));
    return l5;
  }
  n3.__e != l5 && (t4 && (l5 && n3.type && !l5.parentNode && (l5 = S(n3)), u5.insertBefore(n3.__e, l5 || null)), l5 = n3.__e);
  do {
    l5 = l5 && l5.nextSibling;
  } while (null != l5 && 8 == l5.nodeType);
  return l5;
}
function H(n3, l5) {
  return l5 = l5 || [], null == n3 || "boolean" == typeof n3 || (d(n3) ? n3.some(function(n4) {
    H(n4, l5);
  }) : l5.push(n3)), l5;
}
function L(n3, l5, u5, t4) {
  var i4, o4, r4, e4 = n3.key, f5 = n3.type, c4 = l5[u5], s4 = null != c4 && 0 == (2 & c4.__u);
  if (null === c4 && null == e4 || s4 && e4 == c4.key && f5 == c4.type) return u5;
  if (t4 > (s4 ? 1 : 0)) {
    for (i4 = u5 - 1, o4 = u5 + 1; i4 >= 0 || o4 < l5.length; ) if (null != (c4 = l5[r4 = i4 >= 0 ? i4-- : o4++]) && 0 == (2 & c4.__u) && e4 == c4.key && f5 == c4.type) return r4;
  }
  return -1;
}
function T(n3, l5, u5) {
  "-" == l5[0] ? n3.setProperty(l5, null == u5 ? "" : u5) : n3[l5] = null == u5 ? "" : "number" != typeof u5 || y.test(l5) ? u5 : u5 + "px";
}
function j(n3, l5, u5, t4, i4) {
  var o4, r4;
  n: if ("style" == l5) if ("string" == typeof u5) n3.style.cssText = u5;
  else {
    if ("string" == typeof t4 && (n3.style.cssText = t4 = ""), t4) for (l5 in t4) u5 && l5 in u5 || T(n3.style, l5, "");
    if (u5) for (l5 in u5) t4 && u5[l5] == t4[l5] || T(n3.style, l5, u5[l5]);
  }
  else if ("o" == l5[0] && "n" == l5[1]) o4 = l5 != (l5 = l5.replace(f, "$1")), r4 = l5.toLowerCase(), l5 = r4 in n3 || "onFocusOut" == l5 || "onFocusIn" == l5 ? r4.slice(2) : l5.slice(2), n3.l || (n3.l = {}), n3.l[l5 + o4] = u5, u5 ? t4 ? u5.u = t4.u : (u5.u = c, n3.addEventListener(l5, o4 ? a : s, o4)) : n3.removeEventListener(l5, o4 ? a : s, o4);
  else {
    if ("http://www.w3.org/2000/svg" == i4) l5 = l5.replace(/xlink(H|:h)/, "h").replace(/sName$/, "s");
    else if ("width" != l5 && "height" != l5 && "href" != l5 && "list" != l5 && "form" != l5 && "tabIndex" != l5 && "download" != l5 && "rowSpan" != l5 && "colSpan" != l5 && "role" != l5 && "popover" != l5 && l5 in n3) try {
      n3[l5] = null == u5 ? "" : u5;
      break n;
    } catch (n4) {
    }
    "function" == typeof u5 || (null == u5 || false === u5 && "-" != l5[4] ? n3.removeAttribute(l5) : n3.setAttribute(l5, "popover" == l5 && 1 == u5 ? "" : u5));
  }
}
function F(n3) {
  return function(u5) {
    if (this.l) {
      var t4 = this.l[u5.type + n3];
      if (null == u5.t) u5.t = c++;
      else if (u5.t < t4.u) return;
      return t4(l.event ? l.event(u5) : u5);
    }
  };
}
function O(n3, u5, t4, i4, o4, r4, e4, f5, c4, s4) {
  var a4, h5, p5, v4, y5, _4, m4, b3, S2, C3, M3, $2, P2, A4, H2, L2, T3, j3 = u5.type;
  if (void 0 !== u5.constructor) return null;
  128 & t4.__u && (c4 = !!(32 & t4.__u), r4 = [f5 = u5.__e = t4.__e]), (a4 = l.__b) && a4(u5);
  n: if ("function" == typeof j3) try {
    if (b3 = u5.props, S2 = "prototype" in j3 && j3.prototype.render, C3 = (a4 = j3.contextType) && i4[a4.__c], M3 = a4 ? C3 ? C3.props.value : a4.__ : i4, t4.__c ? m4 = (h5 = u5.__c = t4.__c).__ = h5.__E : (S2 ? u5.__c = h5 = new j3(b3, M3) : (u5.__c = h5 = new x(b3, M3), h5.constructor = j3, h5.render = E), C3 && C3.sub(h5), h5.state || (h5.state = {}), h5.__n = i4, p5 = h5.__d = true, h5.__h = [], h5._sb = []), S2 && null == h5.__s && (h5.__s = h5.state), S2 && null != j3.getDerivedStateFromProps && (h5.__s == h5.state && (h5.__s = w({}, h5.__s)), w(h5.__s, j3.getDerivedStateFromProps(b3, h5.__s))), v4 = h5.props, y5 = h5.state, h5.__v = u5, p5) S2 && null == j3.getDerivedStateFromProps && null != h5.componentWillMount && h5.componentWillMount(), S2 && null != h5.componentDidMount && h5.__h.push(h5.componentDidMount);
    else {
      if (S2 && null == j3.getDerivedStateFromProps && b3 !== v4 && null != h5.componentWillReceiveProps && h5.componentWillReceiveProps(b3, M3), u5.__v == t4.__v || !h5.__e && null != h5.shouldComponentUpdate && false === h5.shouldComponentUpdate(b3, h5.__s, M3)) {
        for (u5.__v != t4.__v && (h5.props = b3, h5.state = h5.__s, h5.__d = false), u5.__e = t4.__e, u5.__k = t4.__k, u5.__k.some(function(n4) {
          n4 && (n4.__ = u5);
        }), $2 = 0; $2 < h5._sb.length; $2++) h5.__h.push(h5._sb[$2]);
        h5._sb = [], h5.__h.length && e4.push(h5);
        break n;
      }
      null != h5.componentWillUpdate && h5.componentWillUpdate(b3, h5.__s, M3), S2 && null != h5.componentDidUpdate && h5.__h.push(function() {
        h5.componentDidUpdate(v4, y5, _4);
      });
    }
    if (h5.context = M3, h5.props = b3, h5.__P = n3, h5.__e = false, P2 = l.__r, A4 = 0, S2) {
      for (h5.state = h5.__s, h5.__d = false, P2 && P2(u5), a4 = h5.render(h5.props, h5.state, h5.context), H2 = 0; H2 < h5._sb.length; H2++) h5.__h.push(h5._sb[H2]);
      h5._sb = [];
    } else do {
      h5.__d = false, P2 && P2(u5), a4 = h5.render(h5.props, h5.state, h5.context), h5.state = h5.__s;
    } while (h5.__d && ++A4 < 25);
    h5.state = h5.__s, null != h5.getChildContext && (i4 = w(w({}, i4), h5.getChildContext())), S2 && !p5 && null != h5.getSnapshotBeforeUpdate && (_4 = h5.getSnapshotBeforeUpdate(v4, y5)), L2 = a4, null != a4 && a4.type === k && null == a4.key && (L2 = V(a4.props.children)), f5 = I(n3, d(L2) ? L2 : [L2], u5, t4, i4, o4, r4, e4, f5, c4, s4), h5.base = u5.__e, u5.__u &= -161, h5.__h.length && e4.push(h5), m4 && (h5.__E = h5.__ = null);
  } catch (n4) {
    if (u5.__v = null, c4 || null != r4) if (n4.then) {
      for (u5.__u |= c4 ? 160 : 128; f5 && 8 == f5.nodeType && f5.nextSibling; ) f5 = f5.nextSibling;
      r4[r4.indexOf(f5)] = null, u5.__e = f5;
    } else {
      for (T3 = r4.length; T3--; ) g(r4[T3]);
      z(u5);
    }
    else u5.__e = t4.__e, u5.__k = t4.__k, n4.then || z(u5);
    l.__e(n4, u5, t4);
  }
  else null == r4 && u5.__v == t4.__v ? (u5.__k = t4.__k, u5.__e = t4.__e) : f5 = u5.__e = q(t4.__e, u5, t4, i4, o4, r4, e4, c4, s4);
  return (a4 = l.diffed) && a4(u5), 128 & u5.__u ? void 0 : f5;
}
function z(n3) {
  n3 && n3.__c && (n3.__c.__e = true), n3 && n3.__k && n3.__k.forEach(z);
}
function N(n3, u5, t4) {
  for (var i4 = 0; i4 < t4.length; i4++) B(t4[i4], t4[++i4], t4[++i4]);
  l.__c && l.__c(u5, n3), n3.some(function(u6) {
    try {
      n3 = u6.__h, u6.__h = [], n3.some(function(n4) {
        n4.call(u6);
      });
    } catch (n4) {
      l.__e(n4, u6.__v);
    }
  });
}
function V(n3) {
  return "object" != typeof n3 || null == n3 || n3.__b && n3.__b > 0 ? n3 : d(n3) ? n3.map(V) : w({}, n3);
}
function q(u5, t4, i4, o4, r4, e4, f5, c4, s4) {
  var a4, h5, v4, y5, w4, _4, m4, b3 = i4.props || p, k4 = t4.props, x2 = t4.type;
  if ("svg" == x2 ? r4 = "http://www.w3.org/2000/svg" : "math" == x2 ? r4 = "http://www.w3.org/1998/Math/MathML" : r4 || (r4 = "http://www.w3.org/1999/xhtml"), null != e4) {
    for (a4 = 0; a4 < e4.length; a4++) if ((w4 = e4[a4]) && "setAttribute" in w4 == !!x2 && (x2 ? w4.localName == x2 : 3 == w4.nodeType)) {
      u5 = w4, e4[a4] = null;
      break;
    }
  }
  if (null == u5) {
    if (null == x2) return document.createTextNode(k4);
    u5 = document.createElementNS(r4, x2, k4.is && k4), c4 && (l.__m && l.__m(t4, e4), c4 = false), e4 = null;
  }
  if (null == x2) b3 === k4 || c4 && u5.data == k4 || (u5.data = k4);
  else {
    if (e4 = e4 && n.call(u5.childNodes), !c4 && null != e4) for (b3 = {}, a4 = 0; a4 < u5.attributes.length; a4++) b3[(w4 = u5.attributes[a4]).name] = w4.value;
    for (a4 in b3) if (w4 = b3[a4], "children" == a4) ;
    else if ("dangerouslySetInnerHTML" == a4) v4 = w4;
    else if (!(a4 in k4)) {
      if ("value" == a4 && "defaultValue" in k4 || "checked" == a4 && "defaultChecked" in k4) continue;
      j(u5, a4, null, w4, r4);
    }
    for (a4 in k4) w4 = k4[a4], "children" == a4 ? y5 = w4 : "dangerouslySetInnerHTML" == a4 ? h5 = w4 : "value" == a4 ? _4 = w4 : "checked" == a4 ? m4 = w4 : c4 && "function" != typeof w4 || b3[a4] === w4 || j(u5, a4, w4, b3[a4], r4);
    if (h5) c4 || v4 && (h5.__html == v4.__html || h5.__html == u5.innerHTML) || (u5.innerHTML = h5.__html), t4.__k = [];
    else if (v4 && (u5.innerHTML = ""), I("template" == t4.type ? u5.content : u5, d(y5) ? y5 : [y5], t4, i4, o4, "foreignObject" == x2 ? "http://www.w3.org/1999/xhtml" : r4, e4, f5, e4 ? e4[0] : i4.__k && S(i4, 0), c4, s4), null != e4) for (a4 = e4.length; a4--; ) g(e4[a4]);
    c4 || (a4 = "value", "progress" == x2 && null == _4 ? u5.removeAttribute("value") : null != _4 && (_4 !== u5[a4] || "progress" == x2 && !_4 || "option" == x2 && _4 != b3[a4]) && j(u5, a4, _4, b3[a4], r4), a4 = "checked", null != m4 && m4 != u5[a4] && j(u5, a4, m4, b3[a4], r4));
  }
  return u5;
}
function B(n3, u5, t4) {
  try {
    if ("function" == typeof n3) {
      var i4 = "function" == typeof n3.__u;
      i4 && n3.__u(), i4 && null == u5 || (n3.__u = n3(u5));
    } else n3.current = u5;
  } catch (n4) {
    l.__e(n4, t4);
  }
}
function D(n3, u5, t4) {
  var i4, o4;
  if (l.unmount && l.unmount(n3), (i4 = n3.ref) && (i4.current && i4.current != n3.__e || B(i4, null, u5)), null != (i4 = n3.__c)) {
    if (i4.componentWillUnmount) try {
      i4.componentWillUnmount();
    } catch (n4) {
      l.__e(n4, u5);
    }
    i4.base = i4.__P = null;
  }
  if (i4 = n3.__k) for (o4 = 0; o4 < i4.length; o4++) i4[o4] && D(i4[o4], u5, t4 || "function" != typeof n3.type);
  t4 || g(n3.__e), n3.__c = n3.__ = n3.__e = void 0;
}
function E(n3, l5, u5) {
  return this.constructor(n3, u5);
}
function G(u5, t4, i4) {
  var o4, r4, e4, f5;
  t4 == document && (t4 = document.documentElement), l.__ && l.__(u5, t4), r4 = (o4 = "function" == typeof i4) ? null : i4 && i4.__k || t4.__k, e4 = [], f5 = [], O(t4, u5 = (!o4 && i4 || t4).__k = _(k, null, [u5]), r4 || p, p, t4.namespaceURI, !o4 && i4 ? [i4] : r4 ? null : t4.firstChild ? n.call(t4.childNodes) : null, e4, !o4 && i4 ? i4 : r4 ? r4.__e : t4.firstChild, o4, f5), N(e4, u5, f5);
}
n = v.slice, l = { __e: function(n3, l5, u5, t4) {
  for (var i4, o4, r4; l5 = l5.__; ) if ((i4 = l5.__c) && !i4.__) try {
    if ((o4 = i4.constructor) && null != o4.getDerivedStateFromError && (i4.setState(o4.getDerivedStateFromError(n3)), r4 = i4.__d), null != i4.componentDidCatch && (i4.componentDidCatch(n3, t4 || {}), r4 = i4.__d), r4) return i4.__E = i4;
  } catch (l6) {
    n3 = l6;
  }
  throw n3;
} }, u = 0, t = function(n3) {
  return null != n3 && void 0 === n3.constructor;
}, x.prototype.setState = function(n3, l5) {
  var u5;
  u5 = null != this.__s && this.__s != this.state ? this.__s : this.__s = w({}, this.state), "function" == typeof n3 && (n3 = n3(w({}, u5), this.props)), n3 && w(u5, n3), null != n3 && this.__v && (l5 && this._sb.push(l5), M(this));
}, x.prototype.forceUpdate = function(n3) {
  this.__v && (this.__e = true, n3 && this.__h.push(n3), M(this));
}, x.prototype.render = k, i = [], r = "function" == typeof Promise ? Promise.prototype.then.bind(Promise.resolve()) : setTimeout, e = function(n3, l5) {
  return n3.__v.__b - l5.__v.__b;
}, $.__r = 0, f = /(PointerCapture)$|Capture$/i, c = 0, s = F(false), a = F(true), h = 0;

// node_modules/preact/hooks/dist/hooks.module.js
var t2;
var r2;
var u2;
var i2;
var o2 = 0;
var f2 = [];
var c2 = l;
var e2 = c2.__b;
var a2 = c2.__r;
var v2 = c2.diffed;
var l2 = c2.__c;
var m2 = c2.unmount;
var s2 = c2.__;
function p2(n3, t4) {
  c2.__h && c2.__h(r2, n3, o2 || t4), o2 = 0;
  var u5 = r2.__H || (r2.__H = { __: [], __h: [] });
  return n3 >= u5.__.length && u5.__.push({}), u5.__[n3];
}
function d2(n3) {
  return o2 = 1, h2(D2, n3);
}
function h2(n3, u5, i4) {
  var o4 = p2(t2++, 2);
  if (o4.t = n3, !o4.__c && (o4.__ = [i4 ? i4(u5) : D2(void 0, u5), function(n4) {
    var t4 = o4.__N ? o4.__N[0] : o4.__[0], r4 = o4.t(t4, n4);
    t4 !== r4 && (o4.__N = [r4, o4.__[1]], o4.__c.setState({}));
  }], o4.__c = r2, !r2.__f)) {
    var f5 = function(n4, t4, r4) {
      if (!o4.__c.__H) return true;
      var u6 = o4.__c.__H.__.filter(function(n5) {
        return !!n5.__c;
      });
      if (u6.every(function(n5) {
        return !n5.__N;
      })) return !c4 || c4.call(this, n4, t4, r4);
      var i5 = o4.__c.props !== n4;
      return u6.forEach(function(n5) {
        if (n5.__N) {
          var t5 = n5.__[0];
          n5.__ = n5.__N, n5.__N = void 0, t5 !== n5.__[0] && (i5 = true);
        }
      }), c4 && c4.call(this, n4, t4, r4) || i5;
    };
    r2.__f = true;
    var c4 = r2.shouldComponentUpdate, e4 = r2.componentWillUpdate;
    r2.componentWillUpdate = function(n4, t4, r4) {
      if (this.__e) {
        var u6 = c4;
        c4 = void 0, f5(n4, t4, r4), c4 = u6;
      }
      e4 && e4.call(this, n4, t4, r4);
    }, r2.shouldComponentUpdate = f5;
  }
  return o4.__N || o4.__;
}
function y2(n3, u5) {
  var i4 = p2(t2++, 3);
  !c2.__s && C2(i4.__H, u5) && (i4.__ = n3, i4.u = u5, r2.__H.__h.push(i4));
}
function T2(n3, r4) {
  var u5 = p2(t2++, 7);
  return C2(u5.__H, r4) && (u5.__ = n3(), u5.__H = r4, u5.__h = n3), u5.__;
}
function q2(n3, t4) {
  return o2 = 8, T2(function() {
    return n3;
  }, t4);
}
function j2() {
  for (var n3; n3 = f2.shift(); ) if (n3.__P && n3.__H) try {
    n3.__H.__h.forEach(z2), n3.__H.__h.forEach(B2), n3.__H.__h = [];
  } catch (t4) {
    n3.__H.__h = [], c2.__e(t4, n3.__v);
  }
}
c2.__b = function(n3) {
  r2 = null, e2 && e2(n3);
}, c2.__ = function(n3, t4) {
  n3 && t4.__k && t4.__k.__m && (n3.__m = t4.__k.__m), s2 && s2(n3, t4);
}, c2.__r = function(n3) {
  a2 && a2(n3), t2 = 0;
  var i4 = (r2 = n3.__c).__H;
  i4 && (u2 === r2 ? (i4.__h = [], r2.__h = [], i4.__.forEach(function(n4) {
    n4.__N && (n4.__ = n4.__N), n4.u = n4.__N = void 0;
  })) : (i4.__h.forEach(z2), i4.__h.forEach(B2), i4.__h = [], t2 = 0)), u2 = r2;
}, c2.diffed = function(n3) {
  v2 && v2(n3);
  var t4 = n3.__c;
  t4 && t4.__H && (t4.__H.__h.length && (1 !== f2.push(t4) && i2 === c2.requestAnimationFrame || ((i2 = c2.requestAnimationFrame) || w2)(j2)), t4.__H.__.forEach(function(n4) {
    n4.u && (n4.__H = n4.u), n4.u = void 0;
  })), u2 = r2 = null;
}, c2.__c = function(n3, t4) {
  t4.some(function(n4) {
    try {
      n4.__h.forEach(z2), n4.__h = n4.__h.filter(function(n5) {
        return !n5.__ || B2(n5);
      });
    } catch (r4) {
      t4.some(function(n5) {
        n5.__h && (n5.__h = []);
      }), t4 = [], c2.__e(r4, n4.__v);
    }
  }), l2 && l2(n3, t4);
}, c2.unmount = function(n3) {
  m2 && m2(n3);
  var t4, r4 = n3.__c;
  r4 && r4.__H && (r4.__H.__.forEach(function(n4) {
    try {
      z2(n4);
    } catch (n5) {
      t4 = n5;
    }
  }), r4.__H = void 0, t4 && c2.__e(t4, r4.__v));
};
var k2 = "function" == typeof requestAnimationFrame;
function w2(n3) {
  var t4, r4 = function() {
    clearTimeout(u5), k2 && cancelAnimationFrame(t4), setTimeout(n3);
  }, u5 = setTimeout(r4, 35);
  k2 && (t4 = requestAnimationFrame(r4));
}
function z2(n3) {
  var t4 = r2, u5 = n3.__c;
  "function" == typeof u5 && (n3.__c = void 0, u5()), r2 = t4;
}
function B2(n3) {
  var t4 = r2;
  n3.__c = n3.__(), r2 = t4;
}
function C2(n3, t4) {
  return !n3 || n3.length !== t4.length || t4.some(function(t5, r4) {
    return t5 !== n3[r4];
  });
}
function D2(n3, t4) {
  return "function" == typeof t4 ? t4(n3) : t4;
}

// src/browser.ts
var import_webextension_polyfill = __toESM(require_browser_polyfill(), 1);
var browser_default = import_webextension_polyfill.default;

// src/types.ts
var DEFAULT_OPTIONS = {
  defaultDuration: 864e5,
  // 24 hours
  quickBlockDuration: 36e5,
  // 1 hour
  notificationsEnabled: true,
  notificationSound: false,
  checkInterval: 1,
  theme: "auto",
  // Post context defaults
  savePostContext: true,
  postContextRetentionDays: 0,
  // 0 = forever
  // Amnesty defaults
  forgivenessPeriodDays: 90,
  // 3 months
  // Last Word defaults
  lastWordMuteEnabled: true,
  // Mute during delay by default
  lastWordDelaySeconds: 60
  // 60 second delay by default
};
var DEFAULT_MASS_OPS_SETTINGS = {
  timeWindowMinutes: 5,
  minOperationCount: 10
};

// src/utils.ts
var LOG_LEVEL_PRIORITY = {
  debug: 0,
  info: 1,
  warn: 2,
  error: 3
};
var currentLogLevel = "info";
var logger = {
  debug: (message, ...args) => {
    if (LOG_LEVEL_PRIORITY[currentLogLevel] <= LOG_LEVEL_PRIORITY.debug) {
      console.debug(`[ErgoBlock] ${message}`, ...args);
    }
  },
  info: (message, ...args) => {
    if (LOG_LEVEL_PRIORITY[currentLogLevel] <= LOG_LEVEL_PRIORITY.info) {
      console.log(`[ErgoBlock] ${message}`, ...args);
    }
  },
  warn: (message, ...args) => {
    if (LOG_LEVEL_PRIORITY[currentLogLevel] <= LOG_LEVEL_PRIORITY.warn) {
      console.warn(`[ErgoBlock] ${message}`, ...args);
    }
  },
  error: (message, ...args) => {
    if (LOG_LEVEL_PRIORITY[currentLogLevel] <= LOG_LEVEL_PRIORITY.error) {
      console.error(`[ErgoBlock] ${message}`, ...args);
    }
  }
};
var RateLimiter = class {
  constructor(options2 = {}) {
    this.lastActionTime = 0;
    this.actionCount = 0;
    this.windowMs = options2.windowMs ?? 1e4;
    this.maxActions = options2.maxActions ?? 5;
    this.cooldownMs = options2.cooldownMs ?? 2e3;
  }
  /**
   * Check if an action is allowed
   * @returns true if allowed, false if rate limited
   */
  canPerformAction() {
    const now = Date.now();
    if (now - this.lastActionTime > this.windowMs) {
      this.actionCount = 0;
    }
    if (now - this.lastActionTime < this.cooldownMs) {
      return false;
    }
    if (this.actionCount >= this.maxActions) {
      return false;
    }
    return true;
  }
  /**
   * Record an action
   */
  recordAction() {
    const now = Date.now();
    if (now - this.lastActionTime > this.windowMs) {
      this.actionCount = 0;
    }
    this.lastActionTime = now;
    this.actionCount++;
  }
  /**
   * Get time until next action is allowed (in ms)
   */
  getWaitTime() {
    const now = Date.now();
    const cooldownRemaining = Math.max(0, this.cooldownMs - (now - this.lastActionTime));
    if (this.actionCount >= this.maxActions) {
      const windowRemaining = Math.max(0, this.windowMs - (now - this.lastActionTime));
      return Math.max(cooldownRemaining, windowRemaining);
    }
    return cooldownRemaining;
  }
};
var actionRateLimiter = new RateLimiter({
  windowMs: 1e4,
  // 10 seconds
  maxActions: 5,
  // Max 5 blocks/mutes per 10 seconds
  cooldownMs: 1e3
  // 1 second minimum between actions
});
var CircuitBreaker = class {
  constructor(options2 = {}) {
    this.state = "closed";
    this.failures = 0;
    this.lastFailureTime = 0;
    this.successesSinceHalfOpen = 0;
    this.failureThreshold = options2.failureThreshold ?? 5;
    this.resetTimeoutMs = options2.resetTimeoutMs ?? 6e4;
    this.halfOpenSuccessThreshold = options2.halfOpenSuccessThreshold ?? 2;
  }
  /**
   * Get current circuit state
   */
  getState() {
    this.updateState();
    return this.state;
  }
  /**
   * Check if circuit allows requests
   */
  isAllowed() {
    this.updateState();
    return this.state !== "open";
  }
  /**
   * Record a successful operation
   */
  recordSuccess() {
    this.updateState();
    if (this.state === "half-open") {
      this.successesSinceHalfOpen++;
      if (this.successesSinceHalfOpen >= this.halfOpenSuccessThreshold) {
        this.reset();
      }
    } else if (this.state === "closed") {
      this.failures = Math.max(0, this.failures - 1);
    }
  }
  /**
   * Record a failed operation
   */
  recordFailure() {
    this.updateState();
    if (this.state === "half-open") {
      this.trip();
    } else if (this.state === "closed") {
      this.failures++;
      this.lastFailureTime = Date.now();
      if (this.failures >= this.failureThreshold) {
        this.trip();
      }
    }
  }
  /**
   * Manually reset the circuit
   */
  reset() {
    this.state = "closed";
    this.failures = 0;
    this.successesSinceHalfOpen = 0;
    logger.info("Circuit breaker reset to closed");
  }
  trip() {
    this.state = "open";
    this.lastFailureTime = Date.now();
    logger.warn(`Circuit breaker opened after ${this.failures} failures`);
  }
  updateState() {
    if (this.state === "open") {
      const now = Date.now();
      if (now - this.lastFailureTime >= this.resetTimeoutMs) {
        this.state = "half-open";
        this.successesSinceHalfOpen = 0;
        logger.info("Circuit breaker entering half-open state");
      }
    }
  }
};
var apiCircuitBreaker = new CircuitBreaker({
  failureThreshold: 5,
  resetTimeoutMs: 6e4,
  // 1 minute
  halfOpenSuccessThreshold: 2
});

// src/storage.ts
var STORAGE_KEYS = {
  TEMP_BLOCKS: "tempBlocks",
  TEMP_MUTES: "tempMutes",
  OPTIONS: "extensionOptions",
  ACTION_HISTORY: "actionHistory",
  LAST_TAB: "lastActiveTab",
  POST_CONTEXTS: "postContexts",
  // New keys for full manager
  PERMANENT_BLOCKS: "permanentBlocks",
  PERMANENT_MUTES: "permanentMutes",
  SYNC_STATE: "syncState",
  // Amnesty feature
  AMNESTY_REVIEWS: "amnestyReviews",
  // Blocklist audit feature
  BLOCKLIST_AUDIT_STATE: "blocklistAuditState",
  SUBSCRIBED_BLOCKLISTS: "subscribedBlocklists",
  SOCIAL_GRAPH: "socialGraph",
  BLOCKLIST_CONFLICTS: "blocklistConflicts",
  DISMISSED_CONFLICTS: "dismissedConflicts",
  // Repost filtering feature
  REPOST_FILTERED_USERS: "repostFilteredUsers",
  // Lightweight follows list (just handles, for repost filter feature)
  FOLLOWS_HANDLES: "followsHandles",
  // List audit feature
  LIST_AUDIT_REVIEWS: "listAuditReviews",
  // Mass operations detection feature
  MASS_OPS_SCAN_RESULT: "massOpsScanResult",
  MASS_OPS_SETTINGS: "massOpsSettings",
  MASS_OPS_DISMISSED_CLUSTERS: "massOpsDismissedClusters",
  // CAR download progress (for UI updates)
  CAR_DOWNLOAD_PROGRESS: "carDownloadProgress",
  // Pending delayed blocks (Last Word feature)
  PENDING_DELAYED_BLOCKS: "pendingDelayedBlocks"
};
var DEFAULT_DURATION_MS = 24 * 60 * 60 * 1e3;
async function getTempBlocks() {
  const result = await browser_default.storage.sync.get(STORAGE_KEYS.TEMP_BLOCKS);
  return result[STORAGE_KEYS.TEMP_BLOCKS] || {};
}
async function getTempMutes() {
  const result = await browser_default.storage.sync.get(STORAGE_KEYS.TEMP_MUTES);
  return result[STORAGE_KEYS.TEMP_MUTES] || {};
}
async function removeTempBlock(did) {
  const blocks2 = await getTempBlocks();
  delete blocks2[did];
  await browser_default.storage.sync.set({ [STORAGE_KEYS.TEMP_BLOCKS]: blocks2 });
}
async function removeTempMute(did) {
  const mutes2 = await getTempMutes();
  delete mutes2[did];
  await browser_default.storage.sync.set({ [STORAGE_KEYS.TEMP_MUTES]: mutes2 });
}
async function getOptions() {
  const result = await browser_default.storage.local.get(STORAGE_KEYS.OPTIONS);
  const stored = result[STORAGE_KEYS.OPTIONS];
  if (!stored) {
    return DEFAULT_OPTIONS;
  }
  return {
    ...DEFAULT_OPTIONS,
    ...stored
  };
}
async function setOptions(options2) {
  await browser_default.storage.local.set({ [STORAGE_KEYS.OPTIONS]: options2 });
}
async function getPostContexts() {
  const result = await browser_default.storage.local.get(STORAGE_KEYS.POST_CONTEXTS);
  return result[STORAGE_KEYS.POST_CONTEXTS] || [];
}
async function getPermanentBlocks() {
  const result = await browser_default.storage.local.get(STORAGE_KEYS.PERMANENT_BLOCKS);
  return result[STORAGE_KEYS.PERMANENT_BLOCKS] || {};
}
async function getPermanentMutes() {
  const result = await browser_default.storage.local.get(STORAGE_KEYS.PERMANENT_MUTES);
  return result[STORAGE_KEYS.PERMANENT_MUTES] || {};
}
async function removePermanentBlock(did) {
  const blocks2 = await getPermanentBlocks();
  delete blocks2[did];
  await browser_default.storage.local.set({ [STORAGE_KEYS.PERMANENT_BLOCKS]: blocks2 });
}
async function removePermanentMute(did) {
  const mutes2 = await getPermanentMutes();
  delete mutes2[did];
  await browser_default.storage.local.set({ [STORAGE_KEYS.PERMANENT_MUTES]: mutes2 });
}
var DEFAULT_SYNC_STATE = {
  lastBlockSync: 0,
  lastMuteSync: 0,
  syncInProgress: false
};
async function getSyncState() {
  const result = await browser_default.storage.local.get(STORAGE_KEYS.SYNC_STATE);
  return result[STORAGE_KEYS.SYNC_STATE] || DEFAULT_SYNC_STATE;
}
async function getAllManagedBlocks() {
  const [tempBlocks, permanentBlocks] = await Promise.all([getTempBlocks(), getPermanentBlocks()]);
  const entries = [];
  for (const [did, data] of Object.entries(tempBlocks)) {
    entries.push({
      did,
      handle: data.handle,
      source: "ergoblock_temp",
      type: "block",
      expiresAt: data.expiresAt,
      createdAt: data.createdAt,
      rkey: data.rkey
    });
  }
  for (const [did, data] of Object.entries(permanentBlocks)) {
    if (!tempBlocks[did]) {
      entries.push({
        did,
        handle: data.handle,
        displayName: data.displayName,
        avatar: data.avatar,
        source: "bluesky",
        type: "block",
        syncedAt: data.syncedAt,
        createdAt: data.createdAt,
        rkey: data.rkey,
        mutualBlock: data.mutualBlock,
        viewer: data.viewer
      });
    }
  }
  entries.sort((a4, b3) => {
    const dateA = a4.createdAt || a4.syncedAt || 0;
    const dateB = b3.createdAt || b3.syncedAt || 0;
    return dateB - dateA;
  });
  return entries;
}
async function getAllManagedMutes() {
  const [tempMutes, permanentMutes] = await Promise.all([getTempMutes(), getPermanentMutes()]);
  const entries = [];
  for (const [did, data] of Object.entries(tempMutes)) {
    entries.push({
      did,
      handle: data.handle,
      source: "ergoblock_temp",
      type: "mute",
      expiresAt: data.expiresAt,
      createdAt: data.createdAt
    });
  }
  for (const [did, data] of Object.entries(permanentMutes)) {
    if (!tempMutes[did]) {
      entries.push({
        did,
        handle: data.handle,
        displayName: data.displayName,
        avatar: data.avatar,
        source: "bluesky",
        type: "mute",
        syncedAt: data.syncedAt,
        viewer: data.viewer
      });
    }
  }
  entries.sort((a4, b3) => {
    const dateA = a4.createdAt || a4.syncedAt || 0;
    const dateB = b3.createdAt || b3.syncedAt || 0;
    return dateB - dateA;
  });
  return entries;
}
async function getAmnestyReviews() {
  const localResult = await browser_default.storage.local.get(STORAGE_KEYS.AMNESTY_REVIEWS);
  if (localResult[STORAGE_KEYS.AMNESTY_REVIEWS]) {
    return localResult[STORAGE_KEYS.AMNESTY_REVIEWS];
  }
  const syncResult = await browser_default.storage.sync.get(STORAGE_KEYS.AMNESTY_REVIEWS);
  const syncReviews = syncResult[STORAGE_KEYS.AMNESTY_REVIEWS] || [];
  if (syncReviews.length > 0) {
    await browser_default.storage.local.set({ [STORAGE_KEYS.AMNESTY_REVIEWS]: syncReviews });
    await browser_default.storage.sync.remove(STORAGE_KEYS.AMNESTY_REVIEWS);
  }
  return syncReviews;
}
async function getAmnestyReviewedDids() {
  const reviews = await getAmnestyReviews();
  return new Set(reviews.map((r4) => r4.did));
}
async function addAmnestyReview(review) {
  const reviews = await getAmnestyReviews();
  const filtered = reviews.filter((r4) => r4.did !== review.did);
  filtered.push(review);
  await browser_default.storage.local.set({ [STORAGE_KEYS.AMNESTY_REVIEWS]: filtered });
}
async function getAmnestyStats() {
  const reviews = await getAmnestyReviews();
  return {
    totalReviewed: reviews.length,
    unblocked: reviews.filter((r4) => r4.decision === "unblocked").length,
    keptBlocked: reviews.filter((r4) => r4.decision === "kept_blocked").length,
    unmuted: reviews.filter((r4) => r4.decision === "unmuted").length,
    keptMuted: reviews.filter((r4) => r4.decision === "kept_muted").length
  };
}
var DEFAULT_AUDIT_STATE = {
  lastSyncAt: 0,
  syncInProgress: false,
  followCount: 0,
  followerCount: 0,
  blocklistCount: 0,
  conflictCount: 0
};
async function getBlocklistAuditState() {
  const result = await browser_default.storage.local.get(STORAGE_KEYS.BLOCKLIST_AUDIT_STATE);
  return result[STORAGE_KEYS.BLOCKLIST_AUDIT_STATE] || DEFAULT_AUDIT_STATE;
}
async function getBlocklistConflicts() {
  const result = await browser_default.storage.local.get(STORAGE_KEYS.BLOCKLIST_CONFLICTS);
  return result[STORAGE_KEYS.BLOCKLIST_CONFLICTS] || [];
}
async function getDismissedConflicts() {
  const result = await browser_default.storage.local.get(STORAGE_KEYS.DISMISSED_CONFLICTS);
  const dismissed = result[STORAGE_KEYS.DISMISSED_CONFLICTS] || [];
  return new Set(dismissed);
}
async function dismissBlocklistConflicts(listUri) {
  const dismissed = await getDismissedConflicts();
  dismissed.add(listUri);
  await browser_default.storage.local.set({
    [STORAGE_KEYS.DISMISSED_CONFLICTS]: Array.from(dismissed)
  });
}
async function undismissBlocklistConflicts(listUri) {
  const dismissed = await getDismissedConflicts();
  dismissed.delete(listUri);
  await browser_default.storage.local.set({
    [STORAGE_KEYS.DISMISSED_CONFLICTS]: Array.from(dismissed)
  });
}
async function getRepostFilteredUsers() {
  const result = await browser_default.storage.local.get(STORAGE_KEYS.REPOST_FILTERED_USERS);
  return result[STORAGE_KEYS.REPOST_FILTERED_USERS] || {};
}
async function addRepostFilteredUser(user) {
  const users = await getRepostFilteredUsers();
  users[user.did] = user;
  await browser_default.storage.local.set({ [STORAGE_KEYS.REPOST_FILTERED_USERS]: users });
}
async function removeRepostFilteredUser(did) {
  const users = await getRepostFilteredUsers();
  delete users[did];
  await browser_default.storage.local.set({ [STORAGE_KEYS.REPOST_FILTERED_USERS]: users });
}
async function getRepostFilteredUsersArray() {
  const users = await getRepostFilteredUsers();
  return Object.values(users).sort((a4, b3) => b3.addedAt - a4.addedAt);
}
async function getListAuditReviews() {
  const result = await browser_default.storage.local.get(STORAGE_KEYS.LIST_AUDIT_REVIEWS);
  return result[STORAGE_KEYS.LIST_AUDIT_REVIEWS] || [];
}
async function addListAuditReview(review) {
  const reviews = await getListAuditReviews();
  const filtered = reviews.filter((r4) => !(r4.did === review.did && r4.listUri === review.listUri));
  filtered.push(review);
  await browser_default.storage.local.set({ [STORAGE_KEYS.LIST_AUDIT_REVIEWS]: filtered });
}
async function getListAuditReviewedDids(listUri) {
  const reviews = await getListAuditReviews();
  const dids = reviews.filter((r4) => r4.listUri === listUri).map((r4) => r4.did);
  return new Set(dids);
}
async function getListAuditStats(listUri) {
  const reviews = await getListAuditReviews();
  const listReviews = reviews.filter((r4) => r4.listUri === listUri);
  return {
    reviewed: listReviews.length,
    removed: listReviews.filter((r4) => r4.decision === "removed").length,
    kept: listReviews.filter((r4) => r4.decision === "kept").length
  };
}
async function getMassOpsScanResult() {
  const result = await browser_default.storage.local.get(STORAGE_KEYS.MASS_OPS_SCAN_RESULT);
  return result[STORAGE_KEYS.MASS_OPS_SCAN_RESULT] || null;
}
async function setMassOpsSettings(settings) {
  await browser_default.storage.sync.set({ [STORAGE_KEYS.MASS_OPS_SETTINGS]: settings });
}

// node_modules/@preact/signals-core/dist/signals-core.module.js
var i3 = /* @__PURE__ */ Symbol.for("preact-signals");
function t3() {
  if (!(s3 > 1)) {
    var i4, t4 = false;
    while (void 0 !== h3) {
      var r4 = h3;
      h3 = void 0;
      f3++;
      while (void 0 !== r4) {
        var o4 = r4.o;
        r4.o = void 0;
        r4.f &= -3;
        if (!(8 & r4.f) && c3(r4)) try {
          r4.c();
        } catch (r5) {
          if (!t4) {
            i4 = r5;
            t4 = true;
          }
        }
        r4 = o4;
      }
    }
    f3 = 0;
    s3--;
    if (t4) throw i4;
  } else s3--;
}
function r3(i4) {
  if (s3 > 0) return i4();
  s3++;
  try {
    return i4();
  } finally {
    t3();
  }
}
var o3 = void 0;
function n2(i4) {
  var t4 = o3;
  o3 = void 0;
  try {
    return i4();
  } finally {
    o3 = t4;
  }
}
var h3 = void 0;
var s3 = 0;
var f3 = 0;
var v3 = 0;
function e3(i4) {
  if (void 0 !== o3) {
    var t4 = i4.n;
    if (void 0 === t4 || t4.t !== o3) {
      t4 = { i: 0, S: i4, p: o3.s, n: void 0, t: o3, e: void 0, x: void 0, r: t4 };
      if (void 0 !== o3.s) o3.s.n = t4;
      o3.s = t4;
      i4.n = t4;
      if (32 & o3.f) i4.S(t4);
      return t4;
    } else if (-1 === t4.i) {
      t4.i = 0;
      if (void 0 !== t4.n) {
        t4.n.p = t4.p;
        if (void 0 !== t4.p) t4.p.n = t4.n;
        t4.p = o3.s;
        t4.n = void 0;
        o3.s.n = t4;
        o3.s = t4;
      }
      return t4;
    }
  }
}
function u3(i4, t4) {
  this.v = i4;
  this.i = 0;
  this.n = void 0;
  this.t = void 0;
  this.W = null == t4 ? void 0 : t4.watched;
  this.Z = null == t4 ? void 0 : t4.unwatched;
  this.name = null == t4 ? void 0 : t4.name;
}
u3.prototype.brand = i3;
u3.prototype.h = function() {
  return true;
};
u3.prototype.S = function(i4) {
  var t4 = this, r4 = this.t;
  if (r4 !== i4 && void 0 === i4.e) {
    i4.x = r4;
    this.t = i4;
    if (void 0 !== r4) r4.e = i4;
    else n2(function() {
      var i5;
      null == (i5 = t4.W) || i5.call(t4);
    });
  }
};
u3.prototype.U = function(i4) {
  var t4 = this;
  if (void 0 !== this.t) {
    var r4 = i4.e, o4 = i4.x;
    if (void 0 !== r4) {
      r4.x = o4;
      i4.e = void 0;
    }
    if (void 0 !== o4) {
      o4.e = r4;
      i4.x = void 0;
    }
    if (i4 === this.t) {
      this.t = o4;
      if (void 0 === o4) n2(function() {
        var i5;
        null == (i5 = t4.Z) || i5.call(t4);
      });
    }
  }
};
u3.prototype.subscribe = function(i4) {
  var t4 = this;
  return E2(function() {
    var r4 = t4.value, n3 = o3;
    o3 = void 0;
    try {
      i4(r4);
    } finally {
      o3 = n3;
    }
  }, { name: "sub" });
};
u3.prototype.valueOf = function() {
  return this.value;
};
u3.prototype.toString = function() {
  return this.value + "";
};
u3.prototype.toJSON = function() {
  return this.value;
};
u3.prototype.peek = function() {
  var i4 = o3;
  o3 = void 0;
  try {
    return this.value;
  } finally {
    o3 = i4;
  }
};
Object.defineProperty(u3.prototype, "value", { get: function() {
  var i4 = e3(this);
  if (void 0 !== i4) i4.i = this.i;
  return this.v;
}, set: function(i4) {
  if (i4 !== this.v) {
    if (f3 > 100) throw new Error("Cycle detected");
    this.v = i4;
    this.i++;
    v3++;
    s3++;
    try {
      for (var r4 = this.t; void 0 !== r4; r4 = r4.x) r4.t.N();
    } finally {
      t3();
    }
  }
} });
function d3(i4, t4) {
  return new u3(i4, t4);
}
function c3(i4) {
  for (var t4 = i4.s; void 0 !== t4; t4 = t4.n) if (t4.S.i !== t4.i || !t4.S.h() || t4.S.i !== t4.i) return true;
  return false;
}
function a3(i4) {
  for (var t4 = i4.s; void 0 !== t4; t4 = t4.n) {
    var r4 = t4.S.n;
    if (void 0 !== r4) t4.r = r4;
    t4.S.n = t4;
    t4.i = -1;
    if (void 0 === t4.n) {
      i4.s = t4;
      break;
    }
  }
}
function l3(i4) {
  var t4 = i4.s, r4 = void 0;
  while (void 0 !== t4) {
    var o4 = t4.p;
    if (-1 === t4.i) {
      t4.S.U(t4);
      if (void 0 !== o4) o4.n = t4.n;
      if (void 0 !== t4.n) t4.n.p = o4;
    } else r4 = t4;
    t4.S.n = t4.r;
    if (void 0 !== t4.r) t4.r = void 0;
    t4 = o4;
  }
  i4.s = r4;
}
function y3(i4, t4) {
  u3.call(this, void 0);
  this.x = i4;
  this.s = void 0;
  this.g = v3 - 1;
  this.f = 4;
  this.W = null == t4 ? void 0 : t4.watched;
  this.Z = null == t4 ? void 0 : t4.unwatched;
  this.name = null == t4 ? void 0 : t4.name;
}
y3.prototype = new u3();
y3.prototype.h = function() {
  this.f &= -3;
  if (1 & this.f) return false;
  if (32 == (36 & this.f)) return true;
  this.f &= -5;
  if (this.g === v3) return true;
  this.g = v3;
  this.f |= 1;
  if (this.i > 0 && !c3(this)) {
    this.f &= -2;
    return true;
  }
  var i4 = o3;
  try {
    a3(this);
    o3 = this;
    var t4 = this.x();
    if (16 & this.f || this.v !== t4 || 0 === this.i) {
      this.v = t4;
      this.f &= -17;
      this.i++;
    }
  } catch (i5) {
    this.v = i5;
    this.f |= 16;
    this.i++;
  }
  o3 = i4;
  l3(this);
  this.f &= -2;
  return true;
};
y3.prototype.S = function(i4) {
  if (void 0 === this.t) {
    this.f |= 36;
    for (var t4 = this.s; void 0 !== t4; t4 = t4.n) t4.S.S(t4);
  }
  u3.prototype.S.call(this, i4);
};
y3.prototype.U = function(i4) {
  if (void 0 !== this.t) {
    u3.prototype.U.call(this, i4);
    if (void 0 === this.t) {
      this.f &= -33;
      for (var t4 = this.s; void 0 !== t4; t4 = t4.n) t4.S.U(t4);
    }
  }
};
y3.prototype.N = function() {
  if (!(2 & this.f)) {
    this.f |= 6;
    for (var i4 = this.t; void 0 !== i4; i4 = i4.x) i4.t.N();
  }
};
Object.defineProperty(y3.prototype, "value", { get: function() {
  if (1 & this.f) throw new Error("Cycle detected");
  var i4 = e3(this);
  this.h();
  if (void 0 !== i4) i4.i = this.i;
  if (16 & this.f) throw this.v;
  return this.v;
} });
function w3(i4, t4) {
  return new y3(i4, t4);
}
function _2(i4) {
  var r4 = i4.u;
  i4.u = void 0;
  if ("function" == typeof r4) {
    s3++;
    var n3 = o3;
    o3 = void 0;
    try {
      r4();
    } catch (t4) {
      i4.f &= -2;
      i4.f |= 8;
      b(i4);
      throw t4;
    } finally {
      o3 = n3;
      t3();
    }
  }
}
function b(i4) {
  for (var t4 = i4.s; void 0 !== t4; t4 = t4.n) t4.S.U(t4);
  i4.x = void 0;
  i4.s = void 0;
  _2(i4);
}
function g2(i4) {
  if (o3 !== this) throw new Error("Out-of-order effect");
  l3(this);
  o3 = i4;
  this.f &= -2;
  if (8 & this.f) b(this);
  t3();
}
function p3(i4, t4) {
  this.x = i4;
  this.u = void 0;
  this.s = void 0;
  this.o = void 0;
  this.f = 32;
  this.name = null == t4 ? void 0 : t4.name;
}
p3.prototype.c = function() {
  var i4 = this.S();
  try {
    if (8 & this.f) return;
    if (void 0 === this.x) return;
    var t4 = this.x();
    if ("function" == typeof t4) this.u = t4;
  } finally {
    i4();
  }
};
p3.prototype.S = function() {
  if (1 & this.f) throw new Error("Cycle detected");
  this.f |= 1;
  this.f &= -9;
  _2(this);
  a3(this);
  s3++;
  var i4 = o3;
  o3 = this;
  return g2.bind(this, i4);
};
p3.prototype.N = function() {
  if (!(2 & this.f)) {
    this.f |= 2;
    this.o = h3;
    h3 = this;
  }
};
p3.prototype.d = function() {
  this.f |= 8;
  if (!(1 & this.f)) b(this);
};
p3.prototype.dispose = function() {
  this.d();
};
function E2(i4, t4) {
  var r4 = new p3(i4, t4);
  try {
    r4.c();
  } catch (i5) {
    r4.d();
    throw i5;
  }
  var o4 = r4.d.bind(r4);
  o4[Symbol.dispose] = o4;
  return o4;
}

// node_modules/@preact/signals/dist/signals.module.js
var h4;
var l4;
var p4;
var m3 = "undefined" != typeof window && !!window.__PREACT_SIGNALS_DEVTOOLS__;
var _3 = [];
E2(function() {
  h4 = this.N;
})();
function g3(i4, t4) {
  l[i4] = t4.bind(null, l[i4] || function() {
  });
}
function y4(i4) {
  if (p4) p4();
  p4 = i4 && i4.S();
}
function b2(i4) {
  var n3 = this, r4 = i4.data, o4 = useSignal(r4);
  o4.value = r4;
  var e4 = T2(function() {
    var i5 = n3, r5 = n3.__v;
    while (r5 = r5.__) if (r5.__c) {
      r5.__c.__$f |= 4;
      break;
    }
    var f5 = w3(function() {
      var i6 = o4.value.value;
      return 0 === i6 ? 0 : true === i6 ? "" : i6 || "";
    }), e5 = w3(function() {
      return !Array.isArray(f5.value) && !t(f5.value);
    }), u6 = E2(function() {
      this.N = M2;
      if (e5.value) {
        var n4 = f5.value;
        if (i5.__v && i5.__v.__e && 3 === i5.__v.__e.nodeType) i5.__v.__e.data = n4;
      }
    }), c5 = n3.__$u.d;
    n3.__$u.d = function() {
      u6();
      c5.call(this);
    };
    return [e5, f5];
  }, []), u5 = e4[0], c4 = e4[1];
  return u5.value ? c4.peek() : c4.value;
}
b2.displayName = "ReactiveTextNode";
Object.defineProperties(u3.prototype, { constructor: { configurable: true, value: void 0 }, type: { configurable: true, value: b2 }, props: { configurable: true, get: function() {
  return { data: this };
} }, __b: { configurable: true, value: 1 } });
g3("__b", function(i4, n3) {
  if (m3 && "function" == typeof n3.type) window.__PREACT_SIGNALS_DEVTOOLS__.exitComponent();
  if ("string" == typeof n3.type) {
    var t4, r4 = n3.props;
    for (var f5 in r4) if ("children" !== f5) {
      var o4 = r4[f5];
      if (o4 instanceof u3) {
        if (!t4) n3.__np = t4 = {};
        t4[f5] = o4;
        r4[f5] = o4.peek();
      }
    }
  }
  i4(n3);
});
g3("__r", function(i4, n3) {
  if (m3 && "function" == typeof n3.type) window.__PREACT_SIGNALS_DEVTOOLS__.enterComponent(n3);
  if (n3.type !== k) {
    y4();
    var t4, f5 = n3.__c;
    if (f5) {
      f5.__$f &= -2;
      if (void 0 === (t4 = f5.__$u)) f5.__$u = t4 = (function(i5) {
        var n4;
        E2(function() {
          n4 = this;
        });
        n4.c = function() {
          f5.__$f |= 1;
          f5.setState({});
        };
        return n4;
      })();
    }
    l4 = f5;
    y4(t4);
  }
  i4(n3);
});
g3("__e", function(i4, n3, t4, r4) {
  if (m3) window.__PREACT_SIGNALS_DEVTOOLS__.exitComponent();
  y4();
  l4 = void 0;
  i4(n3, t4, r4);
});
g3("diffed", function(i4, n3) {
  if (m3 && "function" == typeof n3.type) window.__PREACT_SIGNALS_DEVTOOLS__.exitComponent();
  y4();
  l4 = void 0;
  var t4;
  if ("string" == typeof n3.type && (t4 = n3.__e)) {
    var r4 = n3.__np, f5 = n3.props;
    if (r4) {
      var o4 = t4.U;
      if (o4) for (var e4 in o4) {
        var u5 = o4[e4];
        if (void 0 !== u5 && !(e4 in r4)) {
          u5.d();
          o4[e4] = void 0;
        }
      }
      else {
        o4 = {};
        t4.U = o4;
      }
      for (var a4 in r4) {
        var c4 = o4[a4], v4 = r4[a4];
        if (void 0 === c4) {
          c4 = k3(t4, a4, v4, f5);
          o4[a4] = c4;
        } else c4.o(v4, f5);
      }
    }
  }
  i4(n3);
});
function k3(i4, n3, t4, r4) {
  var f5 = n3 in i4 && void 0 === i4.ownerSVGElement, o4 = d3(t4);
  return { o: function(i5, n4) {
    o4.value = i5;
    r4 = n4;
  }, d: E2(function() {
    this.N = M2;
    var t5 = o4.value.value;
    if (r4[n3] !== t5) {
      r4[n3] = t5;
      if (f5) i4[n3] = t5;
      else if (null != t5 && (false !== t5 || "-" === n3[4])) i4.setAttribute(n3, t5);
      else i4.removeAttribute(n3);
    }
  }) };
}
g3("unmount", function(i4, n3) {
  if ("string" == typeof n3.type) {
    var t4 = n3.__e;
    if (t4) {
      var r4 = t4.U;
      if (r4) {
        t4.U = void 0;
        for (var f5 in r4) {
          var o4 = r4[f5];
          if (o4) o4.d();
        }
      }
    }
  } else {
    var e4 = n3.__c;
    if (e4) {
      var u5 = e4.__$u;
      if (u5) {
        e4.__$u = void 0;
        u5.d();
      }
    }
  }
  i4(n3);
});
g3("__h", function(i4, n3, t4, r4) {
  if (r4 < 3 || 9 === r4) n3.__$f |= 2;
  i4(n3, t4, r4);
});
x.prototype.shouldComponentUpdate = function(i4, n3) {
  var t4 = this.__$u, r4 = t4 && void 0 !== t4.s;
  for (var f5 in n3) return true;
  if (this.__f || "boolean" == typeof this.u && true === this.u) {
    var o4 = 2 & this.__$f;
    if (!(r4 || o4 || 4 & this.__$f)) return true;
    if (1 & this.__$f) return true;
  } else {
    if (!(r4 || 4 & this.__$f)) return true;
    if (3 & this.__$f) return true;
  }
  for (var e4 in i4) if ("__source" !== e4 && i4[e4] !== this.props[e4]) return true;
  for (var u5 in this.props) if (!(u5 in i4)) return true;
  return false;
};
function useSignal(i4, n3) {
  return d2(function() {
    return d3(i4, n3);
  })[0];
}
var A3 = function(i4) {
  queueMicrotask(function() {
    queueMicrotask(i4);
  });
};
function F2() {
  r3(function() {
    var i4;
    while (i4 = _3.shift()) h4.call(i4);
  });
}
function M2() {
  if (1 === _3.push(this)) (l.requestAnimationFrame || A3)(F2);
}

// src/signals/manager.ts
var blocks = d3([]);
var mutes = d3([]);
var history = d3([]);
var contexts = d3([]);
var syncState = d3(null);
var options = d3(null);
var amnestyReviewedDids = d3(/* @__PURE__ */ new Set());
var amnestyReviews = d3([]);
var amnestyCandidate = d3(null);
var amnestySearching = d3(false);
var amnestySearchedNoContext = d3(/* @__PURE__ */ new Set());
var amnestyMode = d3("blocks_mutes");
var ownedLists = d3([]);
var selectedListUri = d3(null);
var listMembers = d3([]);
var listAuditCandidate = d3(null);
var listAuditReviewedDids = d3(/* @__PURE__ */ new Set());
var listAuditLoading = d3(false);
function setAmnestyMode(mode) {
  amnestyMode.value = mode;
  if (mode === "blocks_mutes") {
    listAuditCandidate.value = null;
  } else {
    amnestyCandidate.value = null;
  }
}
function selectList(uri) {
  selectedListUri.value = uri;
  listMembers.value = [];
  listAuditCandidate.value = null;
  listAuditReviewedDids.value = /* @__PURE__ */ new Set();
}
var amnestyStatusMap = w3(() => {
  const map = /* @__PURE__ */ new Map();
  for (const review of amnestyReviews.value) {
    if (review.decision === "kept_blocked" || review.decision === "kept_muted") {
      map.set(review.did, "denied");
    }
  }
  return map;
});
var blocklistAuditState = d3(null);
var blocklistConflicts = d3([]);
var currentTab = d3("actions");
var searchQuery = d3("");
var filterSource = d3("all");
var filterType = d3("all");
var sortColumn = d3("date");
var sortDirection = d3("desc");
var selectedItems = d3(/* @__PURE__ */ new Set());
var loading = d3(true);
var tempUnblockTimers = d3(
  /* @__PURE__ */ new Map()
);
var findingContext = d3(/* @__PURE__ */ new Set());
function setFindingContext(did, loading2) {
  const newSet = new Set(findingContext.value);
  if (loading2) {
    newSet.add(did);
  } else {
    newSet.delete(did);
  }
  findingContext.value = newSet;
}
var expandedRows = d3(/* @__PURE__ */ new Set());
var expandedInteractions = d3(/* @__PURE__ */ new Map());
var expandedLoading = d3(/* @__PURE__ */ new Set());
function toggleExpanded(did) {
  const newSet = new Set(expandedRows.value);
  if (newSet.has(did)) {
    newSet.delete(did);
  } else {
    newSet.add(did);
  }
  expandedRows.value = newSet;
}
function setInteractions(did, interactions) {
  const newMap = new Map(expandedInteractions.value);
  newMap.set(did, interactions);
  expandedInteractions.value = newMap;
}
function setExpandedLoading(did, loading2) {
  const newSet = new Set(expandedLoading.value);
  if (loading2) {
    newSet.add(did);
  } else {
    newSet.delete(did);
  }
  expandedLoading.value = newSet;
}
var contextMap = w3(() => {
  const map = /* @__PURE__ */ new Map();
  for (const ctx of contexts.value) {
    const existing = map.get(ctx.targetDid);
    if (!existing || ctx.timestamp > existing.timestamp) {
      map.set(ctx.targetDid, ctx);
    }
  }
  return map;
});
var stats = w3(() => ({
  totalBlocks: blocks.value.length,
  totalMutes: mutes.value.length,
  tempBlocks: blocks.value.filter((b3) => b3.source === "ergoblock_temp").length,
  tempMutes: mutes.value.filter((m4) => m4.source === "ergoblock_temp").length
}));
var allEntries = w3(() => {
  const blockDids = new Set(blocks.value.map((b3) => b3.did));
  const muteDids = new Set(mutes.value.map((m4) => m4.did));
  const bothDids = new Set([...blockDids].filter((did) => muteDids.has(did)));
  const combinedEntries = [];
  for (const block of blocks.value) {
    if (bothDids.has(block.did)) {
      combinedEntries.push({
        ...block,
        type: "both"
      });
    } else {
      combinedEntries.push(block);
    }
  }
  for (const mute of mutes.value) {
    if (!bothDids.has(mute.did)) {
      combinedEntries.push(mute);
    }
  }
  return combinedEntries;
});
function toggleSort(column) {
  if (sortColumn.value === column) {
    sortDirection.value = sortDirection.value === "asc" ? "desc" : "asc";
  } else {
    sortColumn.value = column;
    sortDirection.value = column === "date" || column === "expires" ? "desc" : "asc";
  }
}
function toggleSelection(did) {
  const newSet = new Set(selectedItems.value);
  if (newSet.has(did)) {
    newSet.delete(did);
  } else {
    newSet.add(did);
  }
  selectedItems.value = newSet;
}
function selectAll(dids) {
  selectedItems.value = new Set(dids);
}
function clearSelection() {
  selectedItems.value = /* @__PURE__ */ new Set();
}
var massOpsLoading = d3(false);
var massOpsProgress = d3("");
var massOpsScanResult = d3(null);
var massOpsSettings = d3(DEFAULT_MASS_OPS_SETTINGS);
var massOpsSelectedItems = d3(/* @__PURE__ */ new Map());
var massOpsExpandedClusters = d3(/* @__PURE__ */ new Set());
function toggleMassOpsClusterExpanded(clusterId) {
  const newSet = new Set(massOpsExpandedClusters.value);
  if (newSet.has(clusterId)) {
    newSet.delete(clusterId);
  } else {
    newSet.add(clusterId);
  }
  massOpsExpandedClusters.value = newSet;
}
function initMassOpsClusterSelection(clusterId, rkeys) {
  const newMap = new Map(massOpsSelectedItems.value);
  newMap.set(clusterId, new Set(rkeys));
  massOpsSelectedItems.value = newMap;
}
function toggleMassOpsItemSelection(clusterId, rkey) {
  const newMap = new Map(massOpsSelectedItems.value);
  const current = newMap.get(clusterId) || /* @__PURE__ */ new Set();
  const newSet = new Set(current);
  if (newSet.has(rkey)) {
    newSet.delete(rkey);
  } else {
    newSet.add(rkey);
  }
  newMap.set(clusterId, newSet);
  massOpsSelectedItems.value = newMap;
}
function selectAllMassOpsItems(clusterId, rkeys) {
  const newMap = new Map(massOpsSelectedItems.value);
  newMap.set(clusterId, new Set(rkeys));
  massOpsSelectedItems.value = newMap;
}
function deselectAllMassOpsItems(clusterId) {
  const newMap = new Map(massOpsSelectedItems.value);
  newMap.set(clusterId, /* @__PURE__ */ new Set());
  massOpsSelectedItems.value = newMap;
}
function getMassOpsSelectedItems(clusterId) {
  return massOpsSelectedItems.value.get(clusterId) || /* @__PURE__ */ new Set();
}
var carCacheStatus = d3(null);
var carDownloadProgress = d3(null);
var carEstimatedSize = d3(null);
var copyUserTargetHandle = d3("");
var copyUserTargetDid = d3(null);
var copyUserTargetProfile = d3(null);
var copyUserLoading = d3(false);
var copyUserProgress = d3("");
var copyUserError = d3(null);
var copyUserFollows = d3([]);
var copyUserBlocks = d3([]);
var copyUserSelectedFollows = d3(/* @__PURE__ */ new Set());
var copyUserSelectedBlocks = d3(/* @__PURE__ */ new Set());
var copyUserProfiles = d3(/* @__PURE__ */ new Map());
var copyUserProfilesError = d3(null);
var copyUserProfilesLoaded = d3(false);
var copyUserExecuting = d3(false);
var copyUserExecuteProgress = d3({
  done: 0,
  total: 0,
  type: ""
});
function resetCopyUserState() {
  copyUserTargetHandle.value = "";
  copyUserTargetDid.value = null;
  copyUserTargetProfile.value = null;
  copyUserLoading.value = false;
  copyUserProgress.value = "";
  copyUserError.value = null;
  copyUserFollows.value = [];
  copyUserBlocks.value = [];
  copyUserSelectedFollows.value = /* @__PURE__ */ new Set();
  copyUserSelectedBlocks.value = /* @__PURE__ */ new Set();
  copyUserProfiles.value = /* @__PURE__ */ new Map();
  copyUserProfilesError.value = null;
  copyUserProfilesLoaded.value = false;
  copyUserExecuting.value = false;
  copyUserExecuteProgress.value = { done: 0, total: 0, type: "" };
}
function toggleCopyUserFollow(did) {
  const newSet = new Set(copyUserSelectedFollows.value);
  if (newSet.has(did)) {
    newSet.delete(did);
  } else {
    newSet.add(did);
  }
  copyUserSelectedFollows.value = newSet;
}
function toggleCopyUserBlock(did) {
  const newSet = new Set(copyUserSelectedBlocks.value);
  if (newSet.has(did)) {
    newSet.delete(did);
  } else {
    newSet.add(did);
  }
  copyUserSelectedBlocks.value = newSet;
}
function selectAllCopyUserFollows(dids) {
  copyUserSelectedFollows.value = new Set(dids);
}
function deselectAllCopyUserFollows() {
  copyUserSelectedFollows.value = /* @__PURE__ */ new Set();
}
function selectAllCopyUserBlocks(dids) {
  copyUserSelectedBlocks.value = new Set(dids);
}
function deselectAllCopyUserBlocks() {
  copyUserSelectedBlocks.value = /* @__PURE__ */ new Set();
}

// node_modules/preact/jsx-runtime/dist/jsxRuntime.module.js
var f4 = 0;
function u4(e4, t4, n3, o4, i4, u5) {
  t4 || (t4 = {});
  var a4, c4, p5 = t4;
  if ("ref" in p5) for (c4 in p5 = {}, t4) "ref" == c4 ? a4 = t4[c4] : p5[c4] = t4[c4];
  var l5 = { type: e4, props: p5, key: n3, ref: a4, __k: null, __: null, __b: 0, __e: null, __c: null, constructor: void 0, __v: --f4, __i: -1, __u: 0, __source: i4, __self: u5 };
  if ("function" == typeof e4 && (a4 = e4.defaultProps)) for (c4 in a4) void 0 === p5[c4] && (p5[c4] = a4[c4]);
  return l.vnode && l.vnode(l5), l5;
}

// src/components/manager/StatsBar.tsx
function StatsBar() {
  const s4 = stats.value;
  return /* @__PURE__ */ u4("div", { class: "stats-bar", children: [
    /* @__PURE__ */ u4("div", { class: "stat-card", children: [
      /* @__PURE__ */ u4("div", { class: "stat-value", children: s4.totalBlocks }),
      /* @__PURE__ */ u4("div", { class: "stat-label", children: "Total Blocks" })
    ] }),
    /* @__PURE__ */ u4("div", { class: "stat-card", children: [
      /* @__PURE__ */ u4("div", { class: "stat-value", children: s4.totalMutes }),
      /* @__PURE__ */ u4("div", { class: "stat-label", children: "Total Mutes" })
    ] }),
    /* @__PURE__ */ u4("div", { class: "stat-card", children: [
      /* @__PURE__ */ u4("div", { class: "stat-value", children: s4.tempBlocks }),
      /* @__PURE__ */ u4("div", { class: "stat-label", children: "Temp Blocks" })
    ] }),
    /* @__PURE__ */ u4("div", { class: "stat-card", children: [
      /* @__PURE__ */ u4("div", { class: "stat-value", children: s4.tempMutes }),
      /* @__PURE__ */ u4("div", { class: "stat-label", children: "Temp Mutes" })
    ] })
  ] });
}

// src/components/manager/TabNav.tsx
var TABS = [
  { id: "actions", label: "Blocks & Mutes" },
  { id: "amnesty", label: "Amnesty" },
  { id: "blocklist-audit", label: "Blocklist Audit" },
  { id: "repost-filters", label: "Repost Filters" },
  { id: "mass-ops", label: "Mass Ops" },
  { id: "copy-user", label: "Copy User" },
  { id: "settings", label: "Settings" }
];
function TabNav() {
  const handleTabClick = (tabId) => {
    currentTab.value = tabId;
  };
  return /* @__PURE__ */ u4("div", { class: "tabs", children: TABS.map((tab) => /* @__PURE__ */ u4(
    "button",
    {
      class: `tab ${currentTab.value === tab.id ? "active" : ""}`,
      onClick: () => handleTabClick(tab.id),
      children: tab.label
    },
    tab.id
  )) });
}

// src/components/manager/Toolbar.tsx
function Toolbar({ onBulkRemove }) {
  const count = selectedItems.value.size;
  const tab = currentTab.value;
  const isHidden = tab === "amnesty" || tab === "blocklist-audit";
  if (isHidden) {
    return /* @__PURE__ */ u4(k, {});
  }
  return /* @__PURE__ */ u4("div", { class: "toolbar", children: [
    /* @__PURE__ */ u4(
      "input",
      {
        type: "search",
        placeholder: "Search by handle...",
        value: searchQuery.value,
        onInput: (e4) => {
          searchQuery.value = e4.target.value;
        }
      }
    ),
    tab === "actions" && /* @__PURE__ */ u4(
      "select",
      {
        value: filterType.value,
        onChange: (e4) => {
          filterType.value = e4.target.value;
        },
        children: [
          /* @__PURE__ */ u4("option", { value: "all", children: "All Types" }),
          /* @__PURE__ */ u4("option", { value: "block", children: "Blocks Only" }),
          /* @__PURE__ */ u4("option", { value: "mute", children: "Mutes Only" }),
          /* @__PURE__ */ u4("option", { value: "both", children: "Both Block & Mute" })
        ]
      }
    ),
    /* @__PURE__ */ u4(
      "select",
      {
        value: filterSource.value,
        onChange: (e4) => {
          filterSource.value = e4.target.value;
        },
        children: [
          /* @__PURE__ */ u4("option", { value: "all", children: "All Sources" }),
          /* @__PURE__ */ u4("option", { value: "ergoblock_temp", children: "Temp (ErgoBlock)" }),
          /* @__PURE__ */ u4("option", { value: "bluesky", children: "Permanent (Bluesky)" })
        ]
      }
    ),
    count > 0 && /* @__PURE__ */ u4("div", { class: "bulk-actions", children: [
      /* @__PURE__ */ u4("span", { children: [
        count,
        " selected"
      ] }),
      /* @__PURE__ */ u4("button", { class: "danger", onClick: onBulkRemove, children: "Remove Selected" })
    ] })
  ] });
}

// src/components/manager/SortableHeader.tsx
function SortableHeader({ column, label }) {
  const isActive = sortColumn.value === column;
  const arrow = isActive ? sortDirection.value === "asc" ? "\u2191" : "\u2193" : "\u21C5";
  return /* @__PURE__ */ u4("th", { class: "sortable", onClick: () => toggleSort(column), children: [
    label,
    " ",
    /* @__PURE__ */ u4("span", { class: `sort-arrow ${isActive ? "sort-active" : "sort-inactive"}`, children: arrow })
  ] });
}

// src/components/manager/UserCell.tsx
function UserCell({ handle, displayName, avatar }) {
  return /* @__PURE__ */ u4("td", { class: "user-col", children: /* @__PURE__ */ u4("div", { class: "user-cell", children: [
    avatar ? /* @__PURE__ */ u4("img", { src: avatar, class: "user-avatar", alt: "", loading: "lazy" }) : /* @__PURE__ */ u4("div", { class: "user-avatar" }),
    /* @__PURE__ */ u4("div", { class: "user-info", children: [
      /* @__PURE__ */ u4("span", { class: "user-handle", children: [
        "@",
        handle
      ] }),
      displayName && /* @__PURE__ */ u4("span", { class: "user-display-name", children: displayName })
    ] })
  ] }) });
}

// src/components/manager/utils.ts
function formatTimeAgo(timestamp) {
  const diff = Date.now() - timestamp;
  const minutes = Math.floor(diff / 6e4);
  const hours = Math.floor(diff / 36e5);
  const days = Math.floor(diff / 864e5);
  if (minutes < 1) return "Just now";
  if (minutes < 60) return `${minutes}m ago`;
  if (hours < 24) return `${hours}h ago`;
  return `${days}d ago`;
}
function formatTimeRemaining(expiresAt) {
  const diff = expiresAt - Date.now();
  if (diff <= 0) return "Expired";
  const hours = Math.floor(diff / 36e5);
  const minutes = Math.floor(diff % 36e5 / 6e4);
  if (hours >= 24) {
    const days = Math.floor(hours / 24);
    return `${days}d ${hours % 24}h`;
  }
  return `${hours}h ${minutes}m`;
}
function formatDate(timestamp) {
  return new Date(timestamp).toLocaleString();
}
function escapeCSV(value) {
  if (value.includes(",") || value.includes('"') || value.includes("\n")) {
    return `"${value.replace(/"/g, '""')}"`;
  }
  return value;
}
function downloadCSV(content, filename) {
  const blob = new Blob([content], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}
function downloadJSON(data, filename) {
  const blob = new Blob([JSON.stringify(data, null, 2)], { type: "application/json" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = filename;
  link.click();
  URL.revokeObjectURL(url);
}
function getItemHandle(item) {
  if ("handle" in item) return item.handle;
  if ("targetHandle" in item) return item.targetHandle;
  return "";
}
function getItemDate(item) {
  if ("source" in item) {
    return item.createdAt || item.syncedAt || 0;
  } else if ("postCreatedAt" in item) {
    return item.postCreatedAt || item.timestamp || 0;
  } else if ("timestamp" in item) {
    return item.timestamp || 0;
  }
  return 0;
}
function filterAndSort(items, search, sourceFilter, column, direction, amnestyMap, typeFilter) {
  let filtered = items.filter((item) => {
    if (search) {
      const handle = getItemHandle(item);
      if (!handle.toLowerCase().includes(search.toLowerCase())) return false;
    }
    if (sourceFilter !== "all" && "source" in item) {
      if (item.source !== sourceFilter) return false;
    }
    if (typeFilter && typeFilter !== "all" && "type" in item) {
      if (item.type !== typeFilter) return false;
    }
    return true;
  });
  const dir = direction === "asc" ? 1 : -1;
  filtered.sort((a4, b3) => {
    let cmp = 0;
    switch (column) {
      case "user": {
        const handleA = getItemHandle(a4);
        const handleB = getItemHandle(b3);
        cmp = handleA.localeCompare(handleB);
        break;
      }
      case "type": {
        const typeA = "type" in a4 ? a4.type : "";
        const typeB = "type" in b3 ? b3.type : "";
        cmp = typeA.localeCompare(typeB);
        break;
      }
      case "source": {
        const sourceA = "source" in a4 ? a4.source : "";
        const sourceB = "source" in b3 ? b3.source : "";
        cmp = sourceA.localeCompare(sourceB);
        break;
      }
      case "amnesty": {
        const didA = "did" in a4 ? a4.did : "";
        const didB = "did" in b3 ? b3.did : "";
        const statusA = amnestyMap?.get(didA) === "denied" ? 0 : 1;
        const statusB = amnestyMap?.get(didB) === "denied" ? 0 : 1;
        cmp = statusA - statusB;
        break;
      }
      case "expires": {
        const expA = "expiresAt" in a4 ? a4.expiresAt || Infinity : Infinity;
        const expB = "expiresAt" in b3 ? b3.expiresAt || Infinity : Infinity;
        cmp = expA - expB;
        break;
      }
      case "date":
      default: {
        const dateA = getItemDate(a4);
        const dateB = getItemDate(b3);
        cmp = dateA - dateB;
        break;
      }
    }
    return cmp * dir;
  });
  return filtered;
}
var FORGIVENESS_OPTIONS = [
  { value: 30, label: "1 month" },
  { value: 60, label: "2 months" },
  { value: 90, label: "3 months" },
  { value: 180, label: "6 months" },
  { value: 365, label: "1 year" }
];
function getForgivenessPeriodMs(days) {
  return days * 24 * 60 * 60 * 1e3;
}
function getAmnestyCandidates(allBlocks, allMutes, forgivenessDays, reviewedDids) {
  const now = Date.now();
  const cutoff = now - getForgivenessPeriodMs(forgivenessDays);
  const blockCandidates = allBlocks.filter((block) => {
    const blockDate = block.createdAt || block.syncedAt || now;
    if (blockDate > cutoff) return false;
    if (block.viewer?.blockedBy) return false;
    if (reviewedDids.has(block.did)) return false;
    return true;
  });
  const muteCandidates = allMutes.filter((mute) => {
    const muteDate = mute.createdAt || mute.syncedAt || now;
    if (muteDate > cutoff) return false;
    if (reviewedDids.has(mute.did)) return false;
    return true;
  });
  return [...blockCandidates, ...muteCandidates];
}
function selectRandomCandidate(candidates) {
  if (candidates.length === 0) return null;
  const index = Math.floor(Math.random() * candidates.length);
  return candidates[index] ?? null;
}
function postUriToUrl(postUri) {
  return postUri.replace("at://", "https://bsky.app/profile/").replace("/app.bsky.feed.post/", "/post/");
}
function getListAuditCandidates(members, reviewedDids) {
  return members.filter((member) => !reviewedDids.has(member.did));
}
function selectRandomListMember(candidates) {
  if (candidates.length === 0) return null;
  const index = Math.floor(Math.random() * candidates.length);
  return candidates[index] ?? null;
}

// src/components/manager/ContextCell.tsx
function ContextCell({
  did,
  handle,
  isBlocked,
  isExpanded,
  onFindContext,
  onViewPost,
  onToggleExpand,
  showExpandButton = true
}) {
  const ctx = contextMap.value.get(did);
  const tempTimer = tempUnblockTimers.value.get(did);
  const isFinding = findingContext.value.has(did);
  if (!ctx) {
    return /* @__PURE__ */ u4("td", { class: "context-col", children: /* @__PURE__ */ u4("div", { class: "context-cell", children: [
      /* @__PURE__ */ u4("span", { class: "no-context", children: "No context" }),
      /* @__PURE__ */ u4("div", { class: "context-meta", children: [
        /* @__PURE__ */ u4(
          "button",
          {
            class: "context-btn find-context-btn",
            onClick: () => onFindContext(did, handle),
            disabled: isFinding,
            children: isFinding ? /* @__PURE__ */ u4(k, { children: [
              /* @__PURE__ */ u4("span", { class: "spinner" }),
              "Finding..."
            ] }) : "Find"
          }
        ),
        showExpandButton && /* @__PURE__ */ u4(
          "button",
          {
            class: `context-btn expand-btn ${isExpanded ? "expanded" : ""}`,
            onClick: onToggleExpand,
            title: isExpanded ? "Collapse" : "Show all interactions",
            children: isExpanded ? "\u25BC" : "\u25B6"
          }
        )
      ] })
    ] }) });
  }
  const postUrl = ctx.postUri ? postUriToUrl(ctx.postUri) : "";
  const isGuessed = ctx.guessed === true;
  return /* @__PURE__ */ u4("td", { class: "context-col", children: /* @__PURE__ */ u4("div", { class: "context-cell", children: [
    ctx.postText ? /* @__PURE__ */ u4("span", { class: "context-text", children: ctx.postText }) : /* @__PURE__ */ u4("span", { class: "no-context", children: "No text" }),
    /* @__PURE__ */ u4("div", { class: "context-meta", children: [
      isGuessed && /* @__PURE__ */ u4("span", { class: "badge badge-guessed", title: "Auto-detected", children: "Auto" }),
      postUrl && (isBlocked ? /* @__PURE__ */ u4(
        "button",
        {
          class: `context-btn context-view-btn ${tempTimer ? "temp-unblocked" : ""}`,
          onClick: () => onViewPost(did, handle, postUrl),
          disabled: !!tempTimer,
          children: tempTimer ? `Re-blocking...` : "View"
        }
      ) : /* @__PURE__ */ u4("a", { href: postUrl, target: "_blank", rel: "noopener", class: "context-btn context-link-btn", children: "View" })),
      showExpandButton && /* @__PURE__ */ u4(
        "button",
        {
          class: `context-btn expand-btn ${isExpanded ? "expanded" : ""}`,
          onClick: onToggleExpand,
          title: isExpanded ? "Collapse" : "Show all interactions",
          children: isExpanded ? "\u25BC" : "\u25B6"
        }
      )
    ] })
  ] }) });
}

// src/components/manager/StatusIndicators.tsx
function StatusIndicators({ viewer, isBlocksTab }) {
  const labels = [];
  if (viewer?.blockedBy) {
    labels.push(
      /* @__PURE__ */ u4("span", { class: "status-label status-blocked-by", children: "Blocking you" }, "blocked-by")
    );
  }
  const weFollow = !!viewer?.following;
  const theyFollow = !!viewer?.followedBy;
  if (weFollow && theyFollow) {
    labels.push(
      /* @__PURE__ */ u4("span", { class: "status-label status-mutual-follow", children: "Mutual follow" }, "mutual")
    );
  } else if (weFollow) {
    labels.push(
      /* @__PURE__ */ u4("span", { class: "status-label status-following", children: "Following" }, "following")
    );
  } else if (theyFollow) {
    labels.push(
      /* @__PURE__ */ u4("span", { class: "status-label status-followed-by", children: "Follows you" }, "followed-by")
    );
  }
  if (!isBlocksTab && viewer?.muted) {
    labels.push(
      /* @__PURE__ */ u4("span", { class: "status-label status-muted", children: "Muted" }, "muted")
    );
  }
  if (labels.length === 0) {
    return /* @__PURE__ */ u4("td", { children: "-" });
  }
  return /* @__PURE__ */ u4("td", { children: /* @__PURE__ */ u4("span", { class: "status-labels", children: labels }) });
}

// src/components/manager/InteractionsList.tsx
function InteractionsList({
  did,
  handle,
  isBlocked,
  onFetchInteractions,
  onViewPost
}) {
  const interactions = expandedInteractions.value.get(did);
  const isLoading = expandedLoading.value.has(did);
  const tempTimer = tempUnblockTimers.value.get(did);
  y2(() => {
    if (!interactions && !isLoading) {
      onFetchInteractions(did, handle);
    }
  }, [did, handle, interactions, isLoading, onFetchInteractions]);
  if (isLoading) {
    return /* @__PURE__ */ u4("div", { class: "interactions-list loading", children: [
      /* @__PURE__ */ u4("span", { class: "loading-spinner" }),
      "Searching for interactions..."
    ] });
  }
  if (!interactions || interactions.length === 0) {
    return /* @__PURE__ */ u4("div", { class: "interactions-list empty", children: [
      /* @__PURE__ */ u4("span", { class: "no-interactions", children: "No interactions found" }),
      /* @__PURE__ */ u4("button", { class: "context-btn", onClick: () => onFetchInteractions(did, handle), children: "Search again" })
    ] });
  }
  return /* @__PURE__ */ u4("div", { class: "interactions-list", children: [
    /* @__PURE__ */ u4("div", { class: "interactions-header", children: /* @__PURE__ */ u4("span", { class: "interactions-count", children: [
      interactions.length,
      " interaction",
      interactions.length !== 1 ? "s" : "",
      " found"
    ] }) }),
    /* @__PURE__ */ u4("div", { class: "interactions-items", children: interactions.map((interaction) => /* @__PURE__ */ u4(
      InteractionItem,
      {
        interaction,
        isBlocked,
        tempTimer,
        onViewPost: (url) => onViewPost(did, handle, url)
      },
      interaction.uri
    )) })
  ] });
}
function InteractionItem({
  interaction,
  isBlocked,
  tempTimer,
  onViewPost
}) {
  const postUrl = postUriToUrl(interaction.uri);
  const typeLabels = {
    reply: "Reply",
    quote: "Quote",
    mention: "Mention"
  };
  const authorLabel = interaction.author === "them" ? "They wrote" : "You wrote";
  return /* @__PURE__ */ u4("div", { class: "interaction-item", children: [
    /* @__PURE__ */ u4("div", { class: "interaction-meta", children: [
      /* @__PURE__ */ u4("span", { class: `badge badge-${interaction.type}`, children: typeLabels[interaction.type] }),
      /* @__PURE__ */ u4("span", { class: "interaction-author", children: authorLabel }),
      /* @__PURE__ */ u4("span", { class: "interaction-date", title: new Date(interaction.createdAt).toLocaleString(), children: formatTimeAgo(interaction.createdAt) })
    ] }),
    /* @__PURE__ */ u4("div", { class: "interaction-text", children: interaction.text }),
    /* @__PURE__ */ u4("div", { class: "interaction-actions", children: isBlocked ? /* @__PURE__ */ u4(
      "button",
      {
        class: `context-btn context-view-btn ${tempTimer ? "temp-unblocked" : ""}`,
        onClick: () => onViewPost(postUrl),
        disabled: !!tempTimer,
        children: tempTimer ? "Re-blocking..." : "View"
      }
    ) : /* @__PURE__ */ u4("a", { href: postUrl, target: "_blank", rel: "noopener", class: "context-btn context-link-btn", children: "View" }) })
  ] });
}

// src/components/manager/ActionsTable.tsx
function ActionsTable({
  onUnblock,
  onUnmute,
  onFindContext,
  onViewPost,
  onFetchInteractions
}) {
  const filtered = filterAndSort(
    allEntries.value,
    searchQuery.value,
    filterSource.value,
    sortColumn.value,
    sortDirection.value,
    amnestyStatusMap.value,
    filterType.value
  );
  if (filtered.length === 0) {
    return /* @__PURE__ */ u4("div", { class: "empty-state", children: [
      /* @__PURE__ */ u4("h3", { children: "No blocks or mutes found" }),
      /* @__PURE__ */ u4("p", { children: "You haven't blocked or muted anyone yet, or try adjusting your filters." })
    ] });
  }
  const allDids = filtered.map((entry) => entry.did);
  const allSelected = allDids.every((did) => selectedItems.value.has(did));
  const handleSelectAll = (e4) => {
    const checked = e4.target.checked;
    if (checked) {
      selectAll(allDids);
    } else {
      clearSelection();
    }
  };
  return /* @__PURE__ */ u4("table", { children: [
    /* @__PURE__ */ u4("thead", { children: /* @__PURE__ */ u4("tr", { children: [
      /* @__PURE__ */ u4("th", { children: /* @__PURE__ */ u4("input", { type: "checkbox", checked: allSelected, onChange: handleSelectAll }) }),
      /* @__PURE__ */ u4(SortableHeader, { column: "user", label: "User" }),
      /* @__PURE__ */ u4(SortableHeader, { column: "type", label: "Type" }),
      /* @__PURE__ */ u4("th", { children: "Context" }),
      /* @__PURE__ */ u4(SortableHeader, { column: "source", label: "Source" }),
      /* @__PURE__ */ u4("th", { children: "Status" }),
      /* @__PURE__ */ u4(SortableHeader, { column: "amnesty", label: "Amnesty" }),
      /* @__PURE__ */ u4(SortableHeader, { column: "expires", label: "Expires" }),
      /* @__PURE__ */ u4(SortableHeader, { column: "date", label: "Date" }),
      /* @__PURE__ */ u4("th", { children: "Actions" })
    ] }) }),
    /* @__PURE__ */ u4("tbody", { children: filtered.map((entry) => {
      const isBlock = entry.type === "block";
      const isBoth = entry.type === "both";
      const isTemp = entry.source === "ergoblock_temp";
      const isExpiringSoon = isTemp && entry.expiresAt && entry.expiresAt - Date.now() < 24 * 60 * 60 * 1e3;
      const theyBlockUs = !!entry.viewer?.blockedBy;
      const rowClass = theyBlockUs ? "mutual-block" : "";
      const isSelected = selectedItems.value.has(entry.did);
      const amnestyStatus = amnestyStatusMap.value.get(entry.did);
      const isExpanded = expandedRows.value.has(entry.did);
      const hasInteractions = (expandedInteractions.value.get(entry.did)?.length ?? 0) > 0;
      return /* @__PURE__ */ u4(k, { children: [
        /* @__PURE__ */ u4("tr", { class: `${rowClass} ${isExpanded ? "row-expanded" : ""}`, children: [
          /* @__PURE__ */ u4("td", { children: /* @__PURE__ */ u4(
            "input",
            {
              type: "checkbox",
              checked: isSelected,
              onChange: () => toggleSelection(entry.did)
            }
          ) }),
          /* @__PURE__ */ u4(
            UserCell,
            {
              handle: entry.handle,
              displayName: entry.displayName,
              avatar: entry.avatar
            }
          ),
          /* @__PURE__ */ u4("td", { children: isBoth ? /* @__PURE__ */ u4("div", { class: "badge-group", children: [
            /* @__PURE__ */ u4("span", { class: "badge badge-block", children: "Block" }),
            /* @__PURE__ */ u4("span", { class: "badge badge-mute", children: "Mute" })
          ] }) : /* @__PURE__ */ u4("span", { class: `badge ${isBlock ? "badge-block" : "badge-mute"}`, children: isBlock ? "Block" : "Mute" }) }),
          /* @__PURE__ */ u4(
            ContextCell,
            {
              did: entry.did,
              handle: entry.handle,
              isBlocked: isBlock || isBoth,
              isExpanded,
              onFindContext,
              onViewPost,
              onToggleExpand: () => toggleExpanded(entry.did),
              showExpandButton: hasInteractions
            }
          ),
          /* @__PURE__ */ u4("td", { children: /* @__PURE__ */ u4("span", { class: `badge ${isTemp ? "badge-temp" : "badge-permanent"}`, children: isTemp ? "Temp" : "Perm" }) }),
          /* @__PURE__ */ u4(StatusIndicators, { viewer: entry.viewer, isBlocksTab: isBlock || isBoth }),
          /* @__PURE__ */ u4("td", { children: /* @__PURE__ */ u4(
            "span",
            {
              class: `badge ${amnestyStatus === "denied" ? "badge-denied" : "badge-unreviewed"}`,
              children: amnestyStatus === "denied" ? "Denied" : "Unreviewed"
            }
          ) }),
          /* @__PURE__ */ u4("td", { children: isTemp && entry.expiresAt ? /* @__PURE__ */ u4("span", { class: `badge ${isExpiringSoon ? "badge-expiring" : ""}`, children: formatTimeRemaining(entry.expiresAt) }) : "-" }),
          /* @__PURE__ */ u4("td", { children: entry.createdAt ? formatDate(entry.createdAt) : entry.syncedAt ? formatDate(entry.syncedAt) : "-" }),
          /* @__PURE__ */ u4("td", { children: isBoth ? /* @__PURE__ */ u4("div", { class: "action-group", children: [
            /* @__PURE__ */ u4(
              "button",
              {
                class: "action-btn danger unblock-btn",
                onClick: () => onUnblock(entry.did, entry.handle),
                children: "Unblock"
              }
            ),
            /* @__PURE__ */ u4(
              "button",
              {
                class: "action-btn danger unmute-btn",
                onClick: () => onUnmute(entry.did, entry.handle),
                children: "Unmute"
              }
            )
          ] }) : /* @__PURE__ */ u4(
            "button",
            {
              class: `action-btn danger ${isBlock ? "unblock-btn" : "unmute-btn"}`,
              onClick: () => isBlock ? onUnblock(entry.did, entry.handle) : onUnmute(entry.did, entry.handle),
              children: isBlock ? "Unblock" : "Unmute"
            }
          ) })
        ] }),
        isExpanded && /* @__PURE__ */ u4("tr", { class: "expanded-row", children: /* @__PURE__ */ u4("td", { colSpan: 10, children: /* @__PURE__ */ u4(
          InteractionsList,
          {
            did: entry.did,
            handle: entry.handle,
            isBlocked: isBlock || isBoth,
            onFetchInteractions,
            onViewPost
          }
        ) }) })
      ] }, entry.did);
    }) })
  ] });
}

// node_modules/lucide-preact/dist/esm/shared/src/utils.js
var toKebabCase = (string) => string.replace(/([a-z0-9])([A-Z])/g, "$1-$2").toLowerCase();
var toCamelCase = (string) => string.replace(
  /^([A-Z])|[\s-_]+(\w)/g,
  (match, p1, p22) => p22 ? p22.toUpperCase() : p1.toLowerCase()
);
var toPascalCase = (string) => {
  const camelCase = toCamelCase(string);
  return camelCase.charAt(0).toUpperCase() + camelCase.slice(1);
};
var mergeClasses = (...classes) => classes.filter((className, index, array) => {
  return Boolean(className) && className.trim() !== "" && array.indexOf(className) === index;
}).join(" ").trim();

// node_modules/lucide-preact/dist/esm/defaultAttributes.js
var defaultAttributes = {
  xmlns: "http://www.w3.org/2000/svg",
  width: 24,
  height: 24,
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  "stroke-width": "2",
  "stroke-linecap": "round",
  "stroke-linejoin": "round"
};

// node_modules/lucide-preact/dist/esm/Icon.js
var Icon = ({
  color = "currentColor",
  size = 24,
  strokeWidth = 2,
  absoluteStrokeWidth,
  children,
  iconNode,
  class: classes = "",
  ...rest
}) => _(
  "svg",
  {
    ...defaultAttributes,
    width: String(size),
    height: size,
    stroke: color,
    ["stroke-width"]: absoluteStrokeWidth ? Number(strokeWidth) * 24 / Number(size) : strokeWidth,
    class: ["lucide", classes].join(" "),
    ...rest
  },
  [...iconNode.map(([tag, attrs]) => _(tag, attrs)), ...H(children)]
);

// node_modules/lucide-preact/dist/esm/createLucideIcon.js
var createLucideIcon = (iconName, iconNode) => {
  const Component = ({ class: classes = "", className = "", children, ...props }) => _(
    Icon,
    {
      ...props,
      iconNode,
      class: mergeClasses(
        `lucide-${toKebabCase(toPascalCase(iconName))}`,
        `lucide-${toKebabCase(iconName)}`,
        classes,
        className
      )
    },
    children
  );
  Component.displayName = toPascalCase(iconName);
  return Component;
};

// node_modules/lucide-preact/dist/esm/icons/ban.js
var Ban = createLucideIcon("ban", [
  ["path", { d: "M4.929 4.929 19.07 19.071", key: "196cmz" }],
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }]
]);

// node_modules/lucide-preact/dist/esm/icons/check.js
var Check = createLucideIcon("check", [["path", { d: "M20 6 9 17l-5-5", key: "1gmf2c" }]]);

// node_modules/lucide-preact/dist/esm/icons/chevron-down.js
var ChevronDown = createLucideIcon("chevron-down", [
  ["path", { d: "m6 9 6 6 6-6", key: "qrunsl" }]
]);

// node_modules/lucide-preact/dist/esm/icons/chevron-right.js
var ChevronRight = createLucideIcon("chevron-right", [
  ["path", { d: "m9 18 6-6-6-6", key: "mthhwq" }]
]);

// node_modules/lucide-preact/dist/esm/icons/circle-alert.js
var CircleAlert = createLucideIcon("circle-alert", [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["line", { x1: "12", x2: "12", y1: "8", y2: "12", key: "1pkeuh" }],
  ["line", { x1: "12", x2: "12.01", y1: "16", y2: "16", key: "4dfq90" }]
]);

// node_modules/lucide-preact/dist/esm/icons/copy.js
var Copy = createLucideIcon("copy", [
  ["rect", { width: "14", height: "14", x: "8", y: "8", rx: "2", ry: "2", key: "17jyea" }],
  ["path", { d: "M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2", key: "zix9uf" }]
]);

// node_modules/lucide-preact/dist/esm/icons/database.js
var Database = createLucideIcon("database", [
  ["ellipse", { cx: "12", cy: "5", rx: "9", ry: "3", key: "msslwz" }],
  ["path", { d: "M3 5V19A9 3 0 0 0 21 19V5", key: "1wlel7" }],
  ["path", { d: "M3 12A9 3 0 0 0 21 12", key: "mv7ke4" }]
]);

// node_modules/lucide-preact/dist/esm/icons/external-link.js
var ExternalLink = createLucideIcon("external-link", [
  ["path", { d: "M15 3h6v6", key: "1q9fwt" }],
  ["path", { d: "M10 14 21 3", key: "gplh6r" }],
  ["path", { d: "M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6", key: "a6xqqp" }]
]);

// node_modules/lucide-preact/dist/esm/icons/eye-off.js
var EyeOff = createLucideIcon("eye-off", [
  [
    "path",
    {
      d: "M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49",
      key: "ct8e1f"
    }
  ],
  ["path", { d: "M14.084 14.158a3 3 0 0 1-4.242-4.242", key: "151rxh" }],
  [
    "path",
    {
      d: "M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143",
      key: "13bj9a"
    }
  ],
  ["path", { d: "m2 2 20 20", key: "1ooewy" }]
]);

// node_modules/lucide-preact/dist/esm/icons/eye.js
var Eye = createLucideIcon("eye", [
  [
    "path",
    {
      d: "M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",
      key: "1nclc0"
    }
  ],
  ["circle", { cx: "12", cy: "12", r: "3", key: "1v7zrd" }]
]);

// node_modules/lucide-preact/dist/esm/icons/funnel.js
var Funnel = createLucideIcon("funnel", [
  [
    "path",
    {
      d: "M10 20a1 1 0 0 0 .553.895l2 1A1 1 0 0 0 14 21v-7a2 2 0 0 1 .517-1.341L21.74 4.67A1 1 0 0 0 21 3H3a1 1 0 0 0-.742 1.67l7.225 7.989A2 2 0 0 1 10 14z",
      key: "sc7q7i"
    }
  ]
]);

// node_modules/lucide-preact/dist/esm/icons/list.js
var List = createLucideIcon("list", [
  ["path", { d: "M3 5h.01", key: "18ugdj" }],
  ["path", { d: "M3 12h.01", key: "nlz23k" }],
  ["path", { d: "M3 19h.01", key: "noohij" }],
  ["path", { d: "M8 5h13", key: "1pao27" }],
  ["path", { d: "M8 12h13", key: "1za7za" }],
  ["path", { d: "M8 19h13", key: "m83p4d" }]
]);

// node_modules/lucide-preact/dist/esm/icons/loader-circle.js
var LoaderCircle = createLucideIcon("loader-circle", [
  ["path", { d: "M21 12a9 9 0 1 1-6.219-8.56", key: "13zald" }]
]);

// node_modules/lucide-preact/dist/esm/icons/play.js
var Play = createLucideIcon("play", [
  [
    "path",
    {
      d: "M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z",
      key: "10ikf1"
    }
  ]
]);

// node_modules/lucide-preact/dist/esm/icons/plus.js
var Plus = createLucideIcon("plus", [
  ["path", { d: "M5 12h14", key: "1ays0h" }],
  ["path", { d: "M12 5v14", key: "s699le" }]
]);

// node_modules/lucide-preact/dist/esm/icons/refresh-cw.js
var RefreshCw = createLucideIcon("refresh-cw", [
  ["path", { d: "M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8", key: "v9h5vc" }],
  ["path", { d: "M21 3v5h-5", key: "1q7to0" }],
  ["path", { d: "M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16", key: "3uifl3" }],
  ["path", { d: "M8 16H3v5", key: "1cv678" }]
]);

// node_modules/lucide-preact/dist/esm/icons/rotate-ccw.js
var RotateCcw = createLucideIcon("rotate-ccw", [
  ["path", { d: "M3 12a9 9 0 1 0 9-9 9.75 9.75 0 0 0-6.74 2.74L3 8", key: "1357e3" }],
  ["path", { d: "M3 3v5h5", key: "1xhq8a" }]
]);

// node_modules/lucide-preact/dist/esm/icons/save.js
var Save = createLucideIcon("save", [
  [
    "path",
    {
      d: "M15.2 3a2 2 0 0 1 1.4.6l3.8 3.8a2 2 0 0 1 .6 1.4V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2z",
      key: "1c8476"
    }
  ],
  ["path", { d: "M17 21v-7a1 1 0 0 0-1-1H8a1 1 0 0 0-1 1v7", key: "1ydtos" }],
  ["path", { d: "M7 3v4a1 1 0 0 0 1 1h7", key: "t51u73" }]
]);

// node_modules/lucide-preact/dist/esm/icons/search.js
var Search = createLucideIcon("search", [
  ["path", { d: "m21 21-4.34-4.34", key: "14j7rj" }],
  ["circle", { cx: "11", cy: "11", r: "8", key: "4ej97u" }]
]);

// node_modules/lucide-preact/dist/esm/icons/settings.js
var Settings = createLucideIcon("settings", [
  [
    "path",
    {
      d: "M9.671 4.136a2.34 2.34 0 0 1 4.659 0 2.34 2.34 0 0 0 3.319 1.915 2.34 2.34 0 0 1 2.33 4.033 2.34 2.34 0 0 0 0 3.831 2.34 2.34 0 0 1-2.33 4.033 2.34 2.34 0 0 0-3.319 1.915 2.34 2.34 0 0 1-4.659 0 2.34 2.34 0 0 0-3.32-1.915 2.34 2.34 0 0 1-2.33-4.033 2.34 2.34 0 0 0 0-3.831A2.34 2.34 0 0 1 6.35 6.051a2.34 2.34 0 0 0 3.319-1.915",
      key: "1i5ecw"
    }
  ],
  ["circle", { cx: "12", cy: "12", r: "3", key: "1v7zrd" }]
]);

// node_modules/lucide-preact/dist/esm/icons/shield.js
var Shield = createLucideIcon("shield", [
  [
    "path",
    {
      d: "M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",
      key: "oel41y"
    }
  ]
]);

// node_modules/lucide-preact/dist/esm/icons/square-check-big.js
var SquareCheckBig = createLucideIcon("square-check-big", [
  [
    "path",
    { d: "M21 10.656V19a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h12.344", key: "2acyp4" }
  ],
  ["path", { d: "m9 11 3 3L22 4", key: "1pflzl" }]
]);

// node_modules/lucide-preact/dist/esm/icons/square.js
var Square = createLucideIcon("square", [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }]
]);

// node_modules/lucide-preact/dist/esm/icons/thumbs-down.js
var ThumbsDown = createLucideIcon("thumbs-down", [
  [
    "path",
    {
      d: "M9 18.12 10 14H4.17a2 2 0 0 1-1.92-2.56l2.33-8A2 2 0 0 1 6.5 2H20a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2h-2.76a2 2 0 0 0-1.79 1.11L12 22a3.13 3.13 0 0 1-3-3.88Z",
      key: "m61m77"
    }
  ],
  ["path", { d: "M17 14V2", key: "8ymqnk" }]
]);

// node_modules/lucide-preact/dist/esm/icons/thumbs-up.js
var ThumbsUp = createLucideIcon("thumbs-up", [
  [
    "path",
    {
      d: "M15 5.88 14 10h5.83a2 2 0 0 1 1.92 2.56l-2.33 8A2 2 0 0 1 17.5 22H4a2 2 0 0 1-2-2v-8a2 2 0 0 1 2-2h2.76a2 2 0 0 0 1.79-1.11L12 2a3.13 3.13 0 0 1 3 3.88Z",
      key: "emmmcr"
    }
  ],
  ["path", { d: "M7 10v12", key: "1qc93n" }]
]);

// node_modules/lucide-preact/dist/esm/icons/trash-2.js
var Trash2 = createLucideIcon("trash-2", [
  ["path", { d: "M10 11v6", key: "nco0om" }],
  ["path", { d: "M14 11v6", key: "outv1u" }],
  ["path", { d: "M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6", key: "miytrc" }],
  ["path", { d: "M3 6h18", key: "d0wm0j" }],
  ["path", { d: "M8 6V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2", key: "e791ji" }]
]);

// node_modules/lucide-preact/dist/esm/icons/triangle-alert.js
var TriangleAlert = createLucideIcon("triangle-alert", [
  [
    "path",
    {
      d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",
      key: "wmoenq"
    }
  ],
  ["path", { d: "M12 9v4", key: "juzpu7" }],
  ["path", { d: "M12 17h.01", key: "p32p05" }]
]);

// node_modules/lucide-preact/dist/esm/icons/user-minus.js
var UserMinus = createLucideIcon("user-minus", [
  ["path", { d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2", key: "1yyitq" }],
  ["circle", { cx: "9", cy: "7", r: "4", key: "nufk8" }],
  ["line", { x1: "22", x2: "16", y1: "11", y2: "11", key: "1shjgl" }]
]);

// node_modules/lucide-preact/dist/esm/icons/user-plus.js
var UserPlus = createLucideIcon("user-plus", [
  ["path", { d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2", key: "1yyitq" }],
  ["circle", { cx: "9", cy: "7", r: "4", key: "nufk8" }],
  ["line", { x1: "19", x2: "19", y1: "8", y2: "14", key: "1bvyxn" }],
  ["line", { x1: "22", x2: "16", y1: "11", y2: "11", key: "1shjgl" }]
]);

// node_modules/lucide-preact/dist/esm/icons/user-x.js
var UserX = createLucideIcon("user-x", [
  ["path", { d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2", key: "1yyitq" }],
  ["circle", { cx: "9", cy: "7", r: "4", key: "nufk8" }],
  ["line", { x1: "17", x2: "22", y1: "8", y2: "13", key: "3nzzx3" }],
  ["line", { x1: "22", x2: "17", y1: "8", y2: "13", key: "1swrse" }]
]);

// node_modules/lucide-preact/dist/esm/icons/users.js
var Users = createLucideIcon("users", [
  ["path", { d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2", key: "1yyitq" }],
  ["path", { d: "M16 3.128a4 4 0 0 1 0 7.744", key: "16gr8j" }],
  ["path", { d: "M22 21v-2a4 4 0 0 0-3-3.87", key: "kshegd" }],
  ["circle", { cx: "9", cy: "7", r: "4", key: "nufk8" }]
]);

// src/components/manager/AmnestyTab.tsx
function AmnestyTab({
  onUnblock,
  onUnmute,
  onTempUnblockAndView,
  onFetchInteractions,
  onReload
}) {
  const [stats2, setStats] = d2({
    totalReviewed: 0,
    unblocked: 0,
    keptBlocked: 0,
    unmuted: 0,
    keptMuted: 0
  });
  const [processing, setProcessing] = d2(false);
  y2(() => {
    getAmnestyStats().then(setStats);
  }, []);
  const currentPeriod = options.value?.forgivenessPeriodDays || 90;
  const currentPeriodLabel = FORGIVENESS_OPTIONS.find((o4) => o4.value === currentPeriod)?.label || `${currentPeriod} days`;
  const candidates = getAmnestyCandidates(
    blocks.value,
    mutes.value,
    currentPeriod,
    amnestyReviewedDids.value
  );
  y2(() => {
    if (candidates.length > 0) {
      const candidateDids = candidates.map((c4) => c4.did);
      browser_default.runtime.sendMessage({
        type: "PREWARM_CLEARSKY_CACHE",
        targetDids: candidateDids
      }).catch(() => {
      });
    }
  }, [candidates.length]);
  const handlePeriodChange = async (e4) => {
    const newPeriod = parseInt(e4.target.value, 10);
    if (options.value) {
      const updated = { ...options.value, forgivenessPeriodDays: newPeriod };
      await setOptions(updated);
      options.value = updated;
    }
  };
  const startReview = async () => {
    const currentCandidates = getAmnestyCandidates(
      blocks.value,
      mutes.value,
      options.value?.forgivenessPeriodDays || 90,
      amnestyReviewedDids.value
    );
    const candidate = selectRandomCandidate(currentCandidates);
    if (!candidate) return;
    amnestyCandidate.value = candidate;
    const ctx = contextMap.value.get(candidate.did);
    const alreadySearchedNoResult = amnestySearchedNoContext.value.has(candidate.did);
    if (!ctx && !alreadySearchedNoResult) {
      amnestySearching.value = true;
      try {
        const response = await browser_default.runtime.sendMessage({
          type: "FIND_CONTEXT",
          did: candidate.did,
          handle: candidate.handle
        });
        if (response.found) {
          const newContexts = await getPostContexts();
          contexts.value = newContexts;
        } else {
          const newSet = new Set(amnestySearchedNoContext.value);
          newSet.add(candidate.did);
          amnestySearchedNoContext.value = newSet;
        }
      } catch (error) {
        console.error("[AmnestyTab] Failed to find context:", error);
      } finally {
        amnestySearching.value = false;
      }
    }
  };
  const handleDecision = async (decision) => {
    const candidate = amnestyCandidate.value;
    if (!candidate) return;
    setProcessing(true);
    try {
      if (decision === "unblocked") {
        await onUnblock(candidate.did);
      } else if (decision === "unmuted") {
        await onUnmute(candidate.did);
      }
      const isBlock = candidate.type === "block";
      const review = {
        did: candidate.did,
        handle: candidate.handle,
        reviewedAt: Date.now(),
        type: isBlock ? "block" : "mute",
        decision
      };
      await addAmnestyReview(review);
      const newReviewedDids = new Set(amnestyReviewedDids.value);
      newReviewedDids.add(candidate.did);
      amnestyReviewedDids.value = newReviewedDids;
      amnestyCandidate.value = null;
      await onReload();
      const newStats = await getAmnestyStats();
      setStats(newStats);
      startReview();
    } catch (error) {
      console.error("[AmnestyTab] Decision failed:", error);
      alert("Failed to process decision");
    } finally {
      setProcessing(false);
    }
  };
  const ModeToggle = () => /* @__PURE__ */ u4("div", { class: "amnesty-mode-toggle", children: [
    /* @__PURE__ */ u4(
      "button",
      {
        class: `amnesty-mode-btn ${amnestyMode.value === "blocks_mutes" ? "active" : ""}`,
        onClick: () => setAmnestyMode("blocks_mutes"),
        children: [
          /* @__PURE__ */ u4(Shield, { size: 16 }),
          " Blocks/Mutes"
        ]
      }
    ),
    /* @__PURE__ */ u4(
      "button",
      {
        class: `amnesty-mode-btn ${amnestyMode.value === "list_members" ? "active" : ""}`,
        onClick: () => setAmnestyMode("list_members"),
        children: [
          /* @__PURE__ */ u4(List, { size: 16 }),
          " List Members"
        ]
      }
    )
  ] });
  if (amnestyMode.value === "list_members") {
    return /* @__PURE__ */ u4(
      ListAuditMode,
      {
        onReload,
        onFetchInteractions,
        onTempUnblockAndView,
        ModeToggle
      }
    );
  }
  if (amnestyCandidate.value) {
    return /* @__PURE__ */ u4(
      AmnestyCard,
      {
        candidate: amnestyCandidate.value,
        stats: stats2,
        candidates,
        processing,
        onDecision: handleDecision,
        onViewPost: onTempUnblockAndView,
        ModeToggle,
        onFetchInteractions
      }
    );
  }
  const blockCount = candidates.filter((c4) => c4.type === "block").length;
  const muteCount = candidates.filter((c4) => c4.type === "mute").length;
  const freedCount = stats2.unblocked + stats2.unmuted;
  return /* @__PURE__ */ u4("div", { class: "amnesty-container", children: [
    /* @__PURE__ */ u4(ModeToggle, {}),
    /* @__PURE__ */ u4("div", { class: "amnesty-intro", children: [
      /* @__PURE__ */ u4("h3", { children: "Amnesty" }),
      /* @__PURE__ */ u4("p", { children: "Review old blocks and mutes to decide if they still deserve it." })
    ] }),
    /* @__PURE__ */ u4("div", { class: "amnesty-forgiveness", children: [
      /* @__PURE__ */ u4("label", { class: "amnesty-forgiveness-label", children: "How long does it take you to forgive?" }),
      /* @__PURE__ */ u4(
        "select",
        {
          class: "amnesty-forgiveness-select",
          value: currentPeriod,
          onChange: handlePeriodChange,
          children: FORGIVENESS_OPTIONS.map((opt) => /* @__PURE__ */ u4("option", { value: opt.value, children: opt.label }, opt.value))
        }
      ),
      /* @__PURE__ */ u4("p", { class: "amnesty-forgiveness-hint", children: "Only actions older than this will appear. Blocks from users blocking you back are excluded." })
    ] }),
    /* @__PURE__ */ u4("div", { class: "amnesty-stats", children: [
      /* @__PURE__ */ u4("div", { class: "amnesty-stat amnesty-stat-primary", children: [
        /* @__PURE__ */ u4("div", { class: "amnesty-stat-value", children: candidates.length }),
        /* @__PURE__ */ u4("div", { class: "amnesty-stat-label", children: "Ready for Review" }),
        candidates.length > 0 && /* @__PURE__ */ u4("div", { class: "amnesty-stat-detail", children: [
          blockCount,
          " blocks, ",
          muteCount,
          " mutes"
        ] })
      ] }),
      /* @__PURE__ */ u4("div", { class: "amnesty-stat", children: [
        /* @__PURE__ */ u4("div", { class: "amnesty-stat-value", children: stats2.totalReviewed }),
        /* @__PURE__ */ u4("div", { class: "amnesty-stat-label", children: "Reviewed" })
      ] }),
      /* @__PURE__ */ u4("div", { class: "amnesty-stat", children: [
        /* @__PURE__ */ u4("div", { class: "amnesty-stat-value", children: freedCount }),
        /* @__PURE__ */ u4("div", { class: "amnesty-stat-label", children: "Freed" })
      ] })
    ] }),
    candidates.length > 0 ? /* @__PURE__ */ u4("button", { class: "amnesty-start-btn", onClick: startReview, children: [
      /* @__PURE__ */ u4(Play, { size: 20 }),
      " Start Review"
    ] }) : /* @__PURE__ */ u4("div", { class: "amnesty-empty", children: [
      /* @__PURE__ */ u4("h3", { children: "No candidates available" }),
      /* @__PURE__ */ u4("p", { children: [
        "All eligible entries have been reviewed, or you don't have any blocks/mutes older than",
        " ",
        currentPeriodLabel,
        "."
      ] })
    ] })
  ] });
}
function AmnestyCard({
  candidate,
  stats: stats2,
  candidates,
  processing,
  onDecision,
  onViewPost,
  onFetchInteractions,
  ModeToggle
}) {
  const ctx = contextMap.value.get(candidate.did);
  const actionDate = candidate.createdAt || candidate.syncedAt;
  const actionDateStr = actionDate ? new Date(actionDate).toLocaleDateString() : "Unknown";
  const isBlock = candidate.type === "block";
  const actionVerb = isBlock ? "Blocked" : "Muted";
  const actionVerbLower = isBlock ? "block" : "mute";
  const freedCount = stats2.unblocked + stats2.unmuted;
  const isExpanded = expandedRows.value.has(candidate.did);
  const postUrl = ctx?.postUri ? postUriToUrl(ctx.postUri) : "";
  const [followsWhoFollow, setFollowsWhoFollow] = d2({ users: [], loading: true });
  const [followersWhoFollow, setFollowersWhoFollow] = d2({ users: [], loading: true });
  const [followsTheyBlock, setFollowsTheyBlock] = d2({ users: [], loading: true });
  const [followsWhoBlockThem, setFollowsWhoBlockThem] = d2({ users: [], count: 0, totalBlockers: 0, loading: true });
  const [followsFollowExpanded, setFollowsFollowExpanded] = d2(false);
  const [followersFollowExpanded, setFollowersFollowExpanded] = d2(false);
  const [followsBlockedExpanded, setFollowsBlockedExpanded] = d2(false);
  const [followsWhoBlockExpanded, setFollowsWhoBlockExpanded] = d2(false);
  const [profileStats, setProfileStats] = d2({ followersCount: 0, followsCount: 0, postsCount: 0, loading: true });
  y2(() => {
    let cancelled = false;
    const fetchFollowsWhoFollow = async () => {
      try {
        const response = await browser_default.runtime.sendMessage({
          type: "GET_FOLLOWS_WHO_FOLLOW_THEM",
          did: candidate.did
        });
        if (!cancelled && response.success) {
          setFollowsWhoFollow({ users: response.users || [], loading: false });
        } else if (!cancelled) {
          setFollowsWhoFollow((prev) => ({ ...prev, loading: false }));
        }
      } catch {
        if (!cancelled) {
          setFollowsWhoFollow((prev) => ({ ...prev, loading: false }));
        }
      }
    };
    const fetchFollowersWhoFollow = async () => {
      try {
        const response = await browser_default.runtime.sendMessage({
          type: "GET_FOLLOWERS_WHO_FOLLOW_THEM",
          did: candidate.did
        });
        if (!cancelled && response.success) {
          setFollowersWhoFollow({ users: response.users || [], loading: false });
        } else if (!cancelled) {
          setFollowersWhoFollow((prev) => ({ ...prev, loading: false }));
        }
      } catch {
        if (!cancelled) {
          setFollowersWhoFollow((prev) => ({ ...prev, loading: false }));
        }
      }
    };
    const fetchFollowsTheyBlock = async () => {
      try {
        const response = await browser_default.runtime.sendMessage({
          type: "GET_FOLLOWS_THEY_BLOCK",
          did: candidate.did
        });
        if (!cancelled && response.success) {
          setFollowsTheyBlock({ users: response.users || [], loading: false });
        } else if (!cancelled) {
          setFollowsTheyBlock((prev) => ({ ...prev, loading: false }));
        }
      } catch {
        if (!cancelled) {
          setFollowsTheyBlock((prev) => ({ ...prev, loading: false }));
        }
      }
    };
    const fetchFollowsWhoBlockThem = async () => {
      try {
        const response = await browser_default.runtime.sendMessage({
          type: "GET_FOLLOWS_WHO_BLOCK_THEM",
          did: candidate.did
        });
        if (!cancelled && response.success) {
          setFollowsWhoBlockThem({
            users: response.users || [],
            count: response.count || 0,
            totalBlockers: response.totalBlockers || 0,
            loading: false
          });
        } else if (!cancelled) {
          setFollowsWhoBlockThem((prev) => ({ ...prev, loading: false }));
        }
      } catch {
        if (!cancelled) {
          setFollowsWhoBlockThem((prev) => ({ ...prev, loading: false }));
        }
      }
    };
    fetchFollowsWhoFollow();
    fetchFollowersWhoFollow();
    fetchFollowsTheyBlock();
    fetchFollowsWhoBlockThem();
    return () => {
      cancelled = true;
    };
  }, [candidate.did]);
  y2(() => {
    let cancelled = false;
    const fetchStats = async () => {
      try {
        const response = await fetch(
          `https://public.api.bsky.app/xrpc/app.bsky.actor.getProfile?actor=${encodeURIComponent(candidate.did)}`
        );
        if (response.ok) {
          const profile = await response.json();
          if (!cancelled) {
            setProfileStats({
              followersCount: profile.followersCount || 0,
              followsCount: profile.followsCount || 0,
              postsCount: profile.postsCount || 0,
              loading: false
            });
          }
        } else if (!cancelled) {
          setProfileStats((prev) => ({ ...prev, loading: false }));
        }
      } catch {
        if (!cancelled) {
          setProfileStats((prev) => ({ ...prev, loading: false }));
        }
      }
    };
    fetchStats();
    return () => {
      cancelled = true;
    };
  }, [candidate.did]);
  y2(() => {
    if (candidates.length <= 1) return;
    const otherCandidates = candidates.filter((c4) => c4.did !== candidate.did);
    const lookaheadDids = otherCandidates.slice(0, 3).map((c4) => c4.did);
    if (lookaheadDids.length > 0) {
      browser_default.runtime.sendMessage({
        type: "PREFETCH_CLEARSKY_LOOKAHEAD",
        targetDids: lookaheadDids
      }).catch(() => {
      });
    }
  }, [candidate.did, candidates.length]);
  return /* @__PURE__ */ u4("div", { class: "amnesty-container", children: [
    /* @__PURE__ */ u4(ModeToggle, {}),
    /* @__PURE__ */ u4("div", { class: "amnesty-stats", children: [
      /* @__PURE__ */ u4("div", { class: "amnesty-stat", children: [
        /* @__PURE__ */ u4("div", { class: "amnesty-stat-value", children: candidates.length }),
        /* @__PURE__ */ u4("div", { class: "amnesty-stat-label", children: "Remaining" })
      ] }),
      /* @__PURE__ */ u4("div", { class: "amnesty-stat", children: [
        /* @__PURE__ */ u4("div", { class: "amnesty-stat-value", children: stats2.totalReviewed }),
        /* @__PURE__ */ u4("div", { class: "amnesty-stat-label", children: "Reviewed" })
      ] }),
      /* @__PURE__ */ u4("div", { class: "amnesty-stat", children: [
        /* @__PURE__ */ u4("div", { class: "amnesty-stat-value", children: freedCount }),
        /* @__PURE__ */ u4("div", { class: "amnesty-stat-label", children: "Freed" })
      ] })
    ] }),
    /* @__PURE__ */ u4("div", { class: `amnesty-card ${isBlock ? "amnesty-card-block" : "amnesty-card-mute"}`, children: [
      /* @__PURE__ */ u4("div", { class: "amnesty-card-header", children: [
        candidate.avatar ? /* @__PURE__ */ u4("img", { src: candidate.avatar, class: "amnesty-avatar", alt: "", loading: "lazy" }) : /* @__PURE__ */ u4("div", { class: "amnesty-avatar" }),
        /* @__PURE__ */ u4("div", { class: "amnesty-user-info", children: [
          /* @__PURE__ */ u4("div", { class: "amnesty-handle", children: [
            "@",
            candidate.handle
          ] }),
          candidate.displayName && /* @__PURE__ */ u4("div", { class: "amnesty-display-name", children: candidate.displayName }),
          /* @__PURE__ */ u4("div", { class: "amnesty-blocked-date", children: [
            /* @__PURE__ */ u4("span", { class: `amnesty-type-badge ${isBlock ? "badge-block" : "badge-mute"}`, children: actionVerb }),
            "on ",
            actionDateStr
          ] })
        ] })
      ] }),
      !profileStats.loading && /* @__PURE__ */ u4("div", { class: "amnesty-profile-stats", children: [
        /* @__PURE__ */ u4("span", { class: "amnesty-profile-stat", children: [
          /* @__PURE__ */ u4("strong", { children: profileStats.followersCount.toLocaleString() }),
          " followers"
        ] }),
        /* @__PURE__ */ u4("span", { class: "amnesty-profile-stat", children: [
          /* @__PURE__ */ u4("strong", { children: profileStats.followsCount.toLocaleString() }),
          " following"
        ] }),
        /* @__PURE__ */ u4("span", { class: "amnesty-profile-stat", children: [
          /* @__PURE__ */ u4("strong", { children: profileStats.postsCount.toLocaleString() }),
          " posts"
        ] })
      ] }),
      /* @__PURE__ */ u4("div", { class: "amnesty-block-relations", children: [
        /* @__PURE__ */ u4("div", { class: "amnesty-block-rel-section", children: followsWhoFollow.loading ? /* @__PURE__ */ u4("div", { class: "amnesty-rel-loading", children: [
          /* @__PURE__ */ u4(LoaderCircle, { size: 14, class: "spinner" }),
          /* @__PURE__ */ u4("span", { children: "Checking your follows..." })
        ] }) : /* @__PURE__ */ u4(k, { children: [
          /* @__PURE__ */ u4(
            "button",
            {
              type: "button",
              class: "amnesty-block-rel-header amnesty-follows-follow",
              onClick: () => followsWhoFollow.users.length > 0 && setFollowsFollowExpanded(!followsFollowExpanded),
              disabled: followsWhoFollow.users.length === 0,
              children: [
                /* @__PURE__ */ u4(Users, { size: 14 }),
                /* @__PURE__ */ u4("span", { children: [
                  /* @__PURE__ */ u4("strong", { children: followsWhoFollow.users.length }),
                  " ",
                  followsWhoFollow.users.length === 1 ? "person" : "people",
                  " you follow",
                  " ",
                  followsWhoFollow.users.length === 1 ? "follows" : "follow",
                  " them"
                ] }),
                followsWhoFollow.users.length > 0 && (followsFollowExpanded ? /* @__PURE__ */ u4(ChevronDown, { size: 14 }) : /* @__PURE__ */ u4(ChevronRight, { size: 14 }))
              ]
            }
          ),
          followsFollowExpanded && followsWhoFollow.users.length > 0 && /* @__PURE__ */ u4("div", { class: "amnesty-block-rel-list", children: followsWhoFollow.users.map((u5) => /* @__PURE__ */ u4(
            "a",
            {
              href: `https://bsky.app/profile/${u5.handle}`,
              target: "_blank",
              rel: "noopener noreferrer",
              class: "amnesty-block-rel-user",
              children: [
                "@",
                u5.handle,
                u5.displayName && /* @__PURE__ */ u4("span", { class: "amnesty-block-rel-name", children: [
                  " (",
                  u5.displayName,
                  ")"
                ] })
              ]
            },
            u5.handle
          )) })
        ] }) }),
        /* @__PURE__ */ u4("div", { class: "amnesty-block-rel-section", children: followersWhoFollow.loading ? /* @__PURE__ */ u4("div", { class: "amnesty-rel-loading", children: [
          /* @__PURE__ */ u4(LoaderCircle, { size: 14, class: "spinner" }),
          /* @__PURE__ */ u4("span", { children: "Checking your followers..." })
        ] }) : /* @__PURE__ */ u4(k, { children: [
          /* @__PURE__ */ u4(
            "button",
            {
              type: "button",
              class: "amnesty-block-rel-header amnesty-followers-follow",
              onClick: () => followersWhoFollow.users.length > 0 && setFollowersFollowExpanded(!followersFollowExpanded),
              disabled: followersWhoFollow.users.length === 0,
              children: [
                /* @__PURE__ */ u4(Users, { size: 14 }),
                /* @__PURE__ */ u4("span", { children: [
                  /* @__PURE__ */ u4("strong", { children: followersWhoFollow.users.length }),
                  " of your followers",
                  " ",
                  followersWhoFollow.users.length === 1 ? "follows" : "follow",
                  " them"
                ] }),
                followersWhoFollow.users.length > 0 && (followersFollowExpanded ? /* @__PURE__ */ u4(ChevronDown, { size: 14 }) : /* @__PURE__ */ u4(ChevronRight, { size: 14 }))
              ]
            }
          ),
          followersFollowExpanded && followersWhoFollow.users.length > 0 && /* @__PURE__ */ u4("div", { class: "amnesty-block-rel-list", children: followersWhoFollow.users.map((u5) => /* @__PURE__ */ u4(
            "a",
            {
              href: `https://bsky.app/profile/${u5.handle}`,
              target: "_blank",
              rel: "noopener noreferrer",
              class: "amnesty-block-rel-user",
              children: [
                "@",
                u5.handle,
                u5.displayName && /* @__PURE__ */ u4("span", { class: "amnesty-block-rel-name", children: [
                  " (",
                  u5.displayName,
                  ")"
                ] })
              ]
            },
            u5.handle
          )) })
        ] }) }),
        /* @__PURE__ */ u4("div", { class: "amnesty-block-rel-section", children: followsTheyBlock.loading ? /* @__PURE__ */ u4("div", { class: "amnesty-rel-loading", children: [
          /* @__PURE__ */ u4(LoaderCircle, { size: 14, class: "spinner" }),
          /* @__PURE__ */ u4("span", { children: "Checking who they block..." })
        ] }) : /* @__PURE__ */ u4(k, { children: [
          /* @__PURE__ */ u4(
            "button",
            {
              type: "button",
              class: "amnesty-block-rel-header amnesty-blocking",
              onClick: () => followsTheyBlock.users.length > 0 && setFollowsBlockedExpanded(!followsBlockedExpanded),
              disabled: followsTheyBlock.users.length === 0,
              children: [
                /* @__PURE__ */ u4(Shield, { size: 14 }),
                /* @__PURE__ */ u4("span", { children: [
                  "They block ",
                  /* @__PURE__ */ u4("strong", { children: followsTheyBlock.users.length }),
                  " ",
                  followsTheyBlock.users.length === 1 ? "person" : "people",
                  " you follow"
                ] }),
                followsTheyBlock.users.length > 0 && (followsBlockedExpanded ? /* @__PURE__ */ u4(ChevronDown, { size: 14 }) : /* @__PURE__ */ u4(ChevronRight, { size: 14 }))
              ]
            }
          ),
          followsBlockedExpanded && followsTheyBlock.users.length > 0 && /* @__PURE__ */ u4("div", { class: "amnesty-block-rel-list", children: followsTheyBlock.users.map((u5) => /* @__PURE__ */ u4(
            "a",
            {
              href: `https://bsky.app/profile/${u5.handle}`,
              target: "_blank",
              rel: "noopener noreferrer",
              class: "amnesty-block-rel-user",
              children: [
                "@",
                u5.handle,
                u5.displayName && /* @__PURE__ */ u4("span", { class: "amnesty-block-rel-name", children: [
                  " (",
                  u5.displayName,
                  ")"
                ] })
              ]
            },
            u5.handle
          )) })
        ] }) }),
        /* @__PURE__ */ u4("div", { class: "amnesty-block-rel-section", children: followsWhoBlockThem.loading ? /* @__PURE__ */ u4("div", { class: "amnesty-rel-loading", children: [
          /* @__PURE__ */ u4(LoaderCircle, { size: 14, class: "spinner" }),
          /* @__PURE__ */ u4("span", { children: "Checking community blocks..." })
        ] }) : /* @__PURE__ */ u4(k, { children: [
          /* @__PURE__ */ u4(
            "button",
            {
              type: "button",
              class: `amnesty-block-rel-header amnesty-community-blocks ${followsWhoBlockThem.count > 0 ? "has-blocks" : ""}`,
              onClick: () => followsWhoBlockThem.users.length > 0 && setFollowsWhoBlockExpanded(!followsWhoBlockExpanded),
              disabled: followsWhoBlockThem.users.length === 0,
              children: [
                /* @__PURE__ */ u4(TriangleAlert, { size: 14 }),
                /* @__PURE__ */ u4("span", { children: [
                  /* @__PURE__ */ u4("strong", { children: followsWhoBlockThem.count }),
                  " ",
                  followsWhoBlockThem.count === 1 ? "person" : "people",
                  " you follow",
                  " ",
                  followsWhoBlockThem.count === 1 ? "blocks" : "block",
                  " them",
                  followsWhoBlockThem.totalBlockers > 0 && /* @__PURE__ */ u4("span", { class: "amnesty-total-blockers", children: [
                    " ",
                    "(",
                    followsWhoBlockThem.totalBlockers.toLocaleString(),
                    " total)"
                  ] })
                ] }),
                followsWhoBlockThem.users.length > 0 && (followsWhoBlockExpanded ? /* @__PURE__ */ u4(ChevronDown, { size: 14 }) : /* @__PURE__ */ u4(ChevronRight, { size: 14 }))
              ]
            }
          ),
          followsWhoBlockExpanded && followsWhoBlockThem.users.length > 0 && /* @__PURE__ */ u4("div", { class: "amnesty-block-rel-list", children: followsWhoBlockThem.users.map((u5) => /* @__PURE__ */ u4(
            "a",
            {
              href: `https://bsky.app/profile/${u5.handle}`,
              target: "_blank",
              rel: "noopener noreferrer",
              class: "amnesty-block-rel-user",
              children: [
                "@",
                u5.handle,
                u5.displayName && /* @__PURE__ */ u4("span", { class: "amnesty-block-rel-name", children: [
                  " (",
                  u5.displayName,
                  ")"
                ] })
              ]
            },
            u5.handle
          )) })
        ] }) })
      ] }),
      /* @__PURE__ */ u4("div", { class: "amnesty-card-context", children: [
        /* @__PURE__ */ u4("div", { class: "amnesty-context-header", children: [
          /* @__PURE__ */ u4("div", { class: "amnesty-context-label", children: [
            "Why did you ",
            actionVerbLower,
            " them?"
          ] }),
          /* @__PURE__ */ u4(
            "button",
            {
              class: `context-btn expand-btn ${isExpanded ? "expanded" : ""}`,
              onClick: () => toggleExpanded(candidate.did),
              title: isExpanded ? "Collapse" : "Show all interactions",
              children: [
                isExpanded ? /* @__PURE__ */ u4(ChevronDown, { size: 14 }) : /* @__PURE__ */ u4(ChevronRight, { size: 14 }),
                isExpanded ? "Less" : "More"
              ]
            }
          )
        ] }),
        amnestySearching.value ? /* @__PURE__ */ u4("div", { class: "amnesty-searching", children: [
          /* @__PURE__ */ u4(LoaderCircle, { size: 16, class: "spinner" }),
          "Searching for interaction..."
        ] }) : ctx ? /* @__PURE__ */ u4(k, { children: [
          /* @__PURE__ */ u4("div", { class: "amnesty-context-speaker", children: [
            ctx.postAuthorDid === candidate.did ? /* @__PURE__ */ u4("strong", { children: [
              "@",
              candidate.handle
            ] }) : ctx.engagementType ? /* @__PURE__ */ u4(k, { children: [
              /* @__PURE__ */ u4("strong", { children: [
                "@",
                candidate.handle
              ] }),
              " ",
              ctx.engagementType === "like" ? "liked" : "reposted",
              " your post:"
            ] }) : /* @__PURE__ */ u4("strong", { children: [
              "@",
              ctx.postAuthorHandle || "unknown"
            ] }),
            ctx.postAuthorDid === candidate.did && ":"
          ] }),
          /* @__PURE__ */ u4("div", { class: "amnesty-context-text", children: ctx.postText || "No post text available" }),
          postUrl && /* @__PURE__ */ u4("div", { class: "amnesty-context-link", children: isBlock ? /* @__PURE__ */ u4(
            "button",
            {
              class: "context-btn amnesty-view-btn",
              onClick: () => onViewPost(candidate.did, candidate.handle, postUrl),
              children: [
                /* @__PURE__ */ u4(ExternalLink, { size: 12 }),
                " View Post"
              ]
            }
          ) : /* @__PURE__ */ u4("a", { href: postUrl, target: "_blank", rel: "noopener", class: "context-btn", children: [
            /* @__PURE__ */ u4(ExternalLink, { size: 12 }),
            " View Post"
          ] }) })
        ] }) : /* @__PURE__ */ u4("div", { class: "amnesty-no-context", children: [
          "No context found for this ",
          actionVerbLower
        ] }),
        isExpanded && /* @__PURE__ */ u4("div", { class: "amnesty-interactions-expanded", children: /* @__PURE__ */ u4(
          InteractionsList,
          {
            did: candidate.did,
            handle: candidate.handle,
            isBlocked: isBlock,
            onFetchInteractions,
            onViewPost
          }
        ) })
      ] }),
      /* @__PURE__ */ u4("div", { class: "amnesty-card-actions", children: [
        /* @__PURE__ */ u4(
          "button",
          {
            class: `amnesty-btn ${isBlock ? "amnesty-btn-unblock" : "amnesty-btn-unmute"}`,
            onClick: () => {
              onDecision(isBlock ? "unblocked" : "unmuted").catch((err) => {
                console.error("[AmnestyCard] Decision error:", err);
              });
            },
            disabled: processing,
            children: [
              /* @__PURE__ */ u4(ThumbsUp, { size: 18 }),
              " ",
              isBlock ? "Unblock" : "Unmute"
            ]
          }
        ),
        /* @__PURE__ */ u4(
          "button",
          {
            class: "amnesty-btn amnesty-btn-keep",
            onClick: () => {
              onDecision(isBlock ? "kept_blocked" : "kept_muted").catch((err) => {
                console.error("[AmnestyCard] Decision error:", err);
              });
            },
            disabled: processing,
            children: [
              /* @__PURE__ */ u4(ThumbsDown, { size: 18 }),
              " Keep ",
              actionVerb
            ]
          }
        )
      ] })
    ] })
  ] });
}
function ListAuditMode({
  onReload: _onReload,
  onFetchInteractions,
  onTempUnblockAndView,
  ModeToggle
}) {
  const [processing, setProcessing] = d2(false);
  const [stats2, setStats] = d2({ reviewed: 0, removed: 0, kept: 0 });
  const [loadingLists, setLoadingLists] = d2(false);
  const [loadingMembers, setLoadingMembers] = d2(false);
  y2(() => {
    const fetchLists = async () => {
      if (ownedLists.value.length > 0) return;
      setLoadingLists(true);
      try {
        const response = await browser_default.runtime.sendMessage({
          type: "FETCH_OWNED_LISTS"
        });
        if (response.success && response.lists) {
          ownedLists.value = response.lists;
        }
      } catch (error) {
        console.error("[ListAuditMode] Failed to fetch owned lists:", error);
      } finally {
        setLoadingLists(false);
      }
    };
    fetchLists();
  }, []);
  y2(() => {
    if (selectedListUri.value) {
      getListAuditStats(selectedListUri.value).then(setStats);
      getListAuditReviewedDids(selectedListUri.value).then((dids) => {
        listAuditReviewedDids.value = dids;
      });
    }
  }, [selectedListUri.value]);
  const handleListChange = async (e4) => {
    const uri = e4.target.value;
    selectList(uri || null);
    if (uri) {
      setLoadingMembers(true);
      try {
        const response = await browser_default.runtime.sendMessage({
          type: "FETCH_LIST_MEMBERS_WITH_TIMESTAMPS",
          listUri: uri
        });
        if (response.success && response.members) {
          listMembers.value = response.members;
        }
      } catch (error) {
        console.error("[ListAuditMode] Failed to fetch list members:", error);
      } finally {
        setLoadingMembers(false);
      }
    }
  };
  const startReview = () => {
    const candidates2 = getListAuditCandidates(listMembers.value, listAuditReviewedDids.value);
    const candidate = selectRandomListMember(candidates2);
    if (candidate) {
      listAuditCandidate.value = candidate;
    }
  };
  const handleDecision = async (decision) => {
    const candidate = listAuditCandidate.value;
    if (!candidate) return;
    setProcessing(true);
    try {
      if (decision === "removed") {
        const response = await browser_default.runtime.sendMessage({
          type: "REMOVE_FROM_LIST",
          rkey: candidate.listitemRkey
        });
        if (!response.success) {
          throw new Error(response.error || "Failed to remove from list");
        }
        listMembers.value = listMembers.value.filter((m4) => m4.did !== candidate.did);
      }
      const review = {
        did: candidate.did,
        handle: candidate.handle,
        listUri: candidate.listUri,
        listName: candidate.listName,
        reviewedAt: Date.now(),
        decision
      };
      await addListAuditReview(review);
      const newReviewedDids = new Set(listAuditReviewedDids.value);
      newReviewedDids.add(candidate.did);
      listAuditReviewedDids.value = newReviewedDids;
      const newStats = await getListAuditStats(candidate.listUri);
      setStats(newStats);
      listAuditCandidate.value = null;
      startReview();
    } catch (error) {
      console.error("[ListAuditMode] Decision failed:", error);
      alert("Failed to process decision");
    } finally {
      setProcessing(false);
    }
  };
  if (listAuditCandidate.value) {
    const candidates2 = getListAuditCandidates(listMembers.value, listAuditReviewedDids.value);
    return /* @__PURE__ */ u4(
      ListAuditCard,
      {
        member: listAuditCandidate.value,
        stats: stats2,
        candidatesRemaining: candidates2.length,
        processing,
        onDecision: handleDecision,
        onFetchInteractions,
        onViewPost: onTempUnblockAndView,
        ModeToggle
      }
    );
  }
  const candidates = getListAuditCandidates(listMembers.value, listAuditReviewedDids.value);
  return /* @__PURE__ */ u4("div", { class: "amnesty-container", children: [
    /* @__PURE__ */ u4(ModeToggle, {}),
    /* @__PURE__ */ u4("div", { class: "amnesty-intro", children: [
      /* @__PURE__ */ u4("h3", { children: "List Audit" }),
      /* @__PURE__ */ u4("p", { children: "Review members of your lists to see if they still belong there." })
    ] }),
    /* @__PURE__ */ u4("div", { class: "amnesty-forgiveness", children: [
      /* @__PURE__ */ u4("label", { class: "amnesty-forgiveness-label", children: "Select a list to audit" }),
      loadingLists ? /* @__PURE__ */ u4("div", { class: "amnesty-loading", children: [
        /* @__PURE__ */ u4(LoaderCircle, { size: 20, class: "spin" }),
        " Loading your lists..."
      ] }) : /* @__PURE__ */ u4(
        "select",
        {
          class: "amnesty-forgiveness-select",
          value: selectedListUri.value || "",
          onChange: handleListChange,
          children: [
            /* @__PURE__ */ u4("option", { value: "", children: "Select a list..." }),
            ownedLists.value.map((list) => /* @__PURE__ */ u4("option", { value: list.uri, children: [
              list.name,
              " (",
              list.listItemCount,
              " members)"
            ] }, list.uri))
          ]
        }
      ),
      ownedLists.value.length === 0 && !loadingLists && /* @__PURE__ */ u4("p", { class: "amnesty-forgiveness-hint", children: "You don't have any lists to audit." })
    ] }),
    loadingMembers && /* @__PURE__ */ u4("div", { class: "amnesty-loading", children: [
      /* @__PURE__ */ u4(LoaderCircle, { size: 20, class: "spin" }),
      " Loading list members..."
    ] }),
    selectedListUri.value && !loadingMembers && /* @__PURE__ */ u4(k, { children: [
      /* @__PURE__ */ u4("div", { class: "amnesty-stats", children: [
        /* @__PURE__ */ u4("div", { class: "amnesty-stat amnesty-stat-primary", children: [
          /* @__PURE__ */ u4("div", { class: "amnesty-stat-value", children: candidates.length }),
          /* @__PURE__ */ u4("div", { class: "amnesty-stat-label", children: "Ready for Review" }),
          listMembers.value.length > 0 && /* @__PURE__ */ u4("div", { class: "amnesty-stat-detail", children: [
            listMembers.value.length,
            " total members"
          ] })
        ] }),
        /* @__PURE__ */ u4("div", { class: "amnesty-stat", children: [
          /* @__PURE__ */ u4("div", { class: "amnesty-stat-value", children: stats2.reviewed }),
          /* @__PURE__ */ u4("div", { class: "amnesty-stat-label", children: "Reviewed" })
        ] }),
        /* @__PURE__ */ u4("div", { class: "amnesty-stat", children: [
          /* @__PURE__ */ u4("div", { class: "amnesty-stat-value", children: stats2.removed }),
          /* @__PURE__ */ u4("div", { class: "amnesty-stat-label", children: "Removed" })
        ] })
      ] }),
      candidates.length > 0 ? /* @__PURE__ */ u4("button", { class: "amnesty-start-btn", onClick: startReview, children: [
        /* @__PURE__ */ u4(Play, { size: 20 }),
        " Start Review"
      ] }) : /* @__PURE__ */ u4("div", { class: "amnesty-empty", children: [
        /* @__PURE__ */ u4("h3", { children: "No members to review" }),
        /* @__PURE__ */ u4("p", { children: listMembers.value.length === 0 ? "This list has no members." : "All members have been reviewed." })
      ] })
    ] })
  ] });
}
function ListAuditCard({
  member,
  stats: stats2,
  candidatesRemaining,
  processing,
  onDecision,
  onFetchInteractions: _onFetchInteractions,
  onViewPost: _onViewPost,
  ModeToggle
}) {
  const [loadingInteractions, setLoadingInteractions] = d2(false);
  const [interactions, setLocalInteractions] = d2([]);
  const [interactionsLoaded, setInteractionsLoaded] = d2(false);
  const isExpanded = expandedRows.value.has(member.did);
  const addedDateStr = new Date(member.addedAt).toLocaleDateString();
  y2(() => {
    const fetchInteractions = async () => {
      setLoadingInteractions(true);
      try {
        const response = await browser_default.runtime.sendMessage({
          type: "FIND_INTERACTIONS_BEFORE",
          targetDid: member.did,
          beforeTimestamp: member.addedAt
        });
        if (response.success && response.interactions) {
          setLocalInteractions(response.interactions);
          setInteractions(member.did, response.interactions);
        }
      } catch (error) {
        console.error("[ListAuditCard] Failed to fetch interactions:", error);
      } finally {
        setLoadingInteractions(false);
        setInteractionsLoaded(true);
      }
    };
    fetchInteractions();
  }, [member.did, member.addedAt]);
  return /* @__PURE__ */ u4("div", { class: "amnesty-container", children: [
    /* @__PURE__ */ u4(ModeToggle, {}),
    /* @__PURE__ */ u4("div", { class: "amnesty-stats", children: [
      /* @__PURE__ */ u4("div", { class: "amnesty-stat", children: [
        /* @__PURE__ */ u4("div", { class: "amnesty-stat-value", children: candidatesRemaining }),
        /* @__PURE__ */ u4("div", { class: "amnesty-stat-label", children: "Remaining" })
      ] }),
      /* @__PURE__ */ u4("div", { class: "amnesty-stat", children: [
        /* @__PURE__ */ u4("div", { class: "amnesty-stat-value", children: stats2.reviewed }),
        /* @__PURE__ */ u4("div", { class: "amnesty-stat-label", children: "Reviewed" })
      ] }),
      /* @__PURE__ */ u4("div", { class: "amnesty-stat", children: [
        /* @__PURE__ */ u4("div", { class: "amnesty-stat-value", children: stats2.removed }),
        /* @__PURE__ */ u4("div", { class: "amnesty-stat-label", children: "Removed" })
      ] })
    ] }),
    /* @__PURE__ */ u4("div", { class: "amnesty-card amnesty-card-list", children: [
      /* @__PURE__ */ u4("div", { class: "amnesty-card-header", children: [
        member.avatar ? /* @__PURE__ */ u4("img", { src: member.avatar, class: "amnesty-avatar", alt: "", loading: "lazy" }) : /* @__PURE__ */ u4("div", { class: "amnesty-avatar" }),
        /* @__PURE__ */ u4("div", { class: "amnesty-user-info", children: [
          /* @__PURE__ */ u4("div", { class: "amnesty-handle", children: [
            "@",
            member.handle
          ] }),
          member.displayName && /* @__PURE__ */ u4("div", { class: "amnesty-display-name", children: member.displayName }),
          /* @__PURE__ */ u4("div", { class: "amnesty-blocked-date", children: [
            /* @__PURE__ */ u4("span", { class: "amnesty-type-badge badge-list", children: [
              /* @__PURE__ */ u4(List, { size: 12 }),
              " ",
              member.listName
            ] }),
            "Added ",
            addedDateStr
          ] })
        ] })
      ] }),
      /* @__PURE__ */ u4("div", { class: "amnesty-context-container", children: [
        /* @__PURE__ */ u4("div", { class: "amnesty-context-header", children: /* @__PURE__ */ u4(
          "button",
          {
            class: "amnesty-context-toggle",
            onClick: () => toggleExpanded(member.did),
            disabled: loadingInteractions,
            children: [
              isExpanded ? /* @__PURE__ */ u4(ChevronDown, { size: 16 }) : /* @__PURE__ */ u4(ChevronRight, { size: 16 }),
              "Interactions before adding to list"
            ]
          }
        ) }),
        loadingInteractions && /* @__PURE__ */ u4("div", { class: "amnesty-loading", children: [
          /* @__PURE__ */ u4(LoaderCircle, { size: 16, class: "spin" }),
          " Finding interactions..."
        ] }),
        interactionsLoaded && !loadingInteractions && /* @__PURE__ */ u4(k, { children: interactions.length > 0 ? /* @__PURE__ */ u4("div", { class: "amnesty-context-summary", children: [
          "Found ",
          interactions.length,
          " interaction",
          interactions.length !== 1 ? "s" : "",
          " ",
          "before you added them"
        ] }) : /* @__PURE__ */ u4("div", { class: "amnesty-no-context", children: "No interactions found before you added them to this list" }) }),
        isExpanded && interactions.length > 0 && /* @__PURE__ */ u4("div", { class: "amnesty-interactions-expanded", children: /* @__PURE__ */ u4("div", { class: "interactions-list", children: [
          interactions.slice(0, 10).map((interaction, idx) => /* @__PURE__ */ u4("div", { class: "interaction-item", children: [
            /* @__PURE__ */ u4("div", { class: "interaction-header", children: [
              /* @__PURE__ */ u4("span", { class: `interaction-type ${interaction.type}`, children: interaction.type }),
              /* @__PURE__ */ u4("span", { class: "interaction-author", children: interaction.author === "you" ? "You" : `@${interaction.authorHandle}` }),
              /* @__PURE__ */ u4("span", { class: "interaction-date", children: formatTimeAgo(interaction.createdAt) })
            ] }),
            /* @__PURE__ */ u4("div", { class: "interaction-text", children: interaction.text })
          ] }, idx)),
          interactions.length > 10 && /* @__PURE__ */ u4("div", { class: "interaction-more", children: [
            "And ",
            interactions.length - 10,
            " more interactions..."
          ] })
        ] }) })
      ] }),
      /* @__PURE__ */ u4("div", { class: "amnesty-card-actions", children: [
        /* @__PURE__ */ u4(
          "button",
          {
            class: "amnesty-btn amnesty-btn-keep",
            onClick: () => {
              onDecision("kept").catch((err) => {
                console.error("[ListAuditCard] Decision error:", err);
              });
            },
            disabled: processing,
            children: [
              /* @__PURE__ */ u4(ThumbsUp, { size: 18 }),
              " Keep on List"
            ]
          }
        ),
        /* @__PURE__ */ u4(
          "button",
          {
            class: "amnesty-btn amnesty-btn-remove",
            onClick: () => {
              onDecision("removed").catch((err) => {
                console.error("[ListAuditCard] Decision error:", err);
              });
            },
            disabled: processing,
            children: [
              /* @__PURE__ */ u4(UserMinus, { size: 18 }),
              " Remove from List"
            ]
          }
        )
      ] })
    ] })
  ] });
}

// src/components/manager/BlocklistAuditTab.tsx
function BlocklistAuditTab({ onReload }) {
  const [syncing, setSyncing] = d2(false);
  const [copyingListUri, setCopyingListUri] = d2(null);
  const state = blocklistAuditState.value;
  const conflicts = blocklistConflicts.value;
  const lastSyncText = state?.lastSyncAt ? `Last synced: ${formatDate(state.lastSyncAt)}` : "Never synced";
  const activeConflicts = conflicts.filter((g4) => !g4.dismissed);
  const dismissedConflicts = conflicts.filter((g4) => g4.dismissed);
  const totalActiveConflicts = activeConflicts.reduce((sum, g4) => sum + g4.conflicts.length, 0);
  const handleSync = async () => {
    setSyncing(true);
    try {
      const result = await browser_default.runtime.sendMessage({ type: "BLOCKLIST_AUDIT_SYNC" });
      if (result.success) {
        await onReload();
      } else {
        alert(`Audit failed: ${result.error || "Unknown error"}`);
      }
    } catch (error) {
      console.error("[BlocklistAuditTab] Sync failed:", error);
      alert("Failed to run blocklist audit");
    } finally {
      setSyncing(false);
    }
  };
  const handleDismiss = async (listUri) => {
    await dismissBlocklistConflicts(listUri);
    await onReload();
  };
  const handleUndismiss = async (listUri) => {
    await undismissBlocklistConflicts(listUri);
    await onReload();
  };
  const handleUnsubscribe = async (listUri) => {
    const group = conflicts.find((g4) => g4.list.uri === listUri);
    if (!group) return;
    const confirmed = confirm(
      `Are you sure you want to unsubscribe from "${group.list.name}"?

This will remove all blocks/mutes from this list.`
    );
    if (!confirmed) return;
    try {
      const result = await browser_default.runtime.sendMessage({
        type: "UNSUBSCRIBE_BLOCKLIST",
        listUri
      });
      if (result.success) {
        await browser_default.runtime.sendMessage({ type: "BLOCKLIST_AUDIT_SYNC" });
        await onReload();
      } else {
        alert(`Failed to unsubscribe: ${result.error || "Unknown error"}`);
      }
    } catch (error) {
      console.error("[BlocklistAuditTab] Unsubscribe failed:", error);
      alert("Failed to unsubscribe from blocklist");
    }
  };
  const handleCopyAsBlocks = async (listUri) => {
    const group = conflicts.find((g4) => g4.list.uri === listUri);
    if (!group) return;
    const confirmed = confirm(
      `Copy "${group.list.name}" as individual blocks?

This will block all members of this list as permanent individual blocks, EXCLUDING anyone you follow.

This is reversible via Mass Ops (all blocks will appear as a cluster since they happen rapidly).`
    );
    if (!confirmed) return;
    setCopyingListUri(listUri);
    try {
      const result = await browser_default.runtime.sendMessage({
        type: "COPY_BLOCKLIST_AS_INDIVIDUAL_BLOCKS",
        listUri
      });
      if (result.success) {
        alert(
          `Successfully blocked ${result.blocked} users.
Skipped ${result.skipped} (already blocked or you follow them).`
        );
        await onReload();
      } else {
        alert(`Failed to copy blocklist: ${result.error || "Unknown error"}`);
      }
    } catch (error) {
      console.error("[BlocklistAuditTab] Copy as blocks failed:", error);
      alert("Failed to copy blocklist as individual blocks");
    } finally {
      setCopyingListUri(null);
    }
  };
  if (conflicts.length === 0) {
    return /* @__PURE__ */ u4("div", { class: "blocklist-audit-container", children: /* @__PURE__ */ u4("div", { class: "blocklist-audit-empty", children: [
      /* @__PURE__ */ u4("h3", { children: state?.lastSyncAt ? "No Conflicts Found" : "Blocklist Audit" }),
      /* @__PURE__ */ u4("p", { children: state?.lastSyncAt ? "None of your follows or followers are on any of your subscribed blocklists." : "Check if any of your follows or followers are on blocklists you subscribe to." }),
      /* @__PURE__ */ u4("button", { class: "audit-sync-btn", onClick: handleSync, disabled: syncing, children: [
        /* @__PURE__ */ u4(RefreshCw, { size: 16, class: syncing ? "spinner" : "" }),
        " ",
        syncing ? "Syncing..." : "Run Audit"
      ] }),
      /* @__PURE__ */ u4("div", { class: "audit-last-sync", children: lastSyncText })
    ] }) });
  }
  return /* @__PURE__ */ u4("div", { class: "blocklist-audit-container", children: [
    /* @__PURE__ */ u4("div", { class: "blocklist-audit-header", children: [
      /* @__PURE__ */ u4("div", { class: "blocklist-audit-stats", children: [
        /* @__PURE__ */ u4("div", { class: "audit-stat", children: [
          /* @__PURE__ */ u4("div", { class: "audit-stat-value", children: state?.followCount || 0 }),
          /* @__PURE__ */ u4("div", { class: "audit-stat-label", children: "Following" })
        ] }),
        /* @__PURE__ */ u4("div", { class: "audit-stat", children: [
          /* @__PURE__ */ u4("div", { class: "audit-stat-value", children: state?.followerCount || 0 }),
          /* @__PURE__ */ u4("div", { class: "audit-stat-label", children: "Followers" })
        ] }),
        /* @__PURE__ */ u4("div", { class: "audit-stat", children: [
          /* @__PURE__ */ u4("div", { class: "audit-stat-value", children: state?.blocklistCount || 0 }),
          /* @__PURE__ */ u4("div", { class: "audit-stat-label", children: "Blocklists" })
        ] }),
        /* @__PURE__ */ u4("div", { class: "audit-stat", children: [
          /* @__PURE__ */ u4(
            "div",
            {
              class: "audit-stat-value",
              style: { color: totalActiveConflicts > 0 ? "#dc2626" : "#16a34a" },
              children: totalActiveConflicts
            }
          ),
          /* @__PURE__ */ u4("div", { class: "audit-stat-label", children: "Conflicts" })
        ] })
      ] }),
      /* @__PURE__ */ u4("div", { class: "blocklist-audit-actions", children: /* @__PURE__ */ u4("button", { class: "audit-sync-btn", onClick: handleSync, disabled: syncing, children: [
        /* @__PURE__ */ u4(RefreshCw, { size: 16, class: syncing ? "spinner" : "" }),
        " ",
        syncing ? "Syncing..." : "Re-run Audit"
      ] }) })
    ] }),
    /* @__PURE__ */ u4("div", { class: "audit-last-sync", children: lastSyncText }),
    activeConflicts.map((group) => /* @__PURE__ */ u4(
      BlocklistGroup,
      {
        group,
        onDismiss: handleDismiss,
        onUndismiss: handleUndismiss,
        onUnsubscribe: handleUnsubscribe,
        onCopyAsBlocks: handleCopyAsBlocks,
        copyingListUri
      },
      group.list.uri
    )),
    dismissedConflicts.length > 0 && /* @__PURE__ */ u4(k, { children: [
      /* @__PURE__ */ u4("h4", { style: { margin: "20px 0 10px", color: "#888" }, children: [
        "Dismissed (",
        dismissedConflicts.length,
        ")"
      ] }),
      dismissedConflicts.map((group) => /* @__PURE__ */ u4(
        BlocklistGroup,
        {
          group,
          onDismiss: handleDismiss,
          onUndismiss: handleUndismiss,
          onUnsubscribe: handleUnsubscribe,
          onCopyAsBlocks: handleCopyAsBlocks,
          copyingListUri
        },
        group.list.uri
      ))
    ] })
  ] });
}
function BlocklistGroup({
  group,
  onDismiss,
  onUndismiss,
  onUnsubscribe,
  onCopyAsBlocks,
  copyingListUri
}) {
  const isCopying = copyingListUri === group.list.uri;
  const list = group.list;
  const defaultAvatar = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%23666"><path d="M3 4h18v16H3V4zm2 2v12h14V6H5z"/></svg>';
  const avatarUrl = list.avatar || defaultAvatar;
  return /* @__PURE__ */ u4("div", { class: `blocklist-group ${group.dismissed ? "dismissed" : ""}`, children: [
    /* @__PURE__ */ u4("div", { class: "blocklist-group-header", children: [
      /* @__PURE__ */ u4("div", { class: "blocklist-info", children: [
        /* @__PURE__ */ u4("img", { class: "blocklist-avatar", src: avatarUrl, alt: "", loading: "lazy" }),
        /* @__PURE__ */ u4("div", { class: "blocklist-details", children: [
          /* @__PURE__ */ u4("span", { class: "blocklist-name", children: list.name }),
          /* @__PURE__ */ u4("span", { class: "blocklist-creator", children: [
            "by @",
            list.creator.handle
          ] })
        ] }),
        /* @__PURE__ */ u4("span", { class: "blocklist-conflict-count", children: [
          group.conflicts.length,
          " conflict",
          group.conflicts.length === 1 ? "" : "s"
        ] })
      ] }),
      /* @__PURE__ */ u4("div", { class: "blocklist-actions", children: [
        group.dismissed ? /* @__PURE__ */ u4(
          "button",
          {
            class: "blocklist-action-btn blocklist-undismiss",
            onClick: () => onUndismiss(list.uri),
            children: [
              /* @__PURE__ */ u4(Eye, { size: 14 }),
              " Show Again"
            ]
          }
        ) : /* @__PURE__ */ u4(
          "button",
          {
            class: "blocklist-action-btn blocklist-dismiss",
            onClick: () => onDismiss(list.uri),
            children: [
              /* @__PURE__ */ u4(EyeOff, { size: 14 }),
              " Dismiss"
            ]
          }
        ),
        /* @__PURE__ */ u4(
          "button",
          {
            class: "blocklist-action-btn blocklist-unsubscribe",
            onClick: () => onUnsubscribe(list.uri),
            children: [
              /* @__PURE__ */ u4(UserX, { size: 14 }),
              " Unsubscribe"
            ]
          }
        ),
        /* @__PURE__ */ u4(
          "button",
          {
            class: "blocklist-action-btn blocklist-copy-blocks",
            onClick: () => onCopyAsBlocks(list.uri),
            disabled: isCopying,
            children: [
              /* @__PURE__ */ u4(Copy, { size: 14 }),
              " ",
              isCopying ? "Copying..." : "Copy as Blocks"
            ]
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ u4("div", { class: "blocklist-conflicts", children: group.conflicts.map((conflict) => {
      const user = conflict.user;
      const defaultUserAvatar = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%23666"><circle cx="12" cy="8" r="4"/><path d="M12 14c-4 0-8 2-8 4v2h16v-2c0-2-4-4-8-4z"/></svg>';
      const userAvatar = user.avatar || defaultUserAvatar;
      const relationshipText = user.relationship === "mutual" ? "Mutual" : user.relationship === "following" ? "You follow" : "Follows you";
      return /* @__PURE__ */ u4("div", { class: "blocklist-conflict-row", children: [
        /* @__PURE__ */ u4("img", { class: "conflict-user-avatar", src: userAvatar, alt: "", loading: "lazy" }),
        /* @__PURE__ */ u4("div", { class: "conflict-user-info", children: [
          /* @__PURE__ */ u4("span", { class: "conflict-user-handle", children: [
            "@",
            user.handle
          ] }),
          user.displayName && /* @__PURE__ */ u4("span", { class: "conflict-user-name", children: user.displayName })
        ] }),
        /* @__PURE__ */ u4("span", { class: `conflict-relationship ${user.relationship}`, children: relationshipText }),
        /* @__PURE__ */ u4(
          "a",
          {
            class: "conflict-view-profile",
            href: `https://bsky.app/profile/${user.handle}`,
            target: "_blank",
            rel: "noopener",
            children: [
              /* @__PURE__ */ u4(ExternalLink, { size: 12 }),
              " View Profile"
            ]
          }
        )
      ] }, user.did);
    }) })
  ] });
}

// src/components/manager/RepostFiltersTab.tsx
function RepostFiltersTab({ onReload }) {
  const [users, setUsers] = d2([]);
  const [loading2, setLoading] = d2(true);
  const [searchQuery2, setSearchQuery] = d2("");
  const [removing, setRemoving] = d2(null);
  const [addHandle, setAddHandle] = d2("");
  const [adding, setAdding] = d2(false);
  const [addError, setAddError] = d2(null);
  const loadUsers = async () => {
    setLoading(true);
    try {
      const filteredUsers2 = await getRepostFilteredUsersArray();
      setUsers(filteredUsers2);
    } catch (error) {
      console.error("[RepostFiltersTab] Failed to load users:", error);
    } finally {
      setLoading(false);
    }
  };
  y2(() => {
    loadUsers();
  }, []);
  const handleRemove = async (did) => {
    setRemoving(did);
    try {
      await removeRepostFilteredUser(did);
      await loadUsers();
      await onReload();
    } catch (error) {
      console.error("[RepostFiltersTab] Failed to remove user:", error);
      alert("Failed to remove user from filter list");
    } finally {
      setRemoving(null);
    }
  };
  const handleAddUser = async () => {
    if (!addHandle.trim()) {
      setAddError("Please enter a handle");
      return;
    }
    setAdding(true);
    setAddError(null);
    try {
      const normalizedHandle = addHandle.trim().startsWith("@") ? addHandle.trim().slice(1) : addHandle.trim();
      const existingUser = users.find(
        (u5) => u5.handle.toLowerCase() === normalizedHandle.toLowerCase()
      );
      if (existingUser) {
        setAddError("User is already in your filter list");
        return;
      }
      const response = await browser_default.runtime.sendMessage({
        type: "RESOLVE_HANDLE",
        handle: normalizedHandle
      });
      if (!response.success || !response.profile) {
        setAddError(response.error || "User not found");
        return;
      }
      const existingByDid = users.find((u5) => u5.did === response.profile.did);
      if (existingByDid) {
        setAddError("User is already in your filter list");
        return;
      }
      const newUser = {
        did: response.profile.did,
        handle: response.profile.handle,
        displayName: response.profile.displayName,
        avatar: response.profile.avatar,
        addedAt: Date.now()
      };
      await addRepostFilteredUser(newUser);
      await loadUsers();
      await onReload();
      setAddHandle("");
      setAddError(null);
    } catch (error) {
      console.error("[RepostFiltersTab] Failed to add user:", error);
      setAddError("Failed to add user");
    } finally {
      setAdding(false);
    }
  };
  const filteredUsers = searchQuery2 ? users.filter(
    (user) => user.handle.toLowerCase().includes(searchQuery2.toLowerCase()) || user.displayName?.toLowerCase().includes(searchQuery2.toLowerCase())
  ) : users;
  const defaultAvatar = 'data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="%23666"><circle cx="12" cy="8" r="4"/><path d="M12 14c-4 0-8 2-8 4v2h16v-2c0-2-4-4-8-4z"/></svg>';
  if (loading2) {
    return /* @__PURE__ */ u4("div", { class: "blocklist-audit-container", children: /* @__PURE__ */ u4("div", { class: "blocklist-audit-empty", children: [
      /* @__PURE__ */ u4(RefreshCw, { size: 24, class: "spinner" }),
      /* @__PURE__ */ u4("p", { children: "Loading repost filters..." })
    ] }) });
  }
  if (users.length === 0) {
    return /* @__PURE__ */ u4("div", { class: "blocklist-audit-container", children: [
      /* @__PURE__ */ u4("div", { class: "blocklist-audit-empty", children: [
        /* @__PURE__ */ u4(Funnel, { size: 32, style: { marginBottom: "12px", color: "#666" } }),
        /* @__PURE__ */ u4("h3", { children: "Repost Filters" }),
        /* @__PURE__ */ u4("p", { children: [
          "No repost filters configured yet.",
          /* @__PURE__ */ u4("br", {}),
          /* @__PURE__ */ u4("br", {}),
          'To hide reposts from specific users while still seeing their original posts, click the three-dot menu on their profile and select "Disable Reposts", or add a user by handle below.'
        ] })
      ] }),
      /* @__PURE__ */ u4("div", { class: "block-rel-search-section", style: { marginTop: "16px" }, children: /* @__PURE__ */ u4("div", { style: { display: "flex", gap: "8px", alignItems: "flex-start" }, children: [
        /* @__PURE__ */ u4("div", { style: { flex: 1 }, children: [
          /* @__PURE__ */ u4(
            "input",
            {
              type: "text",
              class: "block-rel-search-input",
              placeholder: "Enter handle, e.g. user.bsky.social",
              value: addHandle,
              onInput: (e4) => {
                setAddHandle(e4.target.value);
                setAddError(null);
              },
              onKeyDown: (e4) => {
                if (e4.key === "Enter" && !adding) {
                  handleAddUser();
                }
              },
              disabled: adding,
              style: { width: "100%" }
            }
          ),
          addError && /* @__PURE__ */ u4("div", { style: { color: "var(--error)", fontSize: "12px", marginTop: "4px" }, children: addError })
        ] }),
        /* @__PURE__ */ u4(
          "button",
          {
            class: "blocklist-action-btn",
            onClick: handleAddUser,
            disabled: adding || !addHandle.trim(),
            title: "Add user to filter list",
            children: [
              adding ? /* @__PURE__ */ u4(RefreshCw, { size: 14, class: "spinner" }) : /* @__PURE__ */ u4(Plus, { size: 14 }),
              "Add"
            ]
          }
        )
      ] }) })
    ] });
  }
  return /* @__PURE__ */ u4("div", { class: "blocklist-audit-container", children: [
    /* @__PURE__ */ u4("div", { class: "blocklist-audit-header", children: [
      /* @__PURE__ */ u4("div", { class: "blocklist-audit-stats", children: /* @__PURE__ */ u4("div", { class: "audit-stat", children: [
        /* @__PURE__ */ u4("div", { class: "audit-stat-value", children: users.length }),
        /* @__PURE__ */ u4("div", { class: "audit-stat-label", children: "Filtered Users" })
      ] }) }),
      /* @__PURE__ */ u4("div", { class: "blocklist-audit-actions", children: /* @__PURE__ */ u4(
        "input",
        {
          type: "text",
          class: "block-rel-search-input",
          placeholder: "Search users...",
          value: searchQuery2,
          onInput: (e4) => setSearchQuery(e4.target.value),
          style: { width: "200px", marginRight: "8px" }
        }
      ) })
    ] }),
    /* @__PURE__ */ u4("div", { class: "block-rel-search-section", style: { marginBottom: "16px" }, children: /* @__PURE__ */ u4("p", { class: "block-rel-search-desc", children: "Reposts from these users are hidden from your feed. Their original posts will still appear." }) }),
    /* @__PURE__ */ u4("div", { class: "block-rel-search-section", style: { marginBottom: "16px" }, children: /* @__PURE__ */ u4("div", { style: { display: "flex", gap: "8px", alignItems: "flex-start" }, children: [
      /* @__PURE__ */ u4("div", { style: { flex: 1 }, children: [
        /* @__PURE__ */ u4(
          "input",
          {
            type: "text",
            class: "block-rel-search-input",
            placeholder: "Enter handle, e.g. user.bsky.social",
            value: addHandle,
            onInput: (e4) => {
              setAddHandle(e4.target.value);
              setAddError(null);
            },
            onKeyDown: (e4) => {
              if (e4.key === "Enter" && !adding) {
                handleAddUser();
              }
            },
            disabled: adding,
            style: { width: "100%" }
          }
        ),
        addError && /* @__PURE__ */ u4("div", { style: { color: "var(--error)", fontSize: "12px", marginTop: "4px" }, children: addError })
      ] }),
      /* @__PURE__ */ u4(
        "button",
        {
          class: "blocklist-action-btn",
          onClick: handleAddUser,
          disabled: adding || !addHandle.trim(),
          title: "Add user to filter list",
          children: [
            adding ? /* @__PURE__ */ u4(RefreshCw, { size: 14, class: "spinner" }) : /* @__PURE__ */ u4(Plus, { size: 14 }),
            "Add"
          ]
        }
      )
    ] }) }),
    /* @__PURE__ */ u4("div", { class: "block-rel-results", children: filteredUsers.length === 0 ? /* @__PURE__ */ u4("div", { class: "block-rel-no-results", children: /* @__PURE__ */ u4("p", { children: "No users match your search." }) }) : /* @__PURE__ */ u4("div", { class: "block-rel-user-list", children: filteredUsers.map((user) => /* @__PURE__ */ u4("div", { class: "block-rel-user-row", children: [
      /* @__PURE__ */ u4(
        "img",
        {
          class: "block-rel-user-avatar",
          src: user.avatar || defaultAvatar,
          alt: "",
          loading: "lazy"
        }
      ),
      /* @__PURE__ */ u4("div", { class: "block-rel-user-info", children: [
        /* @__PURE__ */ u4("span", { class: "block-rel-user-handle", children: [
          "@",
          user.handle
        ] }),
        user.displayName && /* @__PURE__ */ u4("span", { class: "block-rel-user-name", children: user.displayName }),
        /* @__PURE__ */ u4("span", { class: "block-rel-user-date", children: [
          "Added ",
          formatDate(user.addedAt)
        ] })
      ] }),
      /* @__PURE__ */ u4("div", { style: { display: "flex", gap: "8px", alignItems: "center" }, children: [
        /* @__PURE__ */ u4(
          "a",
          {
            class: "conflict-view-profile",
            href: `https://bsky.app/profile/${user.handle}`,
            target: "_blank",
            rel: "noopener",
            children: [
              /* @__PURE__ */ u4(ExternalLink, { size: 12 }),
              " View"
            ]
          }
        ),
        /* @__PURE__ */ u4(
          "button",
          {
            class: "blocklist-action-btn danger",
            onClick: () => handleRemove(user.did),
            disabled: removing === user.did,
            title: "Remove from filter list",
            children: [
              removing === user.did ? /* @__PURE__ */ u4(RefreshCw, { size: 14, class: "spinner" }) : /* @__PURE__ */ u4(Trash2, { size: 14 }),
              "Remove"
            ]
          }
        )
      ] })
    ] }, user.did)) }) })
  ] });
}

// src/components/manager/MassOpsTab.tsx
async function fetchProfilesViaBackground(dids) {
  const response = await browser_default.runtime.sendMessage({
    type: "GET_PROFILES_BATCHED",
    dids
  });
  if (!response.success) {
    throw new Error(response.error || "Failed to fetch profiles");
  }
  const map = /* @__PURE__ */ new Map();
  if (response.profiles) {
    for (const [did, profile] of Object.entries(response.profiles)) {
      map.set(did, profile);
    }
  }
  return map;
}
function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
function formatRelativeTime(timestamp) {
  const now = Date.now();
  const diff = now - timestamp;
  const minutes = Math.floor(diff / 6e4);
  const hours = Math.floor(minutes / 60);
  const days = Math.floor(hours / 24);
  if (days > 0) return `${days} day${days === 1 ? "" : "s"} ago`;
  if (hours > 0) return `${hours} hour${hours === 1 ? "" : "s"} ago`;
  if (minutes > 0) return `${minutes} minute${minutes === 1 ? "" : "s"} ago`;
  return "just now";
}
function MassOpsTab({ onReload: _onReload }) {
  const [undoing, setUndoing] = d2(null);
  const [showConfirm, setShowConfirm] = d2(null);
  const [checkingCache, setCheckingCache] = d2(false);
  const [dismissing, setDismissing] = d2(null);
  const [showDismissed, setShowDismissed] = d2(false);
  const [dismissedClusters, setDismissedClusters] = d2([]);
  const loading2 = massOpsLoading.value;
  const progress = massOpsProgress.value;
  const scanResult = massOpsScanResult.value;
  const settings = massOpsSettings.value;
  const cacheStatus = carCacheStatus.value;
  const downloadProgress = carDownloadProgress.value;
  const estimatedSize = carEstimatedSize.value;
  y2(() => {
    const handleStorageChange = (changes, areaName) => {
      if (areaName === "local" && changes[STORAGE_KEYS.CAR_DOWNLOAD_PROGRESS]) {
        const newProgress = changes[STORAGE_KEYS.CAR_DOWNLOAD_PROGRESS].newValue;
        carDownloadProgress.value = newProgress || null;
        if (newProgress) {
          massOpsProgress.value = newProgress.message;
        }
      }
    };
    browser_default.storage.onChanged.addListener(handleStorageChange);
    return () => browser_default.storage.onChanged.removeListener(handleStorageChange);
  }, []);
  y2(() => {
    checkCacheStatus();
  }, []);
  const checkCacheStatus = async () => {
    setCheckingCache(true);
    try {
      const result = await browser_default.runtime.sendMessage({
        type: "CHECK_CAR_CACHE_STATUS"
      });
      if (result.success && result.status) {
        carCacheStatus.value = result.status;
      }
      if (!result.status?.hasCached || result.status?.isStale) {
        const sizeResult = await browser_default.runtime.sendMessage({
          type: "ESTIMATE_CAR_SIZE"
        });
        if (sizeResult.success && sizeResult.sizeBytes) {
          carEstimatedSize.value = sizeResult.sizeBytes;
        }
      }
    } catch (error) {
      console.error("[MassOpsTab] Failed to check cache status:", error);
    } finally {
      setCheckingCache(false);
    }
  };
  const handleSettingsChange = async (field, value) => {
    const newSettings = { ...settings, [field]: value };
    massOpsSettings.value = newSettings;
    await setMassOpsSettings(newSettings);
  };
  const handleScan = async (forceRefresh = false) => {
    massOpsLoading.value = true;
    massOpsProgress.value = "Starting scan...";
    try {
      const result = await browser_default.runtime.sendMessage({
        type: "SCAN_MASS_OPS",
        settings,
        forceRefresh
      });
      if (result.success) {
        const storedResult = await getMassOpsScanResult();
        massOpsScanResult.value = storedResult;
        if (storedResult) {
          for (const cluster of storedResult.clusters) {
            initMassOpsClusterSelection(
              cluster.id,
              cluster.operations.map((op) => op.rkey)
            );
          }
        }
        massOpsProgress.value = "";
        await checkCacheStatus();
      } else {
        massOpsProgress.value = `Error: ${result.error || "Unknown error"}`;
      }
    } catch (error) {
      console.error("[MassOpsTab] Scan failed:", error);
      massOpsProgress.value = `Error: ${error instanceof Error ? error.message : "Unknown error"}`;
    } finally {
      massOpsLoading.value = false;
      carDownloadProgress.value = null;
    }
  };
  const handleUndoCluster = async (cluster) => {
    const selectedRkeys = getMassOpsSelectedItems(cluster.id);
    if (selectedRkeys.size === 0) {
      alert("No operations selected to undo");
      return;
    }
    setShowConfirm(cluster.id);
  };
  const confirmUndo = async (cluster) => {
    setShowConfirm(null);
    setUndoing(cluster.id);
    const selectedRkeys = getMassOpsSelectedItems(cluster.id);
    const selectedOps = cluster.operations.filter((op) => selectedRkeys.has(op.rkey));
    try {
      const result = await browser_default.runtime.sendMessage({
        type: "UNDO_MASS_OPERATIONS",
        operations: selectedOps
      });
      if (result.undone > 0) {
        alert(
          `Successfully undid ${result.undone} operations.` + (result.failed > 0 ? ` ${result.failed} failed.` : "")
        );
        await handleScan();
      } else {
        alert(`Failed to undo operations: ${result.errors.join(", ")}`);
      }
    } catch (error) {
      console.error("[MassOpsTab] Undo failed:", error);
      alert(`Failed to undo: ${error instanceof Error ? error.message : "Unknown error"}`);
    } finally {
      setUndoing(null);
    }
  };
  const handleDismissCluster = async (cluster) => {
    setDismissing(cluster.id);
    try {
      const result = await browser_default.runtime.sendMessage({
        type: "DISMISS_MASS_OPS_CLUSTER",
        cluster: {
          type: cluster.type,
          startTime: cluster.startTime,
          endTime: cluster.endTime,
          count: cluster.count
        }
      });
      if (result.success) {
        if (scanResult) {
          massOpsScanResult.value = {
            ...scanResult,
            clusters: scanResult.clusters.filter((c4) => c4.id !== cluster.id)
          };
        }
        if (showDismissed) {
          await loadDismissedClusters();
        }
      } else {
        alert(`Failed to dismiss: ${result.error || "Unknown error"}`);
      }
    } catch (error) {
      console.error("[MassOpsTab] Dismiss failed:", error);
      alert(`Failed to dismiss: ${error instanceof Error ? error.message : "Unknown error"}`);
    } finally {
      setDismissing(null);
    }
  };
  const loadDismissedClusters = async () => {
    try {
      const result = await browser_default.runtime.sendMessage({
        type: "GET_DISMISSED_MASS_OPS_CLUSTERS"
      });
      if (result.success && result.dismissed) {
        setDismissedClusters(result.dismissed);
      }
    } catch (error) {
      console.error("[MassOpsTab] Failed to load dismissed clusters:", error);
    }
  };
  const handleRestoreCluster = async (cluster) => {
    try {
      const result = await browser_default.runtime.sendMessage({
        type: "RESTORE_MASS_OPS_CLUSTER",
        cluster: {
          type: cluster.type,
          startTime: cluster.startTime,
          endTime: cluster.endTime,
          count: cluster.count
        }
      });
      if (result.success) {
        setDismissedClusters(
          (prev) => prev.filter(
            (c4) => !(c4.type === cluster.type && c4.startTime === cluster.startTime && c4.endTime === cluster.endTime && c4.count === cluster.count)
          )
        );
      } else {
        alert(`Failed to restore: ${result.error || "Unknown error"}`);
      }
    } catch (error) {
      console.error("[MassOpsTab] Restore failed:", error);
    }
  };
  const handleToggleShowDismissed = async () => {
    if (!showDismissed) {
      await loadDismissedClusters();
    }
    setShowDismissed(!showDismissed);
  };
  const renderCacheStatus = () => {
    if (checkingCache) {
      return /* @__PURE__ */ u4("div", { class: "mass-ops-cache-status checking", children: "Checking cache status..." });
    }
    if (!cacheStatus) {
      return null;
    }
    if (cacheStatus.hasCached && !cacheStatus.isStale) {
      return /* @__PURE__ */ u4("div", { class: "mass-ops-cache-status cached", children: [
        /* @__PURE__ */ u4(Database, { size: 14 }),
        /* @__PURE__ */ u4("span", { children: [
          "Using cached data from ",
          formatRelativeTime(cacheStatus.cachedAt || 0),
          cacheStatus.cachedSize && ` (${formatBytes(cacheStatus.cachedSize)})`
        ] }),
        /* @__PURE__ */ u4(
          "button",
          {
            class: "mass-ops-refresh-btn",
            onClick: () => handleScan(true),
            disabled: loading2,
            title: "Force refresh from server",
            children: /* @__PURE__ */ u4(RefreshCw, { size: 14 })
          }
        )
      ] });
    }
    if (cacheStatus.hasCached && cacheStatus.isStale) {
      return /* @__PURE__ */ u4("div", { class: "mass-ops-cache-status stale", children: [
        /* @__PURE__ */ u4(Database, { size: 14 }),
        /* @__PURE__ */ u4("span", { children: [
          "Cached data from ",
          formatRelativeTime(cacheStatus.cachedAt || 0),
          cacheStatus.cachedSize && ` (${formatBytes(cacheStatus.cachedSize)})`
        ] }),
        /* @__PURE__ */ u4(
          "button",
          {
            class: "mass-ops-refresh-btn",
            onClick: () => handleScan(true),
            disabled: loading2,
            title: "Download fresh data from server",
            children: /* @__PURE__ */ u4(RefreshCw, { size: 14 })
          }
        )
      ] });
    }
    return /* @__PURE__ */ u4("div", { class: "mass-ops-cache-status no-cache", children: /* @__PURE__ */ u4("span", { children: [
      "No cached data",
      estimatedSize && ` - Download: ~${formatBytes(estimatedSize)}`
    ] }) });
  };
  const renderProgressBar = () => {
    if (!downloadProgress || downloadProgress.stage === "complete") {
      return null;
    }
    const percent = downloadProgress.percentComplete ?? 0;
    return /* @__PURE__ */ u4("div", { class: "mass-ops-progress-container", children: [
      /* @__PURE__ */ u4("div", { class: "mass-ops-progress-bar", children: /* @__PURE__ */ u4("div", { class: "mass-ops-progress-fill", style: { width: `${percent}%` } }) }),
      /* @__PURE__ */ u4("div", { class: "mass-ops-progress-text", children: [
        downloadProgress.message,
        downloadProgress.isIncremental && " (incremental)"
      ] })
    ] });
  };
  if (!scanResult) {
    return /* @__PURE__ */ u4("div", { class: "mass-ops-container", children: /* @__PURE__ */ u4("div", { class: "mass-ops-intro", children: [
      /* @__PURE__ */ u4("h3", { children: "Mass Operations Detection" }),
      /* @__PURE__ */ u4("p", { children: "Scan your account for clusters of rapid blocks, follows, or list additions. This can help identify and undo actions taken by automation tools, starter packs, or during moments of frustration." }),
      /* @__PURE__ */ u4("p", { class: "mass-ops-note", children: "Note: Mutes cannot be detected as they are not stored in your repository." }),
      renderCacheStatus(),
      /* @__PURE__ */ u4("div", { class: "mass-ops-settings", children: [
        /* @__PURE__ */ u4("label", { children: [
          "Time window (minutes):",
          /* @__PURE__ */ u4(
            "input",
            {
              type: "number",
              min: "1",
              max: "60",
              value: settings.timeWindowMinutes,
              onChange: (e4) => handleSettingsChange(
                "timeWindowMinutes",
                parseInt(e4.target.value) || 5
              )
            }
          )
        ] }),
        /* @__PURE__ */ u4("label", { children: [
          "Minimum operations:",
          /* @__PURE__ */ u4(
            "input",
            {
              type: "number",
              min: "2",
              max: "100",
              value: settings.minOperationCount,
              onChange: (e4) => handleSettingsChange(
                "minOperationCount",
                parseInt(e4.target.value) || 10
              )
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ u4("button", { class: "mass-ops-scan-btn", onClick: () => handleScan(false), disabled: loading2, children: [
        /* @__PURE__ */ u4(Search, { size: 16, class: loading2 ? "spinner" : "" }),
        loading2 ? "Scanning..." : cacheStatus?.hasCached ? "Scan Cached Data" : "Download & Scan"
      ] }),
      loading2 && renderProgressBar(),
      progress && !downloadProgress && /* @__PURE__ */ u4("div", { class: "mass-ops-progress", children: progress })
    ] }) });
  }
  const { clusters, scannedAt, operationCounts } = scanResult;
  return /* @__PURE__ */ u4("div", { class: "mass-ops-container", children: [
    /* @__PURE__ */ u4("div", { class: "mass-ops-header", children: [
      /* @__PURE__ */ u4("div", { class: "mass-ops-stats", children: [
        /* @__PURE__ */ u4("div", { class: "mass-ops-stat", title: "Records in your repo (may include deleted/suspended accounts)", children: [
          /* @__PURE__ */ u4("div", { class: "stat-value", children: operationCounts.blocks }),
          /* @__PURE__ */ u4("div", { class: "stat-label", children: "Blocks*" })
        ] }),
        /* @__PURE__ */ u4("div", { class: "mass-ops-stat", title: "Records in your repo (may include deleted/suspended accounts)", children: [
          /* @__PURE__ */ u4("div", { class: "stat-value", children: operationCounts.follows }),
          /* @__PURE__ */ u4("div", { class: "stat-label", children: "Follows*" })
        ] }),
        /* @__PURE__ */ u4("div", { class: "mass-ops-stat", children: [
          /* @__PURE__ */ u4("div", { class: "stat-value", children: operationCounts.listitems }),
          /* @__PURE__ */ u4("div", { class: "stat-label", children: "List Items" })
        ] }),
        /* @__PURE__ */ u4("div", { class: "mass-ops-stat", children: [
          /* @__PURE__ */ u4("div", { class: "stat-value", style: { color: clusters.length > 0 ? "#dc2626" : "#16a34a" }, children: clusters.length }),
          /* @__PURE__ */ u4("div", { class: "stat-label", children: "Clusters" })
        ] })
      ] }),
      /* @__PURE__ */ u4("div", { class: "mass-ops-repo-note", children: "*Counts from your repository data. May be higher than active counts if you've blocked/followed accounts that were later deleted or suspended." }),
      /* @__PURE__ */ u4("div", { class: "mass-ops-actions", children: [
        /* @__PURE__ */ u4("button", { class: "mass-ops-scan-btn", onClick: () => handleScan(false), disabled: loading2, children: [
          /* @__PURE__ */ u4(Search, { size: 16, class: loading2 ? "spinner" : "" }),
          loading2 ? "Scanning..." : "Rescan"
        ] }),
        /* @__PURE__ */ u4(
          "button",
          {
            class: "mass-ops-refresh-btn",
            onClick: () => handleScan(true),
            disabled: loading2,
            title: "Download fresh data from server",
            children: /* @__PURE__ */ u4(RefreshCw, { size: 16 })
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ u4("div", { class: "mass-ops-last-scan", children: [
      "Last scanned: ",
      formatDate(scannedAt),
      cacheStatus?.hasCached && /* @__PURE__ */ u4("span", { class: "mass-ops-cache-indicator", children: [
        " ",
        "(data from ",
        formatRelativeTime(cacheStatus.cachedAt || 0),
        ")"
      ] })
    ] }),
    loading2 && renderProgressBar(),
    progress && !downloadProgress && /* @__PURE__ */ u4("div", { class: "mass-ops-progress", children: progress }),
    clusters.length === 0 ? /* @__PURE__ */ u4("div", { class: "mass-ops-empty", children: [
      /* @__PURE__ */ u4("p", { children: "No mass operations detected with current settings." }),
      /* @__PURE__ */ u4("p", { children: "Try adjusting the time window or minimum count if you believe there should be results." })
    ] }) : /* @__PURE__ */ u4("div", { class: "mass-ops-clusters", children: clusters.map((cluster) => /* @__PURE__ */ u4(
      ClusterCard,
      {
        cluster,
        onUndo: handleUndoCluster,
        onDismiss: handleDismissCluster,
        undoing: undoing === cluster.id,
        dismissing: dismissing === cluster.id,
        showConfirm: showConfirm === cluster.id,
        onConfirmUndo: confirmUndo,
        onCancelUndo: () => setShowConfirm(null)
      },
      cluster.id
    )) }),
    /* @__PURE__ */ u4("div", { class: "mass-ops-settings-footer", children: [
      /* @__PURE__ */ u4("span", { children: "Detection settings:" }),
      /* @__PURE__ */ u4("label", { children: [
        "Window:",
        /* @__PURE__ */ u4(
          "input",
          {
            type: "number",
            min: "1",
            max: "60",
            value: settings.timeWindowMinutes,
            onChange: (e4) => handleSettingsChange(
              "timeWindowMinutes",
              parseInt(e4.target.value) || 5
            )
          }
        ),
        "min"
      ] }),
      /* @__PURE__ */ u4("label", { children: [
        "Min ops:",
        /* @__PURE__ */ u4(
          "input",
          {
            type: "number",
            min: "2",
            max: "100",
            value: settings.minOperationCount,
            onChange: (e4) => handleSettingsChange(
              "minOperationCount",
              parseInt(e4.target.value) || 10
            )
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ u4("div", { class: "mass-ops-dismissed-section", children: [
      /* @__PURE__ */ u4("button", { class: "mass-ops-show-dismissed-btn", onClick: handleToggleShowDismissed, children: [
        showDismissed ? "Hide" : "Show",
        " Dismissed Clusters",
        dismissedClusters.length > 0 && ` (${dismissedClusters.length})`
      ] }),
      showDismissed && /* @__PURE__ */ u4("div", { class: "mass-ops-dismissed-list", children: dismissedClusters.length === 0 ? /* @__PURE__ */ u4("p", { class: "mass-ops-no-dismissed", children: "No dismissed clusters." }) : dismissedClusters.map((cluster, index) => {
        const typeLabel = cluster.type === "block" ? "Blocks" : cluster.type === "follow" ? "Follows" : "List Adds";
        const timeRange = formatTimeRange(cluster.startTime, cluster.endTime);
        return /* @__PURE__ */ u4("div", { class: "mass-ops-dismissed-item", children: [
          /* @__PURE__ */ u4("span", { class: "dismissed-type", children: typeLabel }),
          /* @__PURE__ */ u4("span", { class: "dismissed-count", children: [
            cluster.count,
            " ops"
          ] }),
          /* @__PURE__ */ u4("span", { class: "dismissed-time", children: timeRange }),
          /* @__PURE__ */ u4(
            "button",
            {
              class: "dismissed-restore-btn",
              onClick: () => handleRestoreCluster(cluster),
              title: "Restore this cluster to show in future scans",
              children: "Restore"
            }
          )
        ] }, index);
      }) })
    ] })
  ] });
}
function ClusterCard({
  cluster,
  onUndo,
  onDismiss,
  undoing,
  dismissing,
  showConfirm,
  onConfirmUndo,
  onCancelUndo
}) {
  const expanded = massOpsExpandedClusters.value.has(cluster.id);
  const selectedRkeys = getMassOpsSelectedItems(cluster.id);
  const allSelected = selectedRkeys.size === cluster.operations.length;
  const noneSelected = selectedRkeys.size === 0;
  const [profiles, setProfiles] = d2(/* @__PURE__ */ new Map());
  const [loadingProfiles, setLoadingProfiles] = d2(false);
  const [profilesLoaded, setProfilesLoaded] = d2(false);
  const typeLabel = cluster.type === "block" ? "Blocks" : cluster.type === "follow" ? "Follows" : "List Adds";
  const typeColor = cluster.type === "block" ? "#dc2626" : cluster.type === "follow" ? "#2563eb" : "#9333ea";
  const timeRange = formatTimeRange(cluster.startTime, cluster.endTime);
  y2(() => {
    if (expanded && !profilesLoaded && !loadingProfiles) {
      const fetchProfiles = async () => {
        try {
          const authResponse = await browser_default.runtime.sendMessage({ type: "GET_AUTH_STATUS" });
          if (!authResponse.success || !authResponse.isAuthenticated) {
            setProfilesLoaded(true);
            return;
          }
        } catch {
          setProfilesLoaded(true);
          return;
        }
        setLoadingProfiles(true);
        try {
          const dids = cluster.operations.map((op) => op.did);
          const profileMap = await fetchProfilesViaBackground(dids);
          setProfiles(profileMap);
          setProfilesLoaded(true);
        } catch (error) {
          console.error("[MassOpsTab] Failed to fetch profiles:", error);
          setProfilesLoaded(true);
        } finally {
          setLoadingProfiles(false);
        }
      };
      fetchProfiles();
    }
  }, [expanded, profilesLoaded, loadingProfiles, cluster.operations]);
  const handleToggleExpand = () => {
    toggleMassOpsClusterExpanded(cluster.id);
    if (!massOpsSelectedItems.value.has(cluster.id)) {
      initMassOpsClusterSelection(
        cluster.id,
        cluster.operations.map((op) => op.rkey)
      );
    }
  };
  const handleSelectAll = () => {
    selectAllMassOpsItems(
      cluster.id,
      cluster.operations.map((op) => op.rkey)
    );
  };
  const handleDeselectAll = () => {
    deselectAllMassOpsItems(cluster.id);
  };
  return /* @__PURE__ */ u4("div", { class: "mass-ops-cluster", children: [
    /* @__PURE__ */ u4("div", { class: "cluster-header", onClick: handleToggleExpand, children: [
      /* @__PURE__ */ u4("span", { class: "cluster-expand-icon", children: expanded ? /* @__PURE__ */ u4(ChevronDown, { size: 16 }) : /* @__PURE__ */ u4(ChevronRight, { size: 16 }) }),
      /* @__PURE__ */ u4("span", { class: "cluster-type", style: { color: typeColor }, children: typeLabel }),
      /* @__PURE__ */ u4("span", { class: "cluster-count", children: [
        cluster.count,
        " operations"
      ] }),
      /* @__PURE__ */ u4("span", { class: "cluster-time", children: timeRange }),
      /* @__PURE__ */ u4(
        "button",
        {
          class: "cluster-undo-btn",
          onClick: (e4) => {
            e4.stopPropagation();
            onUndo(cluster);
          },
          disabled: undoing || noneSelected,
          children: [
            /* @__PURE__ */ u4(Trash2, { size: 14 }),
            undoing ? "Undoing..." : `Undo ${selectedRkeys.size}`
          ]
        }
      ),
      /* @__PURE__ */ u4(
        "button",
        {
          class: "cluster-dismiss-btn",
          onClick: (e4) => {
            e4.stopPropagation();
            onDismiss(cluster);
          },
          disabled: dismissing,
          title: "Hide this cluster from future scans",
          children: dismissing ? "..." : "Dismiss"
        }
      )
    ] }),
    showConfirm && /* @__PURE__ */ u4("div", { class: "cluster-confirm", children: [
      /* @__PURE__ */ u4("span", { children: [
        "Are you sure you want to undo ",
        selectedRkeys.size,
        " ",
        cluster.type,
        selectedRkeys.size === 1 ? "" : "s",
        "?"
      ] }),
      /* @__PURE__ */ u4("button", { class: "confirm-yes", onClick: () => onConfirmUndo(cluster), children: "Yes, Undo" }),
      /* @__PURE__ */ u4("button", { class: "confirm-no", onClick: onCancelUndo, children: "Cancel" })
    ] }),
    expanded && /* @__PURE__ */ u4("div", { class: "cluster-operations", children: [
      /* @__PURE__ */ u4("div", { class: "cluster-select-all", children: [
        /* @__PURE__ */ u4("button", { onClick: allSelected ? handleDeselectAll : handleSelectAll, children: [
          allSelected ? /* @__PURE__ */ u4(SquareCheckBig, { size: 14 }) : /* @__PURE__ */ u4(Square, { size: 14 }),
          allSelected ? "Deselect All" : "Select All"
        ] }),
        /* @__PURE__ */ u4("span", { class: "select-count", children: [
          selectedRkeys.size,
          " of ",
          cluster.operations.length,
          " selected"
        ] }),
        loadingProfiles && /* @__PURE__ */ u4("span", { class: "loading-profiles", children: [
          /* @__PURE__ */ u4(LoaderCircle, { size: 14, class: "spinner" }),
          "Loading profiles..."
        ] })
      ] }),
      /* @__PURE__ */ u4("div", { class: "operations-list", children: cluster.operations.map((op) => /* @__PURE__ */ u4(
        OperationRow,
        {
          operation: op,
          clusterId: cluster.id,
          profile: profiles.get(op.did)
        },
        op.rkey
      )) })
    ] })
  ] });
}
function OperationRow({ operation, clusterId, profile }) {
  const selectedRkeys = getMassOpsSelectedItems(clusterId);
  const isSelected = selectedRkeys.has(operation.rkey);
  const displayName = profile?.displayName || profile?.handle;
  const displayIdentifier = displayName || (operation.did.length > 40 ? `${operation.did.slice(0, 20)}...${operation.did.slice(-15)}` : operation.did);
  return /* @__PURE__ */ u4(
    "div",
    {
      class: `operation-row ${isSelected ? "selected" : ""}`,
      onClick: () => toggleMassOpsItemSelection(clusterId, operation.rkey),
      children: [
        /* @__PURE__ */ u4("span", { class: "operation-checkbox", children: isSelected ? /* @__PURE__ */ u4(SquareCheckBig, { size: 14 }) : /* @__PURE__ */ u4(Square, { size: 14 }) }),
        /* @__PURE__ */ u4(
          "a",
          {
            class: "operation-user",
            href: `https://bsky.app/profile/${operation.did}`,
            target: "_blank",
            rel: "noopener",
            title: operation.did,
            onClick: (e4) => e4.stopPropagation(),
            children: [
              profile?.avatar ? /* @__PURE__ */ u4("img", { src: profile.avatar, alt: "", class: "operation-avatar" }) : /* @__PURE__ */ u4("span", { class: "operation-avatar-placeholder" }),
              /* @__PURE__ */ u4("span", { class: "operation-identity", children: [
                /* @__PURE__ */ u4("span", { class: "operation-display-name", children: displayIdentifier }),
                displayName && profile?.handle && /* @__PURE__ */ u4("span", { class: "operation-handle", children: [
                  "@",
                  profile.handle
                ] })
              ] })
            ]
          }
        ),
        operation.listName && /* @__PURE__ */ u4("span", { class: "operation-list-name", children: operation.listName }),
        /* @__PURE__ */ u4("span", { class: "operation-time", children: formatDate(operation.createdAt) }),
        /* @__PURE__ */ u4(
          "a",
          {
            class: "operation-view",
            href: `https://bsky.app/profile/${operation.did}`,
            target: "_blank",
            rel: "noopener",
            onClick: (e4) => e4.stopPropagation(),
            children: "View"
          }
        )
      ]
    }
  );
}
function formatTimeRange(startTime, endTime) {
  const startDate = new Date(startTime);
  const endDate = new Date(endTime);
  const dateOptions = { month: "short", day: "numeric" };
  const timeOptions = { hour: "2-digit", minute: "2-digit" };
  const startDateStr = startDate.toLocaleDateString(void 0, dateOptions);
  const startTimeStr = startDate.toLocaleTimeString(void 0, timeOptions);
  const endTimeStr = endDate.toLocaleTimeString(void 0, timeOptions);
  const endDateStr = endDate.toLocaleDateString(void 0, dateOptions);
  if (startDateStr === endDateStr) {
    return `${startDateStr}, ${startTimeStr} - ${endTimeStr}`;
  }
  return `${startDateStr} ${startTimeStr} - ${endDateStr} ${endTimeStr}`;
}

// src/components/manager/CopyUserTab.tsx
async function fetchProfilesViaBackground2(dids) {
  const response = await browser_default.runtime.sendMessage({
    type: "GET_PROFILES_BATCHED",
    dids
  });
  if (!response.success) {
    throw new Error(response.error || "Failed to fetch profiles");
  }
  const map = /* @__PURE__ */ new Map();
  if (response.profiles) {
    for (const [did, profile] of Object.entries(response.profiles)) {
      map.set(did, profile);
    }
  }
  return map;
}
function CopyUserTab({ onReload }) {
  const [handleInput, setHandleInput] = d2("");
  const [loadingProfiles, setLoadingProfiles] = d2(false);
  const [showFollowConfirm, setShowFollowConfirm] = d2(false);
  const [showBlockConfirm, setShowBlockConfirm] = d2(false);
  const loading2 = copyUserLoading.value;
  const progress = copyUserProgress.value;
  const error = copyUserError.value;
  const targetDid = copyUserTargetDid.value;
  const targetProfile = copyUserTargetProfile.value;
  const follows = copyUserFollows.value;
  const blocks2 = copyUserBlocks.value;
  const profiles = copyUserProfiles.value;
  const profilesError = copyUserProfilesError.value;
  const selectedFollows = copyUserSelectedFollows.value;
  const selectedBlocks = copyUserSelectedBlocks.value;
  const executing = copyUserExecuting.value;
  const executeProgress = copyUserExecuteProgress.value;
  y2(() => {
    if (follows.length === 0 && blocks2.length === 0) {
      copyUserProfilesLoaded.value = false;
      return;
    }
    const loadProfiles = async () => {
      try {
        const authResponse = await browser_default.runtime.sendMessage({ type: "GET_AUTH_STATUS" });
        if (!authResponse.success || !authResponse.isAuthenticated) {
          copyUserProfilesError.value = "Sign in to Bluesky to view profile details";
          copyUserProfilesLoaded.value = true;
          return;
        }
      } catch {
        copyUserProfilesError.value = "Sign in to Bluesky to view profile details";
        copyUserProfilesLoaded.value = true;
        return;
      }
      setLoadingProfiles(true);
      copyUserProfilesError.value = null;
      try {
        const allDids = [.../* @__PURE__ */ new Set([...follows, ...blocks2])];
        const profileMap = await fetchProfilesViaBackground2(allDids);
        copyUserProfiles.value = profileMap;
        copyUserProfilesLoaded.value = true;
      } catch (err) {
        console.error("[CopyUserTab] Failed to load profiles:", err);
        copyUserProfilesError.value = "Failed to load profile info. Click to retry.";
        copyUserProfilesLoaded.value = true;
      } finally {
        setLoadingProfiles(false);
      }
    };
    loadProfiles();
  }, [follows, blocks2]);
  const handleFetch = async () => {
    const handle = handleInput.trim().replace(/^@/, "");
    if (!handle) return;
    resetCopyUserState();
    copyUserTargetHandle.value = handle;
    copyUserLoading.value = true;
    copyUserProgress.value = "Resolving user...";
    try {
      const result = await browser_default.runtime.sendMessage({
        type: "FETCH_COPY_USER_DATA",
        handle
      });
      if (!result.success) {
        copyUserError.value = result.error || "Failed to fetch user data";
        return;
      }
      copyUserTargetDid.value = result.did || null;
      copyUserTargetProfile.value = result.profile || null;
      copyUserFollows.value = result.follows || [];
      copyUserBlocks.value = result.blocks || [];
      copyUserProgress.value = "";
    } catch (err) {
      copyUserError.value = err instanceof Error ? err.message : "Unknown error";
    } finally {
      copyUserLoading.value = false;
    }
  };
  const handleKeyPress = (e4) => {
    if (e4.key === "Enter" && !loading2) {
      handleFetch();
    }
  };
  const handleRetryProfiles = async () => {
    try {
      const authResponse = await browser_default.runtime.sendMessage({ type: "GET_AUTH_STATUS" });
      if (!authResponse.success || !authResponse.isAuthenticated) return;
    } catch {
      return;
    }
    setLoadingProfiles(true);
    copyUserProfilesError.value = null;
    try {
      const allDids = [.../* @__PURE__ */ new Set([...follows, ...blocks2])];
      const profileMap = await fetchProfilesViaBackground2(allDids);
      copyUserProfiles.value = profileMap;
      copyUserProfilesLoaded.value = true;
    } catch (err) {
      console.error("[CopyUserTab] Failed to load profiles:", err);
      copyUserProfilesError.value = "Failed to load profile info. Click to retry.";
    } finally {
      setLoadingProfiles(false);
    }
  };
  const getSelectableFollows = () => {
    return follows.filter((did) => {
      const profile = profiles.get(did);
      return !profile?.viewer?.following;
    });
  };
  const getSelectableBlocks = () => {
    return blocks2.filter((did) => {
      const profile = profiles.get(did);
      return !profile?.viewer?.blocking;
    });
  };
  const handleSelectAllFollows = () => {
    const selectables = getSelectableFollows();
    if (selectedFollows.size === selectables.length) {
      deselectAllCopyUserFollows();
    } else {
      selectAllCopyUserFollows(selectables);
    }
  };
  const handleSelectAllBlocks = () => {
    const selectables = getSelectableBlocks();
    if (selectedBlocks.size === selectables.length) {
      deselectAllCopyUserBlocks();
    } else {
      selectAllCopyUserBlocks(selectables);
    }
  };
  const executeFollows = async () => {
    setShowFollowConfirm(false);
    if (selectedFollows.size === 0) return;
    copyUserExecuting.value = true;
    copyUserExecuteProgress.value = { done: 0, total: selectedFollows.size, type: "follows" };
    try {
      const dids = Array.from(selectedFollows);
      const result = await browser_default.runtime.sendMessage({
        type: "EXECUTE_COPY_USER_FOLLOWS",
        dids
      });
      if (result.succeeded) {
        copyUserExecuteProgress.value = {
          done: result.succeeded,
          total: dids.length,
          type: "follows"
        };
      }
      deselectAllCopyUserFollows();
      const allDids = [.../* @__PURE__ */ new Set([...follows, ...blocks2])];
      const profileMap = await fetchProfilesViaBackground2(allDids);
      copyUserProfiles.value = profileMap;
      await onReload();
    } catch (err) {
      console.error("[CopyUserTab] Failed to execute follows:", err);
    } finally {
      copyUserExecuting.value = false;
    }
  };
  const executeBlocks = async () => {
    setShowBlockConfirm(false);
    if (selectedBlocks.size === 0) return;
    copyUserExecuting.value = true;
    copyUserExecuteProgress.value = { done: 0, total: selectedBlocks.size, type: "blocks" };
    try {
      const dids = Array.from(selectedBlocks);
      const result = await browser_default.runtime.sendMessage({
        type: "EXECUTE_COPY_USER_BLOCKS",
        dids
      });
      if (result.succeeded) {
        copyUserExecuteProgress.value = {
          done: result.succeeded,
          total: dids.length,
          type: "blocks"
        };
      }
      deselectAllCopyUserBlocks();
      const allDids = [.../* @__PURE__ */ new Set([...follows, ...blocks2])];
      const profileMap = await fetchProfilesViaBackground2(allDids);
      copyUserProfiles.value = profileMap;
      await onReload();
    } catch (err) {
      console.error("[CopyUserTab] Failed to execute blocks:", err);
    } finally {
      copyUserExecuting.value = false;
    }
  };
  if (!targetDid) {
    return /* @__PURE__ */ u4("div", { class: "copy-user-container", children: /* @__PURE__ */ u4("div", { class: "copy-user-intro", children: [
      /* @__PURE__ */ u4("h3", { children: "Copy User" }),
      /* @__PURE__ */ u4("p", { children: "Copy another user's follows and/or blocks to your account. Enter a handle below to download their public data and select which accounts to follow or block." }),
      /* @__PURE__ */ u4("div", { class: "copy-user-input-row", children: [
        /* @__PURE__ */ u4(
          "input",
          {
            type: "text",
            placeholder: "Enter handle (e.g., someone.bsky.social)",
            value: handleInput,
            onInput: (e4) => setHandleInput(e4.target.value),
            onKeyPress: handleKeyPress,
            disabled: loading2,
            class: "copy-user-handle-input"
          }
        ),
        /* @__PURE__ */ u4(
          "button",
          {
            class: "copy-user-fetch-btn",
            onClick: handleFetch,
            disabled: loading2 || !handleInput.trim(),
            children: [
              /* @__PURE__ */ u4(Search, { size: 16, class: loading2 ? "spinner" : "" }),
              loading2 ? "Fetching..." : "Fetch"
            ]
          }
        )
      ] }),
      loading2 && progress && /* @__PURE__ */ u4("div", { class: "copy-user-progress", children: progress }),
      error && /* @__PURE__ */ u4("div", { class: "copy-user-error", children: [
        /* @__PURE__ */ u4(CircleAlert, { size: 16 }),
        error
      ] })
    ] }) });
  }
  const selectableFollows = getSelectableFollows();
  const selectableBlocks = getSelectableBlocks();
  const allFollowsSelected = selectedFollows.size === selectableFollows.length && selectableFollows.length > 0;
  const allBlocksSelected = selectedBlocks.size === selectableBlocks.length && selectableBlocks.length > 0;
  return /* @__PURE__ */ u4("div", { class: "copy-user-container", children: [
    targetProfile && /* @__PURE__ */ u4("div", { class: "copy-user-target-card", children: [
      targetProfile.avatar && /* @__PURE__ */ u4("img", { src: targetProfile.avatar, alt: "", class: "copy-user-target-avatar" }),
      /* @__PURE__ */ u4("div", { class: "copy-user-target-info", children: [
        /* @__PURE__ */ u4("div", { class: "copy-user-target-name", children: targetProfile.displayName || targetProfile.handle }),
        /* @__PURE__ */ u4("div", { class: "copy-user-target-handle", children: [
          "@",
          targetProfile.handle
        ] })
      ] }),
      /* @__PURE__ */ u4(
        "button",
        {
          class: "copy-user-change-btn",
          onClick: () => resetCopyUserState(),
          disabled: executing,
          children: "Change User"
        }
      )
    ] }),
    /* @__PURE__ */ u4("div", { class: "copy-user-stats", children: [
      /* @__PURE__ */ u4("div", { class: "copy-user-stat", children: [
        /* @__PURE__ */ u4("div", { class: "stat-value", children: follows.length }),
        /* @__PURE__ */ u4("div", { class: "stat-label", children: "Follows" })
      ] }),
      /* @__PURE__ */ u4("div", { class: "copy-user-stat", children: [
        /* @__PURE__ */ u4("div", { class: "stat-value", children: blocks2.length }),
        /* @__PURE__ */ u4("div", { class: "stat-label", children: "Blocks" })
      ] })
    ] }),
    loadingProfiles && /* @__PURE__ */ u4("div", { class: "copy-user-loading-profiles", children: [
      /* @__PURE__ */ u4(LoaderCircle, { size: 16, class: "spinner" }),
      "Loading profile info..."
    ] }),
    profilesError && !loadingProfiles && /* @__PURE__ */ u4("div", { class: "copy-user-profiles-error", onClick: handleRetryProfiles, children: [
      /* @__PURE__ */ u4(CircleAlert, { size: 16 }),
      profilesError
    ] }),
    executing && /* @__PURE__ */ u4("div", { class: "copy-user-execute-progress", children: [
      /* @__PURE__ */ u4(LoaderCircle, { size: 16, class: "spinner" }),
      executeProgress.type === "follows" ? "Following" : "Blocking",
      ": ",
      executeProgress.done,
      " /",
      " ",
      executeProgress.total
    ] }),
    /* @__PURE__ */ u4("div", { class: "copy-user-lists", children: [
      /* @__PURE__ */ u4("div", { class: "copy-user-list", children: [
        /* @__PURE__ */ u4("div", { class: "copy-user-list-header", children: [
          /* @__PURE__ */ u4("h4", { children: [
            "Follows (",
            follows.length,
            ")"
          ] }),
          /* @__PURE__ */ u4(
            "button",
            {
              class: "copy-user-select-all-btn",
              onClick: handleSelectAllFollows,
              disabled: selectableFollows.length === 0 || executing,
              children: [
                allFollowsSelected ? /* @__PURE__ */ u4(SquareCheckBig, { size: 14 }) : /* @__PURE__ */ u4(Square, { size: 14 }),
                allFollowsSelected ? "Deselect All" : "Select All"
              ]
            }
          )
        ] }),
        /* @__PURE__ */ u4("div", { class: "copy-user-list-items", children: [
          follows.map((did) => /* @__PURE__ */ u4(
            UserRow,
            {
              did,
              profile: profiles.get(did),
              selected: selectedFollows.has(did),
              isAlreadyDone: !!profiles.get(did)?.viewer?.following,
              alreadyLabel: "Already following",
              onToggle: () => toggleCopyUserFollow(did),
              disabled: executing
            },
            did
          )),
          follows.length === 0 && /* @__PURE__ */ u4("div", { class: "copy-user-empty", children: "No follows found" })
        ] }),
        /* @__PURE__ */ u4("div", { class: "copy-user-list-actions", children: /* @__PURE__ */ u4(
          "button",
          {
            class: "copy-user-action-btn follow",
            onClick: () => setShowFollowConfirm(true),
            disabled: selectedFollows.size === 0 || executing,
            children: [
              /* @__PURE__ */ u4(UserPlus, { size: 16 }),
              "Follow Selected (",
              selectedFollows.size,
              ")"
            ]
          }
        ) })
      ] }),
      /* @__PURE__ */ u4("div", { class: "copy-user-list", children: [
        /* @__PURE__ */ u4("div", { class: "copy-user-list-header", children: [
          /* @__PURE__ */ u4("h4", { children: [
            "Blocks (",
            blocks2.length,
            ")"
          ] }),
          /* @__PURE__ */ u4(
            "button",
            {
              class: "copy-user-select-all-btn",
              onClick: handleSelectAllBlocks,
              disabled: selectableBlocks.length === 0 || executing,
              children: [
                allBlocksSelected ? /* @__PURE__ */ u4(SquareCheckBig, { size: 14 }) : /* @__PURE__ */ u4(Square, { size: 14 }),
                allBlocksSelected ? "Deselect All" : "Select All"
              ]
            }
          )
        ] }),
        /* @__PURE__ */ u4("div", { class: "copy-user-list-items", children: [
          blocks2.map((did) => /* @__PURE__ */ u4(
            UserRow,
            {
              did,
              profile: profiles.get(did),
              selected: selectedBlocks.has(did),
              isAlreadyDone: !!profiles.get(did)?.viewer?.blocking,
              alreadyLabel: "Already blocked",
              onToggle: () => toggleCopyUserBlock(did),
              disabled: executing
            },
            did
          )),
          blocks2.length === 0 && /* @__PURE__ */ u4("div", { class: "copy-user-empty", children: "No blocks found" })
        ] }),
        /* @__PURE__ */ u4("div", { class: "copy-user-list-actions", children: /* @__PURE__ */ u4(
          "button",
          {
            class: "copy-user-action-btn block",
            onClick: () => setShowBlockConfirm(true),
            disabled: selectedBlocks.size === 0 || executing,
            children: [
              /* @__PURE__ */ u4(Ban, { size: 16 }),
              "Block Selected (",
              selectedBlocks.size,
              ")"
            ]
          }
        ) })
      ] })
    ] }),
    showFollowConfirm && /* @__PURE__ */ u4("div", { class: "copy-user-confirm-overlay", children: /* @__PURE__ */ u4("div", { class: "copy-user-confirm-dialog", children: [
      /* @__PURE__ */ u4("h4", { children: "Confirm Follow" }),
      /* @__PURE__ */ u4("p", { children: [
        "Are you sure you want to follow ",
        selectedFollows.size,
        " accounts?"
      ] }),
      /* @__PURE__ */ u4("div", { class: "copy-user-confirm-actions", children: [
        /* @__PURE__ */ u4("button", { class: "copy-user-confirm-yes", onClick: executeFollows, children: "Yes, Follow" }),
        /* @__PURE__ */ u4("button", { class: "copy-user-confirm-no", onClick: () => setShowFollowConfirm(false), children: "Cancel" })
      ] })
    ] }) }),
    showBlockConfirm && /* @__PURE__ */ u4("div", { class: "copy-user-confirm-overlay", children: /* @__PURE__ */ u4("div", { class: "copy-user-confirm-dialog", children: [
      /* @__PURE__ */ u4("h4", { children: "Confirm Block" }),
      /* @__PURE__ */ u4("p", { children: [
        "Are you sure you want to block ",
        selectedBlocks.size,
        " accounts?"
      ] }),
      /* @__PURE__ */ u4("div", { class: "copy-user-confirm-actions", children: [
        /* @__PURE__ */ u4("button", { class: "copy-user-confirm-yes", onClick: executeBlocks, children: "Yes, Block" }),
        /* @__PURE__ */ u4("button", { class: "copy-user-confirm-no", onClick: () => setShowBlockConfirm(false), children: "Cancel" })
      ] })
    ] }) })
  ] });
}
function UserRow({
  did,
  profile,
  selected,
  isAlreadyDone,
  alreadyLabel,
  onToggle,
  disabled
}) {
  const displayName = profile?.displayName || profile?.handle;
  const displayIdentifier = displayName || (did.length > 40 ? `${did.slice(0, 20)}...${did.slice(-15)}` : did);
  return /* @__PURE__ */ u4(
    "div",
    {
      class: `copy-user-row ${selected ? "selected" : ""} ${isAlreadyDone ? "already-done" : ""}`,
      onClick: () => !isAlreadyDone && !disabled && onToggle(),
      children: [
        /* @__PURE__ */ u4("span", { class: "copy-user-row-checkbox", children: isAlreadyDone ? /* @__PURE__ */ u4(Check, { size: 14, class: "already-check" }) : selected ? /* @__PURE__ */ u4(SquareCheckBig, { size: 14 }) : /* @__PURE__ */ u4(Square, { size: 14 }) }),
        /* @__PURE__ */ u4(
          "a",
          {
            class: "copy-user-row-link",
            href: `https://bsky.app/profile/${did}`,
            target: "_blank",
            rel: "noopener",
            onClick: (e4) => e4.stopPropagation(),
            children: [
              profile?.avatar ? /* @__PURE__ */ u4("img", { src: profile.avatar, alt: "", class: "copy-user-row-avatar", loading: "lazy" }) : /* @__PURE__ */ u4("span", { class: "copy-user-row-avatar-placeholder" }),
              /* @__PURE__ */ u4("span", { class: "copy-user-row-identity", children: [
                /* @__PURE__ */ u4("span", { class: "copy-user-row-name", children: displayIdentifier }),
                displayName && profile?.handle && /* @__PURE__ */ u4("span", { class: "copy-user-row-handle", children: [
                  "@",
                  profile.handle
                ] })
              ] })
            ]
          }
        ),
        isAlreadyDone && /* @__PURE__ */ u4("span", { class: "copy-user-already-badge", children: alreadyLabel })
      ]
    }
  );
}

// src/components/manager/SettingsTab.tsx
var DURATION_OPTIONS = [
  { value: 36e5, label: "1 hour" },
  { value: 216e5, label: "6 hours" },
  { value: 432e5, label: "12 hours" },
  { value: 864e5, label: "24 hours" },
  { value: 2592e5, label: "3 days" },
  { value: 6048e5, label: "1 week" }
];
function SettingsTab({ onReload }) {
  const [options2, setLocalOptions] = d2(DEFAULT_OPTIONS);
  const [loading2, setLoading] = d2(true);
  const [saving, setSaving] = d2(false);
  const [status, setStatus] = d2(null);
  y2(() => {
    loadOptions();
  }, []);
  y2(() => {
    if (status) {
      const timer = setTimeout(() => setStatus(null), 3e3);
      return () => clearTimeout(timer);
    }
  }, [status]);
  const loadOptions = async () => {
    try {
      const loaded = await getOptions();
      setLocalOptions(loaded);
    } catch (error) {
      console.error("[SettingsTab] Failed to load options:", error);
      showStatus("Failed to load settings", "error");
    } finally {
      setLoading(false);
    }
  };
  const showStatus = (message, type) => {
    setStatus({ message, type });
  };
  const updateOption = q2(
    (key, value) => {
      setLocalOptions((prev) => ({ ...prev, [key]: value }));
    },
    []
  );
  const handleSave = async () => {
    setSaving(true);
    try {
      await setOptions(options2);
      await onReload();
      showStatus("Settings saved successfully!", "success");
    } catch (error) {
      console.error("[SettingsTab] Failed to save options:", error);
      showStatus("Failed to save settings", "error");
    } finally {
      setSaving(false);
    }
  };
  const handleReset = async () => {
    if (confirm("Reset all settings to defaults?")) {
      setSaving(true);
      try {
        await setOptions(DEFAULT_OPTIONS);
        setLocalOptions(DEFAULT_OPTIONS);
        await onReload();
        showStatus("Settings reset to defaults", "success");
      } catch (error) {
        console.error("[SettingsTab] Failed to reset options:", error);
        showStatus("Failed to reset settings", "error");
      } finally {
        setSaving(false);
      }
    }
  };
  if (loading2) {
    return /* @__PURE__ */ u4("div", { class: "blocklist-audit-container", children: /* @__PURE__ */ u4("div", { class: "blocklist-audit-empty", children: [
      /* @__PURE__ */ u4(RefreshCw, { size: 24, class: "spinner" }),
      /* @__PURE__ */ u4("p", { children: "Loading settings..." })
    ] }) });
  }
  return /* @__PURE__ */ u4("div", { class: "blocklist-audit-container", children: [
    /* @__PURE__ */ u4("div", { class: "blocklist-audit-header", children: /* @__PURE__ */ u4("div", { class: "blocklist-audit-stats", children: /* @__PURE__ */ u4("div", { class: "audit-stat", children: [
      /* @__PURE__ */ u4(Settings, { size: 24, style: { marginBottom: "4px", color: "#666" } }),
      /* @__PURE__ */ u4("div", { class: "audit-stat-label", children: "Extension Settings" })
    ] }) }) }),
    status && /* @__PURE__ */ u4(
      "div",
      {
        class: `settings-status-message ${status.type}`,
        style: {
          padding: "8px 12px",
          marginBottom: "16px",
          borderRadius: "6px",
          backgroundColor: status.type === "success" ? "#d4edda" : "#f8d7da",
          color: status.type === "success" ? "#155724" : "#721c24",
          border: `1px solid ${status.type === "success" ? "#c3e6cb" : "#f5c6cb"}`
        },
        children: status.message
      }
    ),
    /* @__PURE__ */ u4(
      "div",
      {
        class: "settings-sections",
        style: { display: "flex", flexDirection: "column", gap: "24px" },
        children: [
          /* @__PURE__ */ u4(SettingsSection, { title: "Default Duration", children: [
            /* @__PURE__ */ u4(
              SettingRow,
              {
                label: "Default block/mute duration",
                description: "How long blocks and mutes last by default",
                children: /* @__PURE__ */ u4(
                  DurationSelect,
                  {
                    value: options2.defaultDuration,
                    onChange: (value) => updateOption("defaultDuration", value)
                  }
                )
              }
            ),
            /* @__PURE__ */ u4(
              SettingRow,
              {
                label: "Quick block duration",
                description: "Skip the dialog and use this duration",
                children: /* @__PURE__ */ u4(
                  DurationSelect,
                  {
                    value: options2.quickBlockDuration,
                    onChange: (value) => updateOption("quickBlockDuration", value)
                  }
                )
              }
            )
          ] }),
          /* @__PURE__ */ u4(SettingsSection, { title: "Notifications", children: [
            /* @__PURE__ */ u4(
              SettingRow,
              {
                label: "Enable notifications",
                description: "Get alerts when blocks and mutes expire",
                children: /* @__PURE__ */ u4(
                  Checkbox,
                  {
                    id: "settings-notificationsEnabled",
                    label: "Notify me",
                    checked: options2.notificationsEnabled,
                    onChange: (checked) => updateOption("notificationsEnabled", checked)
                  }
                )
              }
            ),
            /* @__PURE__ */ u4(SettingRow, { label: "Notification sound", description: "Play sound with notifications", children: /* @__PURE__ */ u4(
              Checkbox,
              {
                id: "settings-notificationSound",
                label: "Enable sound",
                checked: options2.notificationSound,
                onChange: (checked) => updateOption("notificationSound", checked)
              }
            ) })
          ] }),
          /* @__PURE__ */ u4(SettingsSection, { title: "Expiration Check", children: /* @__PURE__ */ u4(
            SettingRow,
            {
              label: "Check interval",
              description: "How often to check for expired blocks/mutes",
              children: /* @__PURE__ */ u4(
                IntervalSelect,
                {
                  value: options2.checkInterval,
                  onChange: (value) => updateOption("checkInterval", value)
                }
              )
            }
          ) }),
          /* @__PURE__ */ u4(SettingsSection, { title: "Appearance", children: /* @__PURE__ */ u4(SettingRow, { label: "Theme", description: "Choose your color scheme", children: /* @__PURE__ */ u4(
            ThemeSelector,
            {
              value: options2.theme,
              onChange: (theme) => updateOption("theme", theme)
            }
          ) }) }),
          /* @__PURE__ */ u4(SettingsSection, { title: "Post Context", children: [
            /* @__PURE__ */ u4(
              SettingRow,
              {
                label: "Save post context",
                description: "Remember the post that triggered a block/mute",
                children: /* @__PURE__ */ u4(
                  Checkbox,
                  {
                    id: "settings-savePostContext",
                    label: "Save context",
                    checked: options2.savePostContext,
                    onChange: (checked) => updateOption("savePostContext", checked)
                  }
                )
              }
            ),
            /* @__PURE__ */ u4(
              SettingRow,
              {
                label: "Context retention",
                description: "How long to keep post context (0 = forever)",
                children: /* @__PURE__ */ u4(
                  NumberInput,
                  {
                    id: "settings-postContextRetentionDays",
                    value: options2.postContextRetentionDays,
                    min: 0,
                    max: 365,
                    unit: "days",
                    onChange: (value) => updateOption("postContextRetentionDays", value)
                  }
                )
              }
            )
          ] }),
          /* @__PURE__ */ u4(SettingsSection, { title: "Amnesty", children: /* @__PURE__ */ u4(
            SettingRow,
            {
              label: "Forgiveness period",
              description: "How old a block must be to appear in Amnesty review",
              children: /* @__PURE__ */ u4(
                NumberInput,
                {
                  id: "settings-forgivenessPeriodDays",
                  value: options2.forgivenessPeriodDays,
                  min: 1,
                  max: 365,
                  unit: "days",
                  onChange: (value) => updateOption("forgivenessPeriodDays", value)
                }
              )
            }
          ) }),
          /* @__PURE__ */ u4(SettingsSection, { title: "Last Word", children: [
            /* @__PURE__ */ u4(
              SettingRow,
              {
                label: "Default delay",
                description: "How long to wait before blocking when using Last Word",
                children: /* @__PURE__ */ u4(
                  NumberInput,
                  {
                    id: "settings-lastWordDelaySeconds",
                    value: options2.lastWordDelaySeconds,
                    min: 10,
                    max: 3600,
                    unit: "seconds",
                    onChange: (value) => updateOption("lastWordDelaySeconds", value)
                  }
                )
              }
            ),
            /* @__PURE__ */ u4(
              SettingRow,
              {
                label: "Mute during delay",
                description: "Mute the user while waiting, then unmute after blocking",
                children: /* @__PURE__ */ u4(
                  Checkbox,
                  {
                    id: "settings-lastWordMuteEnabled",
                    label: "Mute first",
                    checked: options2.lastWordMuteEnabled,
                    onChange: (checked) => updateOption("lastWordMuteEnabled", checked)
                  }
                )
              }
            )
          ] }),
          /* @__PURE__ */ u4(PdsCleanupSection, {}),
          /* @__PURE__ */ u4(PdsRecordCountsSection, {})
        ]
      }
    ),
    /* @__PURE__ */ u4(
      "div",
      {
        class: "settings-actions",
        style: {
          display: "flex",
          gap: "12px",
          marginTop: "24px",
          paddingTop: "16px",
          borderTop: "1px solid var(--border-color, #ddd)"
        },
        children: [
          /* @__PURE__ */ u4(
            "button",
            {
              class: "blocklist-action-btn primary",
              onClick: handleSave,
              disabled: saving,
              style: { display: "flex", alignItems: "center", gap: "6px" },
              children: [
                saving ? /* @__PURE__ */ u4(RefreshCw, { size: 14, class: "spinner" }) : /* @__PURE__ */ u4(Save, { size: 14 }),
                saving ? "Saving..." : "Save Settings"
              ]
            }
          ),
          /* @__PURE__ */ u4(
            "button",
            {
              class: "blocklist-action-btn",
              onClick: handleReset,
              disabled: saving,
              style: { display: "flex", alignItems: "center", gap: "6px" },
              children: [
                /* @__PURE__ */ u4(RotateCcw, { size: 14 }),
                "Reset to Defaults"
              ]
            }
          )
        ]
      }
    )
  ] });
}
function SettingsSection({ title, children }) {
  return /* @__PURE__ */ u4(
    "div",
    {
      class: "settings-section",
      style: {
        backgroundColor: "var(--card-bg, #f9f9f9)",
        borderRadius: "8px",
        padding: "16px",
        border: "1px solid var(--border-color, #e0e0e0)"
      },
      children: [
        /* @__PURE__ */ u4(
          "div",
          {
            class: "settings-section-title",
            style: {
              fontSize: "14px",
              fontWeight: "600",
              color: "var(--text-primary, #333)",
              marginBottom: "12px",
              paddingBottom: "8px",
              borderBottom: "1px solid var(--border-color, #e0e0e0)"
            },
            children: title
          }
        ),
        /* @__PURE__ */ u4("div", { style: { display: "flex", flexDirection: "column", gap: "12px" }, children })
      ]
    }
  );
}
function SettingRow({ label, description, children }) {
  return /* @__PURE__ */ u4(
    "div",
    {
      class: "setting-row",
      style: {
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        gap: "16px"
      },
      children: [
        /* @__PURE__ */ u4("div", { style: { flex: 1 }, children: [
          /* @__PURE__ */ u4("div", { style: { fontSize: "13px", fontWeight: "500", color: "var(--text-primary, #333)" }, children: label }),
          /* @__PURE__ */ u4("div", { style: { fontSize: "12px", color: "var(--text-secondary, #666)", marginTop: "2px" }, children: description })
        ] }),
        /* @__PURE__ */ u4("div", { style: { flexShrink: 0 }, children })
      ]
    }
  );
}
function DurationSelect({ value, onChange }) {
  return /* @__PURE__ */ u4(
    "select",
    {
      value,
      onChange: (e4) => onChange(parseInt(e4.target.value, 10)),
      style: {
        padding: "6px 10px",
        borderRadius: "6px",
        border: "1px solid var(--border-color, #ccc)",
        backgroundColor: "var(--input-bg, #fff)",
        color: "var(--text-primary, #333)",
        fontSize: "13px",
        minWidth: "120px"
      },
      children: DURATION_OPTIONS.map((option) => /* @__PURE__ */ u4("option", { value: option.value, children: option.label }, option.value))
    }
  );
}
function Checkbox({ id, label, checked, onChange }) {
  return /* @__PURE__ */ u4("div", { style: { display: "flex", alignItems: "center", gap: "8px" }, children: [
    /* @__PURE__ */ u4(
      "input",
      {
        type: "checkbox",
        id,
        checked,
        onChange: (e4) => onChange(e4.target.checked),
        style: { width: "16px", height: "16px", cursor: "pointer" }
      }
    ),
    /* @__PURE__ */ u4(
      "label",
      {
        for: id,
        style: { fontSize: "13px", color: "var(--text-primary, #333)", cursor: "pointer" },
        children: label
      }
    )
  ] });
}
var CHECK_INTERVAL_OPTIONS = [
  { value: 1, label: "1 minute" },
  { value: 5, label: "5 minutes" },
  { value: 15, label: "15 minutes" },
  { value: 30, label: "30 minutes" },
  { value: 60, label: "1 hour" },
  { value: 120, label: "2 hours" },
  { value: 360, label: "6 hours" },
  { value: 720, label: "12 hours" },
  { value: 1440, label: "24 hours" }
];
function IntervalSelect({ value, onChange }) {
  return /* @__PURE__ */ u4(
    "select",
    {
      value,
      onChange: (e4) => onChange(parseInt(e4.target.value, 10)),
      style: {
        padding: "6px 10px",
        borderRadius: "6px",
        border: "1px solid var(--border-color, #ccc)",
        backgroundColor: "var(--input-bg, #fff)",
        color: "var(--text-primary, #333)",
        fontSize: "13px",
        minWidth: "120px"
      },
      children: CHECK_INTERVAL_OPTIONS.map((option) => /* @__PURE__ */ u4("option", { value: option.value, children: option.label }, option.value))
    }
  );
}
function NumberInput({ id, value, min, max, unit, onChange }) {
  return /* @__PURE__ */ u4("div", { style: { display: "flex", alignItems: "center", gap: "8px" }, children: [
    /* @__PURE__ */ u4(
      "input",
      {
        type: "number",
        id,
        min,
        max,
        value,
        onChange: (e4) => {
          const val = parseInt(e4.target.value, 10);
          if (!isNaN(val) && val >= min && val <= max) {
            onChange(val);
          }
        },
        style: {
          width: "70px",
          padding: "6px 10px",
          borderRadius: "6px",
          border: "1px solid var(--border-color, #ccc)",
          backgroundColor: "var(--input-bg, #fff)",
          color: "var(--text-primary, #333)",
          fontSize: "13px"
        }
      }
    ),
    /* @__PURE__ */ u4("span", { style: { fontSize: "13px", color: "var(--text-secondary, #666)" }, children: unit })
  ] });
}
function ThemeSelector({ value, onChange }) {
  const themes = [
    { value: "auto", label: "Auto" },
    { value: "light", label: "Light" },
    { value: "dark", label: "Dark" }
  ];
  return /* @__PURE__ */ u4("div", { style: { display: "flex", gap: "12px" }, children: themes.map((theme) => /* @__PURE__ */ u4(
    "label",
    {
      style: {
        display: "flex",
        alignItems: "center",
        gap: "6px",
        fontSize: "13px",
        color: "var(--text-primary, #333)",
        cursor: "pointer"
      },
      children: [
        /* @__PURE__ */ u4(
          "input",
          {
            type: "radio",
            name: "settings-theme",
            value: theme.value,
            checked: value === theme.value,
            onChange: () => onChange(theme.value),
            style: { cursor: "pointer" }
          }
        ),
        /* @__PURE__ */ u4("span", { children: theme.label })
      ]
    },
    theme.value
  )) });
}
function PdsCleanupSection() {
  const [scanning, setScanning] = d2(false);
  const [deleting, setDeleting] = d2(false);
  const [scanResult, setScanResult] = d2(null);
  const [error, setError] = d2(null);
  const handleScan = async () => {
    setScanning(true);
    setError(null);
    setScanResult(null);
    try {
      const result = await browser_default.runtime.sendMessage({
        type: "SCAN_DUPLICATE_FOLLOWS",
        deleteDuplicates: false
      });
      if (!result.success) {
        setError(result.error || "Scan failed");
      } else {
        setScanResult(result);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to scan");
    } finally {
      setScanning(false);
    }
  };
  const handleDelete = async () => {
    if (!scanResult || scanResult.duplicateRecords === 0) return;
    const confirmed = confirm(
      `This will delete ${scanResult.duplicateRecords} duplicate follow records from your PDS. The oldest record for each followed user will be kept.

Continue?`
    );
    if (!confirmed) return;
    setDeleting(true);
    setError(null);
    try {
      const result = await browser_default.runtime.sendMessage({
        type: "SCAN_DUPLICATE_FOLLOWS",
        deleteDuplicates: true
      });
      if (!result.success) {
        setError(result.error || "Delete failed");
      } else {
        setScanResult(result);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to delete duplicates");
    } finally {
      setDeleting(false);
    }
  };
  return /* @__PURE__ */ u4(
    "div",
    {
      class: "settings-section",
      style: {
        backgroundColor: "var(--card-bg, #f9f9f9)",
        borderRadius: "8px",
        padding: "16px",
        border: "1px solid var(--border-color, #e0e0e0)"
      },
      children: [
        /* @__PURE__ */ u4(
          "div",
          {
            class: "settings-section-title",
            style: {
              fontSize: "14px",
              fontWeight: "600",
              color: "var(--text-primary, #333)",
              marginBottom: "12px",
              paddingBottom: "8px",
              borderBottom: "1px solid var(--border-color, #e0e0e0)"
            },
            children: "PDS Cleanup"
          }
        ),
        /* @__PURE__ */ u4("div", { style: { display: "flex", flexDirection: "column", gap: "12px" }, children: [
          /* @__PURE__ */ u4("div", { style: { fontSize: "13px", color: "var(--text-secondary, #666)" }, children: "Scan your PDS for duplicate follow records. These can occur when following users through different tools or during sync issues." }),
          error && /* @__PURE__ */ u4(
            "div",
            {
              style: {
                display: "flex",
                alignItems: "center",
                gap: "8px",
                padding: "8px 12px",
                backgroundColor: "#f8d7da",
                color: "#721c24",
                borderRadius: "6px",
                fontSize: "13px"
              },
              children: [
                /* @__PURE__ */ u4(CircleAlert, { size: 16 }),
                error
              ]
            }
          ),
          scanResult && /* @__PURE__ */ u4(
            "div",
            {
              style: {
                padding: "12px",
                backgroundColor: "var(--input-bg, #fff)",
                borderRadius: "6px",
                border: "1px solid var(--border-color, #ddd)"
              },
              children: [
                /* @__PURE__ */ u4(
                  "div",
                  {
                    style: {
                      display: "grid",
                      gridTemplateColumns: "repeat(2, 1fr)",
                      gap: "8px",
                      fontSize: "13px"
                    },
                    children: [
                      /* @__PURE__ */ u4("div", { children: [
                        /* @__PURE__ */ u4("span", { style: { color: "var(--text-secondary, #666)" }, children: "Total records: " }),
                        /* @__PURE__ */ u4("strong", { children: scanResult.totalRecords })
                      ] }),
                      /* @__PURE__ */ u4("div", { children: [
                        /* @__PURE__ */ u4("span", { style: { color: "var(--text-secondary, #666)" }, children: "Unique follows: " }),
                        /* @__PURE__ */ u4("strong", { children: scanResult.uniqueFollows })
                      ] }),
                      /* @__PURE__ */ u4("div", { children: [
                        /* @__PURE__ */ u4("span", { style: { color: "var(--text-secondary, #666)" }, children: "Users with dupes: " }),
                        /* @__PURE__ */ u4("strong", { style: { color: scanResult.duplicateDids ? "#dc3545" : "inherit" }, children: scanResult.duplicateDids })
                      ] }),
                      /* @__PURE__ */ u4("div", { children: [
                        /* @__PURE__ */ u4("span", { style: { color: "var(--text-secondary, #666)" }, children: "Extra records: " }),
                        /* @__PURE__ */ u4("strong", { style: { color: scanResult.duplicateRecords ? "#dc3545" : "inherit" }, children: scanResult.duplicateRecords })
                      ] })
                    ]
                  }
                ),
                scanResult.deleted !== void 0 && /* @__PURE__ */ u4(
                  "div",
                  {
                    style: {
                      marginTop: "8px",
                      paddingTop: "8px",
                      borderTop: "1px solid var(--border-color, #ddd)",
                      fontSize: "13px",
                      color: "#155724"
                    },
                    children: [
                      "Deleted ",
                      scanResult.deleted,
                      " duplicate records",
                      scanResult.deleteFailed ? ` (${scanResult.deleteFailed} failed)` : ""
                    ]
                  }
                ),
                scanResult.duplicateRecords === 0 && scanResult.deleted === void 0 && /* @__PURE__ */ u4(
                  "div",
                  {
                    style: {
                      marginTop: "8px",
                      paddingTop: "8px",
                      borderTop: "1px solid var(--border-color, #ddd)",
                      fontSize: "13px",
                      color: "#155724"
                    },
                    children: "No duplicates found - your PDS is clean!"
                  }
                )
              ]
            }
          ),
          /* @__PURE__ */ u4("div", { style: { display: "flex", gap: "8px", marginTop: "4px" }, children: [
            /* @__PURE__ */ u4(
              "button",
              {
                class: "blocklist-action-btn",
                onClick: handleScan,
                disabled: scanning || deleting,
                style: { display: "flex", alignItems: "center", gap: "6px" },
                children: [
                  scanning ? /* @__PURE__ */ u4(RefreshCw, { size: 14, class: "spinner" }) : /* @__PURE__ */ u4(Search, { size: 14 }),
                  scanning ? "Scanning..." : "Scan for Duplicates"
                ]
              }
            ),
            scanResult && scanResult.duplicateRecords !== void 0 && scanResult.duplicateRecords > 0 && scanResult.deleted === void 0 && /* @__PURE__ */ u4(
              "button",
              {
                class: "blocklist-action-btn",
                onClick: handleDelete,
                disabled: scanning || deleting,
                style: {
                  display: "flex",
                  alignItems: "center",
                  gap: "6px",
                  backgroundColor: "#dc3545",
                  color: "white",
                  borderColor: "#dc3545"
                },
                children: [
                  deleting ? /* @__PURE__ */ u4(RefreshCw, { size: 14, class: "spinner" }) : /* @__PURE__ */ u4(Trash2, { size: 14 }),
                  deleting ? "Deleting..." : `Delete ${scanResult.duplicateRecords} Duplicates`
                ]
              }
            )
          ] })
        ] })
      ]
    }
  );
}
function PdsRecordCountsSection() {
  const [loading2, setLoading] = d2(false);
  const [result, setResult] = d2(null);
  const [error, setError] = d2(null);
  const handleFetch = async () => {
    setLoading(true);
    setError(null);
    setResult(null);
    try {
      const response = await browser_default.runtime.sendMessage({
        type: "GET_PDS_RECORD_COUNTS"
      });
      if (!response.success) {
        setError(response.error || "Failed to fetch counts");
      } else {
        setResult(response);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to fetch counts");
    } finally {
      setLoading(false);
    }
  };
  const formatCount = (count) => {
    if (count === -1) return "Error";
    if (count >= 1e6) return `${(count / 1e6).toFixed(1)}M`;
    if (count >= 1e3) return `${(count / 1e3).toFixed(1)}K`;
    return count.toString();
  };
  return /* @__PURE__ */ u4(
    "div",
    {
      class: "settings-section",
      style: {
        backgroundColor: "var(--card-bg, #f9f9f9)",
        borderRadius: "8px",
        padding: "16px",
        border: "1px solid var(--border-color, #e0e0e0)"
      },
      children: [
        /* @__PURE__ */ u4(
          "div",
          {
            class: "settings-section-title",
            style: {
              fontSize: "14px",
              fontWeight: "600",
              color: "var(--text-primary, #333)",
              marginBottom: "12px",
              paddingBottom: "8px",
              borderBottom: "1px solid var(--border-color, #e0e0e0)"
            },
            children: "PDS Record Counts"
          }
        ),
        /* @__PURE__ */ u4("div", { style: { display: "flex", flexDirection: "column", gap: "12px" }, children: [
          /* @__PURE__ */ u4("div", { style: { fontSize: "13px", color: "var(--text-secondary, #666)" }, children: "View the number of records in each collection of your Personal Data Server." }),
          error && /* @__PURE__ */ u4(
            "div",
            {
              style: {
                display: "flex",
                alignItems: "center",
                gap: "8px",
                padding: "8px 12px",
                backgroundColor: "#f8d7da",
                color: "#721c24",
                borderRadius: "6px",
                fontSize: "13px"
              },
              children: [
                /* @__PURE__ */ u4(CircleAlert, { size: 16 }),
                error
              ]
            }
          ),
          result && result.collections && /* @__PURE__ */ u4(
            "div",
            {
              style: {
                padding: "12px",
                backgroundColor: "var(--input-bg, #fff)",
                borderRadius: "6px",
                border: "1px solid var(--border-color, #ddd)"
              },
              children: /* @__PURE__ */ u4(
                "div",
                {
                  style: {
                    display: "grid",
                    gridTemplateColumns: "repeat(2, 1fr)",
                    gap: "8px",
                    fontSize: "13px"
                  },
                  children: result.collections.map((col) => /* @__PURE__ */ u4("div", { children: [
                    /* @__PURE__ */ u4("span", { style: { color: "var(--text-secondary, #666)" }, children: [
                      col.label,
                      ": "
                    ] }),
                    /* @__PURE__ */ u4("strong", { style: { color: col.count === -1 ? "#dc3545" : "inherit" }, children: formatCount(col.count) })
                  ] }, col.id))
                }
              )
            }
          ),
          /* @__PURE__ */ u4("div", { style: { display: "flex", gap: "8px", marginTop: "4px" }, children: /* @__PURE__ */ u4(
            "button",
            {
              class: "blocklist-action-btn",
              onClick: handleFetch,
              disabled: loading2,
              style: { display: "flex", alignItems: "center", gap: "6px" },
              children: [
                loading2 ? /* @__PURE__ */ u4(RefreshCw, { size: 14, class: "spinner" }) : /* @__PURE__ */ u4(Database, { size: 14 }),
                loading2 ? "Counting..." : "Fetch Record Counts"
              ]
            }
          ) })
        ] })
      ]
    }
  );
}

// src/components/manager/ExportSection.tsx
function ExportSection() {
  const exportBlocksCSV = () => {
    const headers = ["DID", "Handle", "Display Name", "Source", "Expires At", "Created At"];
    const rows = blocks.value.map((b3) => [
      b3.did,
      b3.handle,
      b3.displayName || "",
      b3.source,
      b3.expiresAt ? new Date(b3.expiresAt).toISOString() : "",
      b3.createdAt ? new Date(b3.createdAt).toISOString() : b3.syncedAt ? new Date(b3.syncedAt).toISOString() : ""
    ]);
    const csv = [headers, ...rows].map((r4) => r4.map(escapeCSV).join(",")).join("\n");
    downloadCSV(csv, `ergoblock-blocks-${Date.now()}.csv`);
  };
  const exportMutesCSV = () => {
    const headers = ["DID", "Handle", "Display Name", "Source", "Expires At", "Created At"];
    const rows = mutes.value.map((m4) => [
      m4.did,
      m4.handle,
      m4.displayName || "",
      m4.source,
      m4.expiresAt ? new Date(m4.expiresAt).toISOString() : "",
      m4.createdAt ? new Date(m4.createdAt).toISOString() : m4.syncedAt ? new Date(m4.syncedAt).toISOString() : ""
    ]);
    const csv = [headers, ...rows].map((r4) => r4.map(escapeCSV).join(",")).join("\n");
    downloadCSV(csv, `ergoblock-mutes-${Date.now()}.csv`);
  };
  const exportHistoryCSV = () => {
    const headers = [
      "DID",
      "Handle",
      "Action",
      "Timestamp",
      "Trigger",
      "Success",
      "Error",
      "Duration"
    ];
    const rows = history.value.map((h5) => [
      h5.did,
      h5.handle,
      h5.action,
      new Date(h5.timestamp).toISOString(),
      h5.trigger,
      h5.success ? "Yes" : "No",
      h5.error || "",
      h5.duration ? Math.round(h5.duration / 1e3 / 60).toString() + " min" : ""
    ]);
    const csv = [headers, ...rows].map((r4) => r4.map(escapeCSV).join(",")).join("\n");
    downloadCSV(csv, `ergoblock-history-${Date.now()}.csv`);
  };
  const exportContextsCSV = () => {
    const headers = [
      "Post URI",
      "Post Author",
      "Target Handle",
      "Target DID",
      "Action",
      "Permanent",
      "Auto-detected",
      "Timestamp",
      "Post Text"
    ];
    const rows = contexts.value.map((c4) => [
      c4.postUri,
      c4.postAuthorHandle || c4.postAuthorDid,
      c4.targetHandle,
      c4.targetDid,
      c4.actionType,
      c4.permanent ? "Yes" : "No",
      c4.guessed ? "Yes" : "No",
      new Date(c4.timestamp).toISOString(),
      c4.postText || ""
    ]);
    const csv = [headers, ...rows].map((r4) => r4.map(escapeCSV).join(",")).join("\n");
    downloadCSV(csv, `ergoblock-contexts-${Date.now()}.csv`);
  };
  const exportAllJSON = () => {
    const data = {
      blocks: blocks.value,
      mutes: mutes.value,
      history: history.value,
      contexts: contexts.value,
      exportedAt: (/* @__PURE__ */ new Date()).toISOString()
    };
    downloadJSON(data, `ergoblock-export-${Date.now()}.json`);
  };
  return /* @__PURE__ */ u4("div", { class: "export-section", children: [
    /* @__PURE__ */ u4("h3", { children: "Export Data" }),
    /* @__PURE__ */ u4("div", { class: "export-buttons", children: [
      /* @__PURE__ */ u4("button", { class: "export-btn", onClick: exportBlocksCSV, children: "Export Blocks (CSV)" }),
      /* @__PURE__ */ u4("button", { class: "export-btn", onClick: exportMutesCSV, children: "Export Mutes (CSV)" }),
      /* @__PURE__ */ u4("button", { class: "export-btn", onClick: exportHistoryCSV, children: "Export History (CSV)" }),
      /* @__PURE__ */ u4("button", { class: "export-btn", onClick: exportContextsCSV, children: "Export Post Contexts (CSV)" }),
      /* @__PURE__ */ u4("button", { class: "export-btn", onClick: exportAllJSON, children: "Export Everything (JSON)" })
    ] })
  ] });
}

// src/manager.tsx
var TEMP_UNBLOCK_DURATION = 60 * 1e3;
function isValidResponse(response) {
  if (typeof response !== "object" || response === null) {
    return false;
  }
  const resp = response;
  return typeof resp.success === "boolean";
}
async function sendValidatedMessage(message) {
  const response = await browser_default.runtime.sendMessage(message);
  if (!isValidResponse(response)) {
    console.error("[Manager] Invalid response shape:", response);
    return { success: false, error: "Invalid response from background" };
  }
  return response;
}
function ManagerApp() {
  const loadData = q2(async () => {
    const [
      blocksData,
      mutesData,
      contextsData,
      syncData,
      reviewedDids,
      reviewsData,
      optionsData,
      auditState,
      auditConflicts
    ] = await Promise.all([
      getAllManagedBlocks(),
      getAllManagedMutes(),
      getPostContexts(),
      getSyncState(),
      getAmnestyReviewedDids(),
      getAmnestyReviews(),
      getOptions(),
      getBlocklistAuditState(),
      getBlocklistConflicts()
    ]);
    blocks.value = blocksData;
    mutes.value = mutesData;
    contexts.value = contextsData;
    syncState.value = syncData;
    amnestyReviewedDids.value = reviewedDids;
    amnestyReviews.value = reviewsData;
    options.value = optionsData;
    blocklistAuditState.value = auditState;
    blocklistConflicts.value = auditConflicts;
    loading.value = false;
  }, []);
  y2(() => {
    loadData();
    const interval = setInterval(loadData, 3e4);
    return () => clearInterval(interval);
  }, [loadData]);
  const handleSync = async () => {
    try {
      if (syncState.value) {
        syncState.value = { ...syncState.value, syncInProgress: true };
      }
      const response = await sendValidatedMessage({ type: "SYNC_NOW" });
      if (response.success) {
        await loadData();
      } else {
        if (syncState.value) {
          syncState.value = { ...syncState.value, syncInProgress: false };
        }
        alert(`Sync failed: ${response.error}`);
      }
    } catch (error) {
      console.error("[Manager] Sync error:", error);
      if (syncState.value) {
        syncState.value = { ...syncState.value, syncInProgress: false };
      }
      alert("Sync failed");
    }
  };
  const handleUnblock = async (did, handle) => {
    if (handle && !confirm(`Unblock @${handle}?`)) return;
    try {
      const response = await sendValidatedMessage({ type: "UNBLOCK_USER", did });
      if (!response.success) {
        console.error("[Manager] Unblock failed:", response.error);
        alert(`Failed to unblock: ${response.error}`);
        return;
      }
      const pendingTimer = tempUnblockTimers.value.get(did);
      if (pendingTimer) {
        window.clearTimeout(pendingTimer.timerId);
        const newTimers = new Map(tempUnblockTimers.value);
        newTimers.delete(did);
        tempUnblockTimers.value = newTimers;
      }
      await Promise.all([removeTempBlock(did), removePermanentBlock(did)]);
      await loadData();
    } catch (error) {
      console.error("[Manager] Unblock error:", error);
      alert("Failed to unblock user");
    }
  };
  const handleUnmute = async (did, handle) => {
    if (handle && !confirm(`Unmute @${handle}?`)) return;
    try {
      const response = await sendValidatedMessage({ type: "UNMUTE_USER", did });
      if (!response.success) {
        console.error("[Manager] Unmute failed:", response.error);
        alert(`Failed to unmute: ${response.error}`);
        return;
      }
      await Promise.all([removeTempMute(did), removePermanentMute(did)]);
      await loadData();
    } catch (error) {
      console.error("[Manager] Unmute error:", error);
      alert("Failed to unmute user");
    }
  };
  const handleFindContext = async (did, handle) => {
    setFindingContext(did, true);
    try {
      const response = await sendValidatedMessage({
        type: "FIND_CONTEXT",
        did,
        handle
      });
      if (!response.success) {
        throw new Error(response.error || "Failed to search");
      }
      if (response.found) {
        await loadData();
      } else {
        alert("No context found");
      }
    } catch (error) {
      console.error("[Manager] Find context failed:", error);
      alert("Failed to search for context");
    } finally {
      setFindingContext(did, false);
    }
  };
  const handleFetchInteractions = async (did, handle) => {
    setExpandedLoading(did, true);
    try {
      const response = await sendValidatedMessage({
        type: "FETCH_ALL_INTERACTIONS",
        did,
        handle
      });
      if (!response.success) {
        throw new Error(response.error || "Failed to fetch interactions");
      }
      setInteractions(did, response.interactions || []);
    } catch (error) {
      console.error("[Manager] Fetch interactions failed:", error);
      setInteractions(did, []);
    } finally {
      setExpandedLoading(did, false);
    }
  };
  const handleTempUnblockAndView = async (did, handle, url) => {
    if (tempUnblockTimers.value.has(did)) {
      window.open(url, "_blank");
      return;
    }
    try {
      const response = await sendValidatedMessage({
        type: "TEMP_UNBLOCK_FOR_VIEW",
        did,
        handle
      });
      if (!response.success) {
        throw new Error(response.error || "Failed to unblock");
      }
      window.open(url, "_blank");
      const expiresAt = Date.now() + TEMP_UNBLOCK_DURATION;
      const timerId = window.setTimeout(async () => {
        await reblockUser(did, handle);
      }, TEMP_UNBLOCK_DURATION);
      const newTimers = new Map(tempUnblockTimers.value);
      newTimers.set(did, { timerId, expiresAt });
      tempUnblockTimers.value = newTimers;
    } catch (error) {
      console.error("[Manager] Temp unblock failed:", error);
      alert(`Failed to unblock: ${error instanceof Error ? error.message : "Unknown error"}`);
    }
  };
  const reblockUser = async (did, handle) => {
    try {
      const response = await sendValidatedMessage({
        type: "REBLOCK_USER",
        did,
        handle
      });
      if (!response.success) {
        console.error("[Manager] Reblock failed:", response.error);
      }
    } catch (error) {
      console.error("[Manager] Reblock error:", error);
    } finally {
      const newTimers = new Map(tempUnblockTimers.value);
      newTimers.delete(did);
      tempUnblockTimers.value = newTimers;
    }
  };
  const handleBulkRemove = async () => {
    const count = selectedItems.value.size;
    if (count === 0) return;
    const selected = Array.from(selectedItems.value);
    const entries = allEntries.value;
    const toUnblock = selected.filter(
      (did) => entries.find((e4) => e4.did === did && (e4.type === "block" || e4.type === "both"))
    );
    const toUnmute = selected.filter(
      (did) => entries.find((e4) => e4.did === did && (e4.type === "mute" || e4.type === "both"))
    );
    const parts = [];
    if (toUnblock.length > 0) parts.push(`${toUnblock.length} block${toUnblock.length > 1 ? "s" : ""}`);
    if (toUnmute.length > 0) parts.push(`${toUnmute.length} mute${toUnmute.length > 1 ? "s" : ""}`);
    if (!confirm(`Remove ${parts.join(" and ")}?`)) return;
    for (const did of toUnblock) {
      await handleUnblock(did);
    }
    for (const did of toUnmute) {
      await handleUnmute(did);
    }
    clearSelection();
  };
  const getSyncStatusText = () => {
    if (!syncState.value) return "Last synced: Never";
    const lastSync = Math.max(syncState.value.lastBlockSync, syncState.value.lastMuteSync);
    const syncStartedTooLongAgo = syncState.value.syncInProgress && lastSync > 0 && Date.now() - lastSync > 5 * 60 * 1e3;
    if (syncState.value.syncInProgress && !syncStartedTooLongAgo) {
      return "Syncing...";
    }
    if (syncState.value.lastError) {
      return `Sync error: ${syncState.value.lastError}`;
    }
    if (lastSync > 0) {
      return `Last synced: ${formatTimeAgo(lastSync)}`;
    }
    return "Last synced: Never";
  };
  const isSyncing = syncState.value?.syncInProgress && !(syncState.value.syncInProgress && Math.max(syncState.value.lastBlockSync, syncState.value.lastMuteSync) > 0 && Date.now() - Math.max(syncState.value.lastBlockSync, syncState.value.lastMuteSync) > 5 * 60 * 1e3);
  const renderTabContent = () => {
    if (loading.value) {
      return /* @__PURE__ */ u4("div", { class: "loading", children: [
        /* @__PURE__ */ u4("div", { class: "spinner" }),
        /* @__PURE__ */ u4("p", { children: "Loading..." })
      ] });
    }
    switch (currentTab.value) {
      case "actions":
        return /* @__PURE__ */ u4(
          ActionsTable,
          {
            onUnblock: handleUnblock,
            onUnmute: handleUnmute,
            onFindContext: handleFindContext,
            onViewPost: handleTempUnblockAndView,
            onFetchInteractions: handleFetchInteractions
          }
        );
      case "amnesty":
        return /* @__PURE__ */ u4(
          AmnestyTab,
          {
            onUnblock: async (did) => handleUnblock(did),
            onUnmute: async (did) => handleUnmute(did),
            onTempUnblockAndView: handleTempUnblockAndView,
            onFetchInteractions: handleFetchInteractions,
            onReload: loadData
          }
        );
      case "blocklist-audit":
        return /* @__PURE__ */ u4(BlocklistAuditTab, { onReload: loadData });
      case "repost-filters":
        return /* @__PURE__ */ u4(RepostFiltersTab, { onReload: loadData });
      case "mass-ops":
        return /* @__PURE__ */ u4(MassOpsTab, { onReload: loadData });
      case "copy-user":
        return /* @__PURE__ */ u4(CopyUserTab, { onReload: loadData });
      case "settings":
        return /* @__PURE__ */ u4(SettingsTab, { onReload: loadData });
      default:
        return null;
    }
  };
  return /* @__PURE__ */ u4(k, { children: [
    /* @__PURE__ */ u4("header", { children: [
      /* @__PURE__ */ u4("h1", { children: "ErgoBlock Manager" }),
      /* @__PURE__ */ u4("div", { class: "sync-status", children: [
        /* @__PURE__ */ u4("span", { children: getSyncStatusText() }),
        /* @__PURE__ */ u4("button", { onClick: handleSync, disabled: isSyncing, class: isSyncing ? "syncing" : "", children: isSyncing ? /* @__PURE__ */ u4(k, { children: [
          /* @__PURE__ */ u4("span", { class: "spinner" }),
          "Syncing..."
        ] }) : "Sync Now" })
      ] })
    ] }),
    /* @__PURE__ */ u4("div", { class: "container", children: [
      /* @__PURE__ */ u4(StatsBar, {}),
      /* @__PURE__ */ u4(TabNav, {}),
      /* @__PURE__ */ u4(Toolbar, { onBulkRemove: handleBulkRemove }),
      /* @__PURE__ */ u4("div", { class: "table-container", children: renderTabContent() }),
      /* @__PURE__ */ u4(ExportSection, {})
    ] })
  ] });
}
var app = document.getElementById("app");
if (app) {
  G(/* @__PURE__ */ u4(ManagerApp, {}), app);
}
/*! Bundled license information:

lucide-preact/dist/esm/shared/src/utils.js:
lucide-preact/dist/esm/defaultAttributes.js:
lucide-preact/dist/esm/Icon.js:
lucide-preact/dist/esm/createLucideIcon.js:
lucide-preact/dist/esm/icons/ban.js:
lucide-preact/dist/esm/icons/check.js:
lucide-preact/dist/esm/icons/chevron-down.js:
lucide-preact/dist/esm/icons/chevron-right.js:
lucide-preact/dist/esm/icons/circle-alert.js:
lucide-preact/dist/esm/icons/copy.js:
lucide-preact/dist/esm/icons/database.js:
lucide-preact/dist/esm/icons/external-link.js:
lucide-preact/dist/esm/icons/eye-off.js:
lucide-preact/dist/esm/icons/eye.js:
lucide-preact/dist/esm/icons/funnel.js:
lucide-preact/dist/esm/icons/list.js:
lucide-preact/dist/esm/icons/loader-circle.js:
lucide-preact/dist/esm/icons/play.js:
lucide-preact/dist/esm/icons/plus.js:
lucide-preact/dist/esm/icons/refresh-cw.js:
lucide-preact/dist/esm/icons/rotate-ccw.js:
lucide-preact/dist/esm/icons/save.js:
lucide-preact/dist/esm/icons/search.js:
lucide-preact/dist/esm/icons/settings.js:
lucide-preact/dist/esm/icons/shield.js:
lucide-preact/dist/esm/icons/square-check-big.js:
lucide-preact/dist/esm/icons/square.js:
lucide-preact/dist/esm/icons/thumbs-down.js:
lucide-preact/dist/esm/icons/thumbs-up.js:
lucide-preact/dist/esm/icons/trash-2.js:
lucide-preact/dist/esm/icons/triangle-alert.js:
lucide-preact/dist/esm/icons/user-minus.js:
lucide-preact/dist/esm/icons/user-plus.js:
lucide-preact/dist/esm/icons/user-x.js:
lucide-preact/dist/esm/icons/users.js:
lucide-preact/dist/esm/lucide-preact.js:
  (**
   * @license lucide-preact v0.562.0 - ISC
   *
   * This source code is licensed under the ISC license.
   * See the LICENSE file in the root directory of this source tree.
   *)
*/
