var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// node_modules/webextension-polyfill/dist/browser-polyfill.js
var require_browser_polyfill = __commonJS({
  "node_modules/webextension-polyfill/dist/browser-polyfill.js"(exports, module) {
    (function(global, factory) {
      if (typeof define === "function" && define.amd) {
        define("webextension-polyfill", ["module"], factory);
      } else if (typeof exports !== "undefined") {
        factory(module);
      } else {
        var mod = {
          exports: {}
        };
        factory(mod);
        global.browser = mod.exports;
      }
    })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, function(module2) {
      "use strict";
      if (!(globalThis.chrome && globalThis.chrome.runtime && globalThis.chrome.runtime.id)) {
        throw new Error("This script should only be loaded in a browser extension.");
      }
      if (!(globalThis.browser && globalThis.browser.runtime && globalThis.browser.runtime.id)) {
        const CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE = "The message port closed before a response was received.";
        const wrapAPIs = (extensionAPIs) => {
          const apiMetadata = {
            "alarms": {
              "clear": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "clearAll": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "get": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "getAll": {
                "minArgs": 0,
                "maxArgs": 0
              }
            },
            "bookmarks": {
              "create": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "get": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getChildren": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getRecent": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getSubTree": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getTree": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "move": {
                "minArgs": 2,
                "maxArgs": 2
              },
              "remove": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeTree": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "search": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "update": {
                "minArgs": 2,
                "maxArgs": 2
              }
            },
            "browserAction": {
              "disable": {
                "minArgs": 0,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "enable": {
                "minArgs": 0,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "getBadgeBackgroundColor": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getBadgeText": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getPopup": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getTitle": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "openPopup": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "setBadgeBackgroundColor": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "setBadgeText": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "setIcon": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "setPopup": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "setTitle": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              }
            },
            "browsingData": {
              "remove": {
                "minArgs": 2,
                "maxArgs": 2
              },
              "removeCache": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeCookies": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeDownloads": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeFormData": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeHistory": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeLocalStorage": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removePasswords": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removePluginData": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "settings": {
                "minArgs": 0,
                "maxArgs": 0
              }
            },
            "commands": {
              "getAll": {
                "minArgs": 0,
                "maxArgs": 0
              }
            },
            "contextMenus": {
              "remove": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeAll": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "update": {
                "minArgs": 2,
                "maxArgs": 2
              }
            },
            "cookies": {
              "get": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getAll": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getAllCookieStores": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "remove": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "set": {
                "minArgs": 1,
                "maxArgs": 1
              }
            },
            "devtools": {
              "inspectedWindow": {
                "eval": {
                  "minArgs": 1,
                  "maxArgs": 2,
                  "singleCallbackArg": false
                }
              },
              "panels": {
                "create": {
                  "minArgs": 3,
                  "maxArgs": 3,
                  "singleCallbackArg": true
                },
                "elements": {
                  "createSidebarPane": {
                    "minArgs": 1,
                    "maxArgs": 1
                  }
                }
              }
            },
            "downloads": {
              "cancel": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "download": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "erase": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getFileIcon": {
                "minArgs": 1,
                "maxArgs": 2
              },
              "open": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "pause": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeFile": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "resume": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "search": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "show": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              }
            },
            "extension": {
              "isAllowedFileSchemeAccess": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "isAllowedIncognitoAccess": {
                "minArgs": 0,
                "maxArgs": 0
              }
            },
            "history": {
              "addUrl": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "deleteAll": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "deleteRange": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "deleteUrl": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getVisits": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "search": {
                "minArgs": 1,
                "maxArgs": 1
              }
            },
            "i18n": {
              "detectLanguage": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getAcceptLanguages": {
                "minArgs": 0,
                "maxArgs": 0
              }
            },
            "identity": {
              "launchWebAuthFlow": {
                "minArgs": 1,
                "maxArgs": 1
              }
            },
            "idle": {
              "queryState": {
                "minArgs": 1,
                "maxArgs": 1
              }
            },
            "management": {
              "get": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getAll": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "getSelf": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "setEnabled": {
                "minArgs": 2,
                "maxArgs": 2
              },
              "uninstallSelf": {
                "minArgs": 0,
                "maxArgs": 1
              }
            },
            "notifications": {
              "clear": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "create": {
                "minArgs": 1,
                "maxArgs": 2
              },
              "getAll": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "getPermissionLevel": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "update": {
                "minArgs": 2,
                "maxArgs": 2
              }
            },
            "pageAction": {
              "getPopup": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getTitle": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "hide": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "setIcon": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "setPopup": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "setTitle": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              },
              "show": {
                "minArgs": 1,
                "maxArgs": 1,
                "fallbackToNoCallback": true
              }
            },
            "permissions": {
              "contains": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getAll": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "remove": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "request": {
                "minArgs": 1,
                "maxArgs": 1
              }
            },
            "runtime": {
              "getBackgroundPage": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "getPlatformInfo": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "openOptionsPage": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "requestUpdateCheck": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "sendMessage": {
                "minArgs": 1,
                "maxArgs": 3
              },
              "sendNativeMessage": {
                "minArgs": 2,
                "maxArgs": 2
              },
              "setUninstallURL": {
                "minArgs": 1,
                "maxArgs": 1
              }
            },
            "sessions": {
              "getDevices": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "getRecentlyClosed": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "restore": {
                "minArgs": 0,
                "maxArgs": 1
              }
            },
            "storage": {
              "local": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getBytesInUse": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              },
              "managed": {
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getBytesInUse": {
                  "minArgs": 0,
                  "maxArgs": 1
                }
              },
              "sync": {
                "clear": {
                  "minArgs": 0,
                  "maxArgs": 0
                },
                "get": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "getBytesInUse": {
                  "minArgs": 0,
                  "maxArgs": 1
                },
                "remove": {
                  "minArgs": 1,
                  "maxArgs": 1
                },
                "set": {
                  "minArgs": 1,
                  "maxArgs": 1
                }
              }
            },
            "tabs": {
              "captureVisibleTab": {
                "minArgs": 0,
                "maxArgs": 2
              },
              "create": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "detectLanguage": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "discard": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "duplicate": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "executeScript": {
                "minArgs": 1,
                "maxArgs": 2
              },
              "get": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getCurrent": {
                "minArgs": 0,
                "maxArgs": 0
              },
              "getZoom": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "getZoomSettings": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "goBack": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "goForward": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "highlight": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "insertCSS": {
                "minArgs": 1,
                "maxArgs": 2
              },
              "move": {
                "minArgs": 2,
                "maxArgs": 2
              },
              "query": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "reload": {
                "minArgs": 0,
                "maxArgs": 2
              },
              "remove": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "removeCSS": {
                "minArgs": 1,
                "maxArgs": 2
              },
              "sendMessage": {
                "minArgs": 2,
                "maxArgs": 3
              },
              "setZoom": {
                "minArgs": 1,
                "maxArgs": 2
              },
              "setZoomSettings": {
                "minArgs": 1,
                "maxArgs": 2
              },
              "update": {
                "minArgs": 1,
                "maxArgs": 2
              }
            },
            "topSites": {
              "get": {
                "minArgs": 0,
                "maxArgs": 0
              }
            },
            "webNavigation": {
              "getAllFrames": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "getFrame": {
                "minArgs": 1,
                "maxArgs": 1
              }
            },
            "webRequest": {
              "handlerBehaviorChanged": {
                "minArgs": 0,
                "maxArgs": 0
              }
            },
            "windows": {
              "create": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "get": {
                "minArgs": 1,
                "maxArgs": 2
              },
              "getAll": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "getCurrent": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "getLastFocused": {
                "minArgs": 0,
                "maxArgs": 1
              },
              "remove": {
                "minArgs": 1,
                "maxArgs": 1
              },
              "update": {
                "minArgs": 2,
                "maxArgs": 2
              }
            }
          };
          if (Object.keys(apiMetadata).length === 0) {
            throw new Error("api-metadata.json has not been included in browser-polyfill");
          }
          class DefaultWeakMap extends WeakMap {
            constructor(createItem, items = void 0) {
              super(items);
              this.createItem = createItem;
            }
            get(key) {
              if (!this.has(key)) {
                this.set(key, this.createItem(key));
              }
              return super.get(key);
            }
          }
          const isThenable = (value) => {
            return value && typeof value === "object" && typeof value.then === "function";
          };
          const makeCallback = (promise, metadata) => {
            return (...callbackArgs) => {
              if (extensionAPIs.runtime.lastError) {
                promise.reject(new Error(extensionAPIs.runtime.lastError.message));
              } else if (metadata.singleCallbackArg || callbackArgs.length <= 1 && metadata.singleCallbackArg !== false) {
                promise.resolve(callbackArgs[0]);
              } else {
                promise.resolve(callbackArgs);
              }
            };
          };
          const pluralizeArguments = (numArgs) => numArgs == 1 ? "argument" : "arguments";
          const wrapAsyncFunction = (name, metadata) => {
            return function asyncFunctionWrapper(target, ...args) {
              if (args.length < metadata.minArgs) {
                throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
              }
              if (args.length > metadata.maxArgs) {
                throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
              }
              return new Promise((resolve, reject) => {
                if (metadata.fallbackToNoCallback) {
                  try {
                    target[name](...args, makeCallback({
                      resolve,
                      reject
                    }, metadata));
                  } catch (cbError) {
                    console.warn(`${name} API method doesn't seem to support the callback parameter, falling back to call it without a callback: `, cbError);
                    target[name](...args);
                    metadata.fallbackToNoCallback = false;
                    metadata.noCallback = true;
                    resolve();
                  }
                } else if (metadata.noCallback) {
                  target[name](...args);
                  resolve();
                } else {
                  target[name](...args, makeCallback({
                    resolve,
                    reject
                  }, metadata));
                }
              });
            };
          };
          const wrapMethod = (target, method, wrapper) => {
            return new Proxy(method, {
              apply(targetMethod, thisObj, args) {
                return wrapper.call(thisObj, target, ...args);
              }
            });
          };
          let hasOwnProperty = Function.call.bind(Object.prototype.hasOwnProperty);
          const wrapObject = (target, wrappers = {}, metadata = {}) => {
            let cache = /* @__PURE__ */ Object.create(null);
            let handlers = {
              has(proxyTarget2, prop) {
                return prop in target || prop in cache;
              },
              get(proxyTarget2, prop, receiver) {
                if (prop in cache) {
                  return cache[prop];
                }
                if (!(prop in target)) {
                  return void 0;
                }
                let value = target[prop];
                if (typeof value === "function") {
                  if (typeof wrappers[prop] === "function") {
                    value = wrapMethod(target, target[prop], wrappers[prop]);
                  } else if (hasOwnProperty(metadata, prop)) {
                    let wrapper = wrapAsyncFunction(prop, metadata[prop]);
                    value = wrapMethod(target, target[prop], wrapper);
                  } else {
                    value = value.bind(target);
                  }
                } else if (typeof value === "object" && value !== null && (hasOwnProperty(wrappers, prop) || hasOwnProperty(metadata, prop))) {
                  value = wrapObject(value, wrappers[prop], metadata[prop]);
                } else if (hasOwnProperty(metadata, "*")) {
                  value = wrapObject(value, wrappers[prop], metadata["*"]);
                } else {
                  Object.defineProperty(cache, prop, {
                    configurable: true,
                    enumerable: true,
                    get() {
                      return target[prop];
                    },
                    set(value2) {
                      target[prop] = value2;
                    }
                  });
                  return value;
                }
                cache[prop] = value;
                return value;
              },
              set(proxyTarget2, prop, value, receiver) {
                if (prop in cache) {
                  cache[prop] = value;
                } else {
                  target[prop] = value;
                }
                return true;
              },
              defineProperty(proxyTarget2, prop, desc) {
                return Reflect.defineProperty(cache, prop, desc);
              },
              deleteProperty(proxyTarget2, prop) {
                return Reflect.deleteProperty(cache, prop);
              }
            };
            let proxyTarget = Object.create(target);
            return new Proxy(proxyTarget, handlers);
          };
          const wrapEvent = (wrapperMap) => ({
            addListener(target, listener, ...args) {
              target.addListener(wrapperMap.get(listener), ...args);
            },
            hasListener(target, listener) {
              return target.hasListener(wrapperMap.get(listener));
            },
            removeListener(target, listener) {
              target.removeListener(wrapperMap.get(listener));
            }
          });
          const onRequestFinishedWrappers = new DefaultWeakMap((listener) => {
            if (typeof listener !== "function") {
              return listener;
            }
            return function onRequestFinished(req) {
              const wrappedReq = wrapObject(req, {}, {
                getContent: {
                  minArgs: 0,
                  maxArgs: 0
                }
              });
              listener(wrappedReq);
            };
          });
          const onMessageWrappers = new DefaultWeakMap((listener) => {
            if (typeof listener !== "function") {
              return listener;
            }
            return function onMessage(message, sender, sendResponse) {
              let didCallSendResponse = false;
              let wrappedSendResponse;
              let sendResponsePromise = new Promise((resolve) => {
                wrappedSendResponse = function(response) {
                  didCallSendResponse = true;
                  resolve(response);
                };
              });
              let result;
              try {
                result = listener(message, sender, wrappedSendResponse);
              } catch (err) {
                result = Promise.reject(err);
              }
              const isResultThenable = result !== true && isThenable(result);
              if (result !== true && !isResultThenable && !didCallSendResponse) {
                return false;
              }
              const sendPromisedResult = (promise) => {
                promise.then((msg) => {
                  sendResponse(msg);
                }, (error) => {
                  let message2;
                  if (error && (error instanceof Error || typeof error.message === "string")) {
                    message2 = error.message;
                  } else {
                    message2 = "An unexpected error occurred";
                  }
                  sendResponse({
                    __mozWebExtensionPolyfillReject__: true,
                    message: message2
                  });
                }).catch((err) => {
                  console.error("Failed to send onMessage rejected reply", err);
                });
              };
              if (isResultThenable) {
                sendPromisedResult(result);
              } else {
                sendPromisedResult(sendResponsePromise);
              }
              return true;
            };
          });
          const wrappedSendMessageCallback = ({
            reject,
            resolve
          }, reply) => {
            if (extensionAPIs.runtime.lastError) {
              if (extensionAPIs.runtime.lastError.message === CHROME_SEND_MESSAGE_CALLBACK_NO_RESPONSE_MESSAGE) {
                resolve();
              } else {
                reject(new Error(extensionAPIs.runtime.lastError.message));
              }
            } else if (reply && reply.__mozWebExtensionPolyfillReject__) {
              reject(new Error(reply.message));
            } else {
              resolve(reply);
            }
          };
          const wrappedSendMessage = (name, metadata, apiNamespaceObj, ...args) => {
            if (args.length < metadata.minArgs) {
              throw new Error(`Expected at least ${metadata.minArgs} ${pluralizeArguments(metadata.minArgs)} for ${name}(), got ${args.length}`);
            }
            if (args.length > metadata.maxArgs) {
              throw new Error(`Expected at most ${metadata.maxArgs} ${pluralizeArguments(metadata.maxArgs)} for ${name}(), got ${args.length}`);
            }
            return new Promise((resolve, reject) => {
              const wrappedCb = wrappedSendMessageCallback.bind(null, {
                resolve,
                reject
              });
              args.push(wrappedCb);
              apiNamespaceObj.sendMessage(...args);
            });
          };
          const staticWrappers = {
            devtools: {
              network: {
                onRequestFinished: wrapEvent(onRequestFinishedWrappers)
              }
            },
            runtime: {
              onMessage: wrapEvent(onMessageWrappers),
              onMessageExternal: wrapEvent(onMessageWrappers),
              sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                minArgs: 1,
                maxArgs: 3
              })
            },
            tabs: {
              sendMessage: wrappedSendMessage.bind(null, "sendMessage", {
                minArgs: 2,
                maxArgs: 3
              })
            }
          };
          const settingMetadata = {
            clear: {
              minArgs: 1,
              maxArgs: 1
            },
            get: {
              minArgs: 1,
              maxArgs: 1
            },
            set: {
              minArgs: 1,
              maxArgs: 1
            }
          };
          apiMetadata.privacy = {
            network: {
              "*": settingMetadata
            },
            services: {
              "*": settingMetadata
            },
            websites: {
              "*": settingMetadata
            }
          };
          return wrapObject(extensionAPIs, staticWrappers, apiMetadata);
        };
        module2.exports = wrapAPIs(chrome);
      } else {
        module2.exports = globalThis.browser;
      }
    });
  }
});

// src/browser.ts
var import_webextension_polyfill = __toESM(require_browser_polyfill(), 1);
var browser_default = import_webextension_polyfill.default;

// src/utils.ts
var LOG_LEVEL_PRIORITY = {
  debug: 0,
  info: 1,
  warn: 2,
  error: 3
};
var currentLogLevel = "info";
var logger = {
  debug: (message, ...args) => {
    if (LOG_LEVEL_PRIORITY[currentLogLevel] <= LOG_LEVEL_PRIORITY.debug) {
      console.debug(`[ErgoBlock] ${message}`, ...args);
    }
  },
  info: (message, ...args) => {
    if (LOG_LEVEL_PRIORITY[currentLogLevel] <= LOG_LEVEL_PRIORITY.info) {
      console.log(`[ErgoBlock] ${message}`, ...args);
    }
  },
  warn: (message, ...args) => {
    if (LOG_LEVEL_PRIORITY[currentLogLevel] <= LOG_LEVEL_PRIORITY.warn) {
      console.warn(`[ErgoBlock] ${message}`, ...args);
    }
  },
  error: (message, ...args) => {
    if (LOG_LEVEL_PRIORITY[currentLogLevel] <= LOG_LEVEL_PRIORITY.error) {
      console.error(`[ErgoBlock] ${message}`, ...args);
    }
  }
};
var RateLimiter = class {
  constructor(options = {}) {
    this.lastActionTime = 0;
    this.actionCount = 0;
    this.windowMs = options.windowMs ?? 1e4;
    this.maxActions = options.maxActions ?? 5;
    this.cooldownMs = options.cooldownMs ?? 2e3;
  }
  /**
   * Check if an action is allowed
   * @returns true if allowed, false if rate limited
   */
  canPerformAction() {
    const now = Date.now();
    if (now - this.lastActionTime > this.windowMs) {
      this.actionCount = 0;
    }
    if (now - this.lastActionTime < this.cooldownMs) {
      return false;
    }
    if (this.actionCount >= this.maxActions) {
      return false;
    }
    return true;
  }
  /**
   * Record an action
   */
  recordAction() {
    const now = Date.now();
    if (now - this.lastActionTime > this.windowMs) {
      this.actionCount = 0;
    }
    this.lastActionTime = now;
    this.actionCount++;
  }
  /**
   * Get time until next action is allowed (in ms)
   */
  getWaitTime() {
    const now = Date.now();
    const cooldownRemaining = Math.max(0, this.cooldownMs - (now - this.lastActionTime));
    if (this.actionCount >= this.maxActions) {
      const windowRemaining = Math.max(0, this.windowMs - (now - this.lastActionTime));
      return Math.max(cooldownRemaining, windowRemaining);
    }
    return cooldownRemaining;
  }
};
var actionRateLimiter = new RateLimiter({
  windowMs: 1e4,
  // 10 seconds
  maxActions: 5,
  // Max 5 blocks/mutes per 10 seconds
  cooldownMs: 1e3
  // 1 second minimum between actions
});
var CircuitBreaker = class {
  constructor(options = {}) {
    this.state = "closed";
    this.failures = 0;
    this.lastFailureTime = 0;
    this.successesSinceHalfOpen = 0;
    this.failureThreshold = options.failureThreshold ?? 5;
    this.resetTimeoutMs = options.resetTimeoutMs ?? 6e4;
    this.halfOpenSuccessThreshold = options.halfOpenSuccessThreshold ?? 2;
  }
  /**
   * Get current circuit state
   */
  getState() {
    this.updateState();
    return this.state;
  }
  /**
   * Check if circuit allows requests
   */
  isAllowed() {
    this.updateState();
    return this.state !== "open";
  }
  /**
   * Record a successful operation
   */
  recordSuccess() {
    this.updateState();
    if (this.state === "half-open") {
      this.successesSinceHalfOpen++;
      if (this.successesSinceHalfOpen >= this.halfOpenSuccessThreshold) {
        this.reset();
      }
    } else if (this.state === "closed") {
      this.failures = Math.max(0, this.failures - 1);
    }
  }
  /**
   * Record a failed operation
   */
  recordFailure() {
    this.updateState();
    if (this.state === "half-open") {
      this.trip();
    } else if (this.state === "closed") {
      this.failures++;
      this.lastFailureTime = Date.now();
      if (this.failures >= this.failureThreshold) {
        this.trip();
      }
    }
  }
  /**
   * Manually reset the circuit
   */
  reset() {
    this.state = "closed";
    this.failures = 0;
    this.successesSinceHalfOpen = 0;
    logger.info("Circuit breaker reset to closed");
  }
  trip() {
    this.state = "open";
    this.lastFailureTime = Date.now();
    logger.warn(`Circuit breaker opened after ${this.failures} failures`);
  }
  updateState() {
    if (this.state === "open") {
      const now = Date.now();
      if (now - this.lastFailureTime >= this.resetTimeoutMs) {
        this.state = "half-open";
        this.successesSinceHalfOpen = 0;
        logger.info("Circuit breaker entering half-open state");
      }
    }
  }
};
var apiCircuitBreaker = new CircuitBreaker({
  failureThreshold: 5,
  resetTimeoutMs: 6e4,
  // 1 minute
  halfOpenSuccessThreshold: 2
});
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
function isValidDid(did) {
  if (!did || typeof did !== "string") return false;
  return /^did:(plc|web):[a-zA-Z0-9._:%-]+$/.test(did);
}
function isValidDuration(durationMs) {
  if (typeof durationMs !== "number") return false;
  if (!Number.isFinite(durationMs)) return false;
  if (durationMs <= 0) return false;
  const ONE_YEAR_MS = 365 * 24 * 60 * 60 * 1e3;
  if (durationMs > ONE_YEAR_MS) return false;
  return true;
}
function generateId(prefix) {
  return `${prefix}_${Date.now()}_${Math.random().toString(36).substring(2, 11)}`;
}
function isRetryableError(error) {
  const message = error.message.toLowerCase();
  if (message.includes("network") || message.includes("fetch") || message.includes("timeout") || message.includes("econnreset") || message.includes("enotfound")) {
    return true;
  }
  if (message.includes("429") || message.includes("rate limit")) {
    return true;
  }
  if (message.includes("500") || message.includes("502") || message.includes("503") || message.includes("504")) {
    return true;
  }
  if (message.includes("401") || message.includes("auth error")) {
    return false;
  }
  if (message.includes("expiredtoken") || message.includes("token has expired") || message.includes("expired token")) {
    return false;
  }
  if (message.includes("400") || message.includes("403") || message.includes("404")) {
    return false;
  }
  return false;
}
async function withRetry(fn, options = {}) {
  if (typeof fn !== "function") {
    throw new TypeError("withRetry: first argument must be a function");
  }
  const {
    maxRetries = 3,
    initialDelayMs = 1e3,
    maxDelayMs = 3e4,
    backoffMultiplier = 2,
    isRetryable = isRetryableError,
    onRetry
  } = options;
  if (maxRetries < 0 || !Number.isFinite(maxRetries)) {
    throw new TypeError("withRetry: maxRetries must be a non-negative finite number");
  }
  let lastError;
  let delay = initialDelayMs;
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const result = fn();
      if (result && typeof result.then === "function") {
        return await result;
      }
      return result;
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));
      if (attempt === maxRetries || !isRetryable(lastError)) {
        throw lastError;
      }
      const jitter = delay * 0.1 * (Math.random() * 2 - 1);
      const actualDelay = Math.min(delay + jitter, maxDelayMs);
      onRetry?.(attempt + 1, lastError, actualDelay);
      logger.info(
        `Retry ${attempt + 1}/${maxRetries} after ${Math.round(actualDelay)}ms: ${lastError.message}`
      );
      await sleep(actualDelay);
      delay = Math.min(delay * backoffMultiplier, maxDelayMs);
    }
  }
  throw lastError || new Error("Retry failed");
}
var Mutex = class {
  constructor() {
    this._locked = false;
    this._queue = [];
  }
  /**
   * Check if the mutex is currently locked (for diagnostics only)
   */
  get isLocked() {
    return this._locked;
  }
  /**
   * Acquire the mutex lock. Returns a release function.
   * If the mutex is already locked, waits until it becomes available.
   */
  async acquire() {
    return new Promise((resolve) => {
      const tryAcquire = () => {
        if (!this._locked) {
          this._locked = true;
          resolve(() => this.release());
        } else {
          this._queue.push(tryAcquire);
        }
      };
      tryAcquire();
    });
  }
  /**
   * Release the mutex lock, allowing the next waiter to proceed.
   */
  release() {
    if (this._queue.length > 0) {
      const next = this._queue.shift();
      if (next) {
        queueMicrotask(next);
      }
    } else {
      this._locked = false;
    }
  }
  /**
   * Execute a function with the mutex held.
   * Automatically releases the mutex when done (even on error).
   */
  async runExclusive(fn) {
    const release = await this.acquire();
    try {
      return await fn();
    } finally {
      release();
    }
  }
};
var LRUCache = class {
  /**
   * @param maxSize - Maximum number of entries (default: 1000)
   * @param ttlMs - Time-to-live in ms, null for no expiry (default: null)
   */
  constructor(maxSize = 1e3, ttlMs = null) {
    this.cache = /* @__PURE__ */ new Map();
    this.maxSize = maxSize;
    this.ttlMs = ttlMs;
  }
  /**
   * Get a value from the cache.
   * Returns undefined if not found or expired.
   */
  get(key) {
    const entry = this.cache.get(key);
    if (!entry) {
      return void 0;
    }
    if (this.ttlMs !== null && Date.now() - entry.timestamp > this.ttlMs) {
      this.cache.delete(key);
      return void 0;
    }
    this.cache.delete(key);
    this.cache.set(key, entry);
    return entry.value;
  }
  /**
   * Set a value in the cache.
   * Evicts oldest entry if at capacity.
   */
  set(key, value) {
    this.cache.delete(key);
    if (this.cache.size >= this.maxSize) {
      const oldestKey = this.cache.keys().next().value;
      if (oldestKey !== void 0) {
        this.cache.delete(oldestKey);
      }
    }
    this.cache.set(key, { value, timestamp: Date.now() });
  }
  /**
   * Check if a key exists (and is not expired).
   */
  has(key) {
    return this.get(key) !== void 0;
  }
  /**
   * Delete a key from the cache.
   */
  delete(key) {
    return this.cache.delete(key);
  }
  /**
   * Clear all entries from the cache.
   */
  clear() {
    this.cache.clear();
  }
  /**
   * Get current cache size.
   */
  get size() {
    return this.cache.size;
  }
  /**
   * Remove all expired entries (useful for periodic cleanup).
   */
  prune() {
    if (this.ttlMs === null) {
      return 0;
    }
    const now = Date.now();
    let pruned = 0;
    for (const [key, entry] of this.cache.entries()) {
      if (now - entry.timestamp > this.ttlMs) {
        this.cache.delete(key);
        pruned++;
      }
    }
    return pruned;
  }
};
function textContainsMention(text, handle) {
  if (!text || !handle || typeof text !== "string" || typeof handle !== "string") {
    return false;
  }
  const normalizedText = text.toLowerCase();
  const normalizedHandle = handle.toLowerCase();
  const escapedHandle = normalizedHandle.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const mentionRegex = new RegExp(`@${escapedHandle}(?=[\\s.,!?;:'"\\)\\]}>]|$)`, "i");
  return mentionRegex.test(normalizedText);
}
var RequestCoalescer = class {
  constructor() {
    this.pending = /* @__PURE__ */ new Map();
  }
  /**
   * Execute a function, deduplicating concurrent calls with the same key.
   * @param key - Unique key for deduplication
   * @param fn - Async function to execute
   * @returns Result of the function
   */
  async execute(key, fn) {
    const existing = this.pending.get(key);
    if (existing) {
      return existing;
    }
    const promise = fn().finally(() => {
      this.pending.delete(key);
    });
    this.pending.set(key, promise);
    return promise;
  }
  /**
   * Check if a request is currently pending for a key.
   */
  isPending(key) {
    return this.pending.has(key);
  }
  /**
   * Get count of pending requests.
   */
  get pendingCount() {
    return this.pending.size;
  }
};

// src/api.ts
var DEFAULT_TIMEOUT_MS = 3e4;
var BSKY_PUBLIC_API = "https://public.api.bsky.app";
async function executeApiRequest(endpoint, method, body, auth, targetBaseUrl, options = {}) {
  const {
    timeoutMs = DEFAULT_TIMEOUT_MS,
    // Default: retry GET requests, don't retry mutations (POST/DELETE) to avoid duplicates
    retry = method === "GET",
    maxRetries = 3
  } = options;
  if (!apiCircuitBreaker.isAllowed()) {
    const state = apiCircuitBreaker.getState();
    logger.warn(`Circuit breaker is ${state}, rejecting request to ${endpoint}`);
    throw new Error(`API circuit breaker is open. Service may be unavailable. Please try again later.`);
  }
  let base = targetBaseUrl;
  if (!base) {
    if (endpoint.startsWith("com.atproto.repo.")) {
      base = auth.pdsUrl;
    } else {
      base = BSKY_PUBLIC_API;
    }
  }
  if (!base) {
    throw new Error("Could not determine base URL for API request");
  }
  base = base.replace(/\/+$/, "");
  const url = `${base}/xrpc/${endpoint}`;
  const doRequest = async () => {
    logger.debug("API request:", method, url);
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const fetchOptions = {
        method,
        headers: {
          Authorization: `Bearer ${auth.accessJwt}`,
          "Content-Type": "application/json"
        },
        signal: controller.signal
      };
      if (body) {
        fetchOptions.body = JSON.stringify(body);
      }
      const response = await fetch(url, fetchOptions);
      if (!response.ok) {
        const error = await response.json().catch(() => ({}));
        const errorCode = error.error || "";
        const errorMessage = error.message || error.error || `API error: ${response.status}`;
        const isBlockError = errorCode === "BlockedActor" || errorCode === "BlockedByActor" || errorMessage.includes("blocked");
        const isExpiredToken = errorCode === "ExpiredToken" || errorMessage.toLowerCase().includes("token has expired") || errorMessage.toLowerCase().includes("expired token");
        if (isExpiredToken) {
          logger.debug("Session token expired, waiting for Bluesky to refresh...");
        } else if (!isBlockError) {
          logger.error("API error:", response.status, JSON.stringify(error));
        }
        if (response.status >= 500) {
          apiCircuitBreaker.recordFailure();
        }
        if (response.status === 401) {
          throw new Error(`Auth error: ${response.status} ${errorMessage}`);
        }
        throw new Error(`${response.status}: ${errorMessage}`);
      }
      apiCircuitBreaker.recordSuccess();
      const text = await response.text();
      return text ? JSON.parse(text) : null;
    } catch (error) {
      if (error instanceof Error && error.name === "AbortError") {
        apiCircuitBreaker.recordFailure();
        throw new Error(`Request timeout after ${timeoutMs}ms: ${url}`);
      }
      apiCircuitBreaker.recordFailure();
      throw error;
    } finally {
      clearTimeout(timeoutId);
    }
  };
  if (retry) {
    return withRetry(doRequest, {
      maxRetries,
      initialDelayMs: 1e3,
      maxDelayMs: 1e4,
      isRetryable: isRetryableError
    });
  }
  return doRequest();
}

// src/types.ts
var DEFAULT_OPTIONS = {
  defaultDuration: 864e5,
  // 24 hours
  quickBlockDuration: 36e5,
  // 1 hour
  notificationsEnabled: true,
  notificationSound: false,
  checkInterval: 1,
  theme: "auto",
  // Post context defaults
  savePostContext: true,
  postContextRetentionDays: 0,
  // 0 = forever
  // Amnesty defaults
  forgivenessPeriodDays: 90,
  // 3 months
  // Last Word defaults
  lastWordMuteEnabled: true,
  // Mute during delay by default
  lastWordDelaySeconds: 60
  // 60 second delay by default
};
var DEFAULT_MASS_OPS_SETTINGS = {
  timeWindowMinutes: 5,
  minOperationCount: 10
};

// src/storage.ts
var SYNC_STORAGE_QUOTA_BYTES = 102400;
var SYNC_STORAGE_ITEM_QUOTA_BYTES = 8192;
var QUOTA_WARNING_THRESHOLD = 0.8;
async function checkStorageQuota() {
  try {
    const allData = await browser_default.storage.sync.get(null);
    const bytesUsed = new Blob([JSON.stringify(allData)]).size;
    const percentUsed = bytesUsed / SYNC_STORAGE_QUOTA_BYTES;
    return {
      bytesUsed,
      bytesTotal: SYNC_STORAGE_QUOTA_BYTES,
      percentUsed,
      isNearLimit: percentUsed >= QUOTA_WARNING_THRESHOLD,
      isAtLimit: percentUsed >= 0.95
    };
  } catch (error) {
    console.error("[ErgoBlock] Error checking storage quota:", error);
    return {
      bytesUsed: 0,
      bytesTotal: SYNC_STORAGE_QUOTA_BYTES,
      percentUsed: 0,
      isNearLimit: false,
      isAtLimit: false
    };
  }
}
var StorageQuotaError = class extends Error {
  constructor(message, quotaInfo) {
    super(message);
    this.quotaInfo = quotaInfo;
    this.name = "StorageQuotaError";
  }
};
async function safeSyncStorageWrite(key, value) {
  const dataSize = new Blob([JSON.stringify(value)]).size;
  if (dataSize > SYNC_STORAGE_ITEM_QUOTA_BYTES) {
    throw new StorageQuotaError(
      `Storage item too large: ${dataSize} bytes exceeds ${SYNC_STORAGE_ITEM_QUOTA_BYTES} byte limit`,
      await checkStorageQuota()
    );
  }
  const quota = await checkStorageQuota();
  if (quota.isAtLimit) {
    throw new StorageQuotaError(
      `Storage quota exceeded: ${Math.round(quota.percentUsed * 100)}% used. Please remove some temp blocks/mutes.`,
      quota
    );
  }
  if (quota.isNearLimit) {
    console.warn(`[ErgoBlock] Storage quota warning: ${Math.round(quota.percentUsed * 100)}% used`);
  }
  await browser_default.storage.sync.set({ [key]: value });
}
var STORAGE_KEYS = {
  TEMP_BLOCKS: "tempBlocks",
  TEMP_MUTES: "tempMutes",
  OPTIONS: "extensionOptions",
  ACTION_HISTORY: "actionHistory",
  LAST_TAB: "lastActiveTab",
  POST_CONTEXTS: "postContexts",
  // New keys for full manager
  PERMANENT_BLOCKS: "permanentBlocks",
  PERMANENT_MUTES: "permanentMutes",
  SYNC_STATE: "syncState",
  // Amnesty feature
  AMNESTY_REVIEWS: "amnestyReviews",
  // Blocklist audit feature
  BLOCKLIST_AUDIT_STATE: "blocklistAuditState",
  SUBSCRIBED_BLOCKLISTS: "subscribedBlocklists",
  SOCIAL_GRAPH: "socialGraph",
  BLOCKLIST_CONFLICTS: "blocklistConflicts",
  DISMISSED_CONFLICTS: "dismissedConflicts",
  // Repost filtering feature
  REPOST_FILTERED_USERS: "repostFilteredUsers",
  // Lightweight follows list (just handles, for repost filter feature)
  FOLLOWS_HANDLES: "followsHandles",
  // List audit feature
  LIST_AUDIT_REVIEWS: "listAuditReviews",
  // Mass operations detection feature
  MASS_OPS_SCAN_RESULT: "massOpsScanResult",
  MASS_OPS_SETTINGS: "massOpsSettings",
  MASS_OPS_DISMISSED_CLUSTERS: "massOpsDismissedClusters",
  // CAR download progress (for UI updates)
  CAR_DOWNLOAD_PROGRESS: "carDownloadProgress",
  // Pending delayed blocks (Last Word feature)
  PENDING_DELAYED_BLOCKS: "pendingDelayedBlocks"
};
var HISTORY_MAX_ENTRIES = 100;
var DEFAULT_DURATION_MS = 24 * 60 * 60 * 1e3;
async function getTempBlocks() {
  const result = await browser_default.storage.sync.get(STORAGE_KEYS.TEMP_BLOCKS);
  return result[STORAGE_KEYS.TEMP_BLOCKS] || {};
}
async function getTempMutes() {
  const result = await browser_default.storage.sync.get(STORAGE_KEYS.TEMP_MUTES);
  return result[STORAGE_KEYS.TEMP_MUTES] || {};
}
async function addTempBlock(did, handle, durationMs = DEFAULT_DURATION_MS, rkey) {
  if (!isValidDid(did)) {
    throw new Error(`Invalid DID format: ${did}`);
  }
  if (!isValidDuration(durationMs)) {
    throw new Error(`Invalid duration: ${durationMs}ms (must be positive and less than 1 year)`);
  }
  if (!handle || typeof handle !== "string" || handle.length === 0) {
    throw new Error("Handle is required");
  }
  const blocks = await getTempBlocks();
  blocks[did] = {
    handle,
    expiresAt: Date.now() + durationMs,
    createdAt: Date.now(),
    rkey
  };
  await safeSyncStorageWrite(STORAGE_KEYS.TEMP_BLOCKS, blocks);
  const notifyBackground = async (retries = 3) => {
    for (let attempt = 0; attempt < retries; attempt++) {
      try {
        await browser_default.runtime.sendMessage({
          type: "TEMP_BLOCK_ADDED",
          did,
          expiresAt: blocks[did].expiresAt
        });
        return;
      } catch (err) {
        if (attempt === retries - 1) {
          console.warn(
            "[ErgoBlock] Could not notify background after retries, alarm will be set on next wake:",
            err instanceof Error ? err.message : err
          );
        } else {
          await new Promise((resolve) => setTimeout(resolve, (attempt + 1) * 100));
        }
      }
    }
  };
  notifyBackground();
}
async function removeTempBlock(did) {
  const blocks = await getTempBlocks();
  delete blocks[did];
  await browser_default.storage.sync.set({ [STORAGE_KEYS.TEMP_BLOCKS]: blocks });
}
async function removeTempMute(did) {
  const mutes = await getTempMutes();
  delete mutes[did];
  await browser_default.storage.sync.set({ [STORAGE_KEYS.TEMP_MUTES]: mutes });
}
async function getOptions() {
  const result = await browser_default.storage.local.get(STORAGE_KEYS.OPTIONS);
  const stored = result[STORAGE_KEYS.OPTIONS];
  if (!stored) {
    return DEFAULT_OPTIONS;
  }
  return {
    ...DEFAULT_OPTIONS,
    ...stored
  };
}
async function getActionHistory() {
  const result = await browser_default.storage.local.get(STORAGE_KEYS.ACTION_HISTORY);
  const history = result[STORAGE_KEYS.ACTION_HISTORY] || [];
  return history;
}
async function addHistoryEntry(entry) {
  const entryWithId = {
    ...entry,
    id: entry.id || generateId("hist")
  };
  const history = await getActionHistory();
  history.unshift(entryWithId);
  const trimmed = history.slice(0, HISTORY_MAX_ENTRIES);
  await browser_default.storage.local.set({ [STORAGE_KEYS.ACTION_HISTORY]: trimmed });
}
var MAX_POST_CONTEXTS = 500;
async function getPostContexts() {
  const result = await browser_default.storage.local.get(STORAGE_KEYS.POST_CONTEXTS);
  return result[STORAGE_KEYS.POST_CONTEXTS] || [];
}
async function addPostContext(context) {
  const contexts = await getPostContexts();
  contexts.unshift(context);
  const trimmed = contexts.slice(0, MAX_POST_CONTEXTS);
  await browser_default.storage.local.set({ [STORAGE_KEYS.POST_CONTEXTS]: trimmed });
}
async function cleanupExpiredPostContexts() {
  const options = await getOptions();
  if (options.postContextRetentionDays <= 0) return;
  const contexts = await getPostContexts();
  const cutoff = Date.now() - options.postContextRetentionDays * 24 * 60 * 60 * 1e3;
  const filtered = contexts.filter((c) => c.timestamp > cutoff);
  if (filtered.length !== contexts.length) {
    await browser_default.storage.local.set({ [STORAGE_KEYS.POST_CONTEXTS]: filtered });
    console.log(
      `[ErgoBlock] Cleaned up ${contexts.length - filtered.length} expired post contexts`
    );
  }
}
async function getPermanentBlocks() {
  const result = await browser_default.storage.local.get(STORAGE_KEYS.PERMANENT_BLOCKS);
  return result[STORAGE_KEYS.PERMANENT_BLOCKS] || {};
}
async function setPermanentBlocks(blocks) {
  await browser_default.storage.local.set({ [STORAGE_KEYS.PERMANENT_BLOCKS]: blocks });
}
async function getPermanentMutes() {
  const result = await browser_default.storage.local.get(STORAGE_KEYS.PERMANENT_MUTES);
  return result[STORAGE_KEYS.PERMANENT_MUTES] || {};
}
async function setPermanentMutes(mutes) {
  await browser_default.storage.local.set({ [STORAGE_KEYS.PERMANENT_MUTES]: mutes });
}
async function removePermanentBlock(did) {
  const blocks = await getPermanentBlocks();
  delete blocks[did];
  await browser_default.storage.local.set({ [STORAGE_KEYS.PERMANENT_BLOCKS]: blocks });
}
var DEFAULT_SYNC_STATE = {
  lastBlockSync: 0,
  lastMuteSync: 0,
  syncInProgress: false
};
async function getSyncState() {
  const result = await browser_default.storage.local.get(STORAGE_KEYS.SYNC_STATE);
  return result[STORAGE_KEYS.SYNC_STATE] || DEFAULT_SYNC_STATE;
}
async function setSyncState(state) {
  await browser_default.storage.local.set({ [STORAGE_KEYS.SYNC_STATE]: state });
}
async function updateSyncState(update) {
  const current = await getSyncState();
  await setSyncState({ ...current, ...update });
}
async function getAmnestyReviews() {
  const localResult = await browser_default.storage.local.get(STORAGE_KEYS.AMNESTY_REVIEWS);
  if (localResult[STORAGE_KEYS.AMNESTY_REVIEWS]) {
    return localResult[STORAGE_KEYS.AMNESTY_REVIEWS];
  }
  const syncResult = await browser_default.storage.sync.get(STORAGE_KEYS.AMNESTY_REVIEWS);
  const syncReviews = syncResult[STORAGE_KEYS.AMNESTY_REVIEWS] || [];
  if (syncReviews.length > 0) {
    await browser_default.storage.local.set({ [STORAGE_KEYS.AMNESTY_REVIEWS]: syncReviews });
    await browser_default.storage.sync.remove(STORAGE_KEYS.AMNESTY_REVIEWS);
  }
  return syncReviews;
}
var DEFAULT_AUDIT_STATE = {
  lastSyncAt: 0,
  syncInProgress: false,
  followCount: 0,
  followerCount: 0,
  blocklistCount: 0,
  conflictCount: 0
};
async function getBlocklistAuditState() {
  const result = await browser_default.storage.local.get(STORAGE_KEYS.BLOCKLIST_AUDIT_STATE);
  return result[STORAGE_KEYS.BLOCKLIST_AUDIT_STATE] || DEFAULT_AUDIT_STATE;
}
async function setBlocklistAuditState(state) {
  await browser_default.storage.local.set({ [STORAGE_KEYS.BLOCKLIST_AUDIT_STATE]: state });
}
async function updateBlocklistAuditState(update) {
  const current = await getBlocklistAuditState();
  await setBlocklistAuditState({ ...current, ...update });
}
async function setSubscribedBlocklists(lists) {
  await browser_default.storage.local.set({ [STORAGE_KEYS.SUBSCRIBED_BLOCKLISTS]: lists });
}
async function getSocialGraph() {
  const result = await browser_default.storage.local.get(STORAGE_KEYS.SOCIAL_GRAPH);
  return result[STORAGE_KEYS.SOCIAL_GRAPH] || {
    follows: [],
    followers: [],
    syncedAt: 0
  };
}
async function getFollowsHandles() {
  const result = await browser_default.storage.local.get(STORAGE_KEYS.FOLLOWS_HANDLES);
  return result[STORAGE_KEYS.FOLLOWS_HANDLES] || {
    handles: [],
    syncedAt: 0
  };
}
async function setFollowsHandles(handles, syncedAt) {
  const data = {
    handles: handles.map((h) => h.toLowerCase()),
    syncedAt
  };
  await browser_default.storage.local.set({ [STORAGE_KEYS.FOLLOWS_HANDLES]: data });
}
async function setBlocklistConflicts(conflicts) {
  await browser_default.storage.local.set({ [STORAGE_KEYS.BLOCKLIST_CONFLICTS]: conflicts });
}
async function getDismissedConflicts() {
  const result = await browser_default.storage.local.get(STORAGE_KEYS.DISMISSED_CONFLICTS);
  const dismissed = result[STORAGE_KEYS.DISMISSED_CONFLICTS] || [];
  return new Set(dismissed);
}
async function saveMassOpsScanResult(scanResult) {
  await browser_default.storage.local.set({ [STORAGE_KEYS.MASS_OPS_SCAN_RESULT]: scanResult });
}
async function getMassOpsSettings() {
  const result = await browser_default.storage.sync.get(STORAGE_KEYS.MASS_OPS_SETTINGS);
  const stored = result[STORAGE_KEYS.MASS_OPS_SETTINGS];
  return stored || DEFAULT_MASS_OPS_SETTINGS;
}
async function setMassOpsSettings(settings) {
  await browser_default.storage.sync.set({ [STORAGE_KEYS.MASS_OPS_SETTINGS]: settings });
}
async function getDismissedMassOpsClusters() {
  const result = await browser_default.storage.local.get(STORAGE_KEYS.MASS_OPS_DISMISSED_CLUSTERS);
  return result[STORAGE_KEYS.MASS_OPS_DISMISSED_CLUSTERS] || [];
}
async function dismissMassOpsCluster(cluster) {
  const dismissed = await getDismissedMassOpsClusters();
  dismissed.push(cluster);
  await browser_default.storage.local.set({ [STORAGE_KEYS.MASS_OPS_DISMISSED_CLUSTERS]: dismissed });
}
function isClusterDismissed(cluster, dismissedClusters) {
  return dismissedClusters.some(
    (d) => d.type === cluster.type && d.startTime === cluster.startTime && d.endTime === cluster.endTime && d.count === cluster.count
  );
}
async function setCarDownloadProgress(progress) {
  if (progress === null) {
    await browser_default.storage.local.remove(STORAGE_KEYS.CAR_DOWNLOAD_PROGRESS);
  } else {
    await browser_default.storage.local.set({ [STORAGE_KEYS.CAR_DOWNLOAD_PROGRESS]: progress });
  }
}
async function clearCarDownloadProgress() {
  await browser_default.storage.local.remove(STORAGE_KEYS.CAR_DOWNLOAD_PROGRESS);
}
async function getPendingDelayedBlocks() {
  const result = await browser_default.storage.local.get(STORAGE_KEYS.PENDING_DELAYED_BLOCKS);
  return result[STORAGE_KEYS.PENDING_DELAYED_BLOCKS] || {};
}
async function addPendingDelayedBlock(entry) {
  const blocks = await getPendingDelayedBlocks();
  blocks[entry.did] = entry;
  await browser_default.storage.local.set({ [STORAGE_KEYS.PENDING_DELAYED_BLOCKS]: blocks });
}
async function removePendingDelayedBlock(did) {
  const blocks = await getPendingDelayedBlocks();
  delete blocks[did];
  await browser_default.storage.local.set({ [STORAGE_KEYS.PENDING_DELAYED_BLOCKS]: blocks });
}
async function getPendingDelayedBlock(did) {
  const blocks = await getPendingDelayedBlocks();
  return blocks[did] || null;
}
var PENDING_ROLLBACKS_KEY = "pendingRollbacks";
var MAX_ROLLBACK_ATTEMPTS = 5;
async function getPendingRollbacks() {
  const result = await browser_default.storage.local.get(PENDING_ROLLBACKS_KEY);
  return result[PENDING_ROLLBACKS_KEY] || [];
}
async function updatePendingRollback(id, update) {
  const rollbacks = await getPendingRollbacks();
  const index = rollbacks.findIndex((r) => r.id === id);
  if (index !== -1) {
    rollbacks[index] = { ...rollbacks[index], ...update };
    await browser_default.storage.local.set({ [PENDING_ROLLBACKS_KEY]: rollbacks });
  }
}
async function removePendingRollback(id) {
  const rollbacks = await getPendingRollbacks();
  const filtered = rollbacks.filter((r) => r.id !== id);
  await browser_default.storage.local.set({ [PENDING_ROLLBACKS_KEY]: filtered });
}
async function getProcessableRollbacks() {
  const rollbacks = await getPendingRollbacks();
  const now = Date.now();
  const MIN_RETRY_INTERVAL = 6e4;
  return rollbacks.filter((r) => {
    if (r.attempts >= MAX_ROLLBACK_ATTEMPTS) return false;
    const backoffMs = MIN_RETRY_INTERVAL * Math.pow(2, r.attempts);
    if (now - r.lastAttempt < backoffMs) return false;
    return true;
  });
}
async function cleanupOldRollbacks() {
  const rollbacks = await getPendingRollbacks();
  const now = Date.now();
  const MAX_AGE_MS = 7 * 24 * 60 * 60 * 1e3;
  const toKeep = rollbacks.filter((r) => {
    if (now - r.createdAt < MAX_AGE_MS) return true;
    return r.attempts < MAX_ROLLBACK_ATTEMPTS;
  });
  const removed = rollbacks.length - toKeep.length;
  if (removed > 0) {
    await browser_default.storage.local.set({ [PENDING_ROLLBACKS_KEY]: toKeep });
  }
  return removed;
}

// node_modules/@atcute/uint8array/dist/index.js
var textEncoder = new TextEncoder();
var textDecoder = new TextDecoder();
var subtle = crypto.subtle;
var alloc = (size) => {
  return new Uint8Array(size);
};
var allocUnsafe = alloc;
var _fromCharCode = String.fromCharCode;
var _shortString = (from, p, length) => {
  if (length < 4) {
    if (length < 2) {
      if (length === 0)
        return "";
      const a3 = from[p];
      if (a3 & 128)
        return null;
      return _fromCharCode(a3);
    }
    const a2 = from[p];
    const b2 = from[p + 1];
    if ((a2 | b2) & 128)
      return null;
    if (length === 2)
      return _fromCharCode(a2, b2);
    const c2 = from[p + 2];
    if (c2 & 128)
      return null;
    return _fromCharCode(a2, b2, c2);
  }
  const a = from[p];
  const b = from[p + 1];
  const c = from[p + 2];
  const d = from[p + 3];
  if ((a | b | c | d) & 128)
    return null;
  if (length < 8) {
    if (length === 4)
      return _fromCharCode(a, b, c, d);
    const e2 = from[p + 4];
    if (e2 & 128)
      return null;
    if (length === 5)
      return _fromCharCode(a, b, c, d, e2);
    const f2 = from[p + 5];
    if (f2 & 128)
      return null;
    if (length === 6)
      return _fromCharCode(a, b, c, d, e2, f2);
    const g2 = from[p + 6];
    if (g2 & 128)
      return null;
    return _fromCharCode(a, b, c, d, e2, f2, g2);
  }
  const e = from[p + 4];
  const f = from[p + 5];
  const g = from[p + 6];
  const h = from[p + 7];
  if ((e | f | g | h) & 128)
    return null;
  if (length < 12) {
    if (length === 8)
      return _fromCharCode(a, b, c, d, e, f, g, h);
    const i2 = from[p + 8];
    if (i2 & 128)
      return null;
    if (length === 9)
      return _fromCharCode(a, b, c, d, e, f, g, h, i2);
    const j2 = from[p + 9];
    if (j2 & 128)
      return null;
    if (length === 10)
      return _fromCharCode(a, b, c, d, e, f, g, h, i2, j2);
    const k2 = from[p + 10];
    if (k2 & 128)
      return null;
    return _fromCharCode(a, b, c, d, e, f, g, h, i2, j2, k2);
  }
  const i = from[p + 8];
  const j = from[p + 9];
  const k = from[p + 10];
  const l = from[p + 11];
  if ((i | j | k | l) & 128)
    return null;
  if (length === 12)
    return _fromCharCode(a, b, c, d, e, f, g, h, i, j, k, l);
  const m = from[p + 12];
  if (m & 128)
    return null;
  if (length === 13)
    return _fromCharCode(a, b, c, d, e, f, g, h, i, j, k, l, m);
  const n = from[p + 13];
  if (n & 128)
    return null;
  if (length === 14)
    return _fromCharCode(a, b, c, d, e, f, g, h, i, j, k, l, m, n);
  const o = from[p + 14];
  if (o & 128)
    return null;
  return _fromCharCode(a, b, c, d, e, f, g, h, i, j, k, l, m, n, o);
};
var decodeUtf8From = (from, offset = 0, length = from.length) => {
  if (length <= 15) {
    const result = _shortString(from, offset, length);
    if (result !== null)
      return result;
  }
  return textDecoder.decode(from.subarray(offset, offset + length));
};

// node_modules/@atcute/multibase/dist/utils.js
var createRfc4648Encode = (alphabet, bitsPerChar, pad) => {
  return (bytes) => {
    const mask = (1 << bitsPerChar) - 1;
    let str = "";
    let bits = 0;
    let buffer = 0;
    for (let i = 0; i < bytes.length; ++i) {
      buffer = buffer << 8 | bytes[i];
      bits += 8;
      while (bits > bitsPerChar) {
        bits -= bitsPerChar;
        str += alphabet[mask & buffer >> bits];
      }
    }
    if (bits !== 0) {
      str += alphabet[mask & buffer << bitsPerChar - bits];
    }
    if (pad) {
      while ((str.length * bitsPerChar & 7) !== 0) {
        str += "=";
      }
    }
    return str;
  };
};
var createRfc4648Decode = (alphabet, bitsPerChar, pad) => {
  const codes = {};
  for (let i = 0; i < alphabet.length; ++i) {
    codes[alphabet[i]] = i;
  }
  return (str) => {
    let end = str.length;
    while (pad && str[end - 1] === "=") {
      --end;
    }
    const bytes = allocUnsafe(end * bitsPerChar / 8 | 0);
    let bits = 0;
    let buffer = 0;
    let written = 0;
    for (let i = 0; i < end; ++i) {
      const value = codes[str[i]];
      if (value === void 0) {
        throw new SyntaxError(`invalid base string`);
      }
      buffer = buffer << bitsPerChar | value;
      bits += bitsPerChar;
      if (bits >= 8) {
        bits -= 8;
        bytes[written++] = 255 & buffer >> bits;
      }
    }
    if (bits >= bitsPerChar || (255 & buffer << 8 - bits) !== 0) {
      throw new SyntaxError("unexpected end of data");
    }
    return bytes;
  };
};

// node_modules/@atcute/multibase/dist/bases/base64-web-native.js
var fromBase64 = (str) => {
  return Uint8Array.fromBase64(str, { alphabet: "base64", lastChunkHandling: "loose" });
};
var toBase64 = (bytes) => {
  return bytes.toBase64({ alphabet: "base64", omitPadding: true });
};

// node_modules/@atcute/multibase/dist/bases/base64-web-polyfill.js
var BASE64_CHARSET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
var fromBase642 = /* @__PURE__ */ createRfc4648Decode(BASE64_CHARSET, 6, false);
var toBase642 = /* @__PURE__ */ createRfc4648Encode(BASE64_CHARSET, 6, false);

// node_modules/@atcute/multibase/dist/bases/base64-web.js
var HAS_NATIVE_SUPPORT = "fromBase64" in Uint8Array;
var fromBase643 = !HAS_NATIVE_SUPPORT ? fromBase642 : fromBase64;
var toBase643 = !HAS_NATIVE_SUPPORT ? toBase642 : toBase64;

// node_modules/@atcute/multibase/dist/bases/base32.js
var BASE32_CHARSET = "abcdefghijklmnopqrstuvwxyz234567";
var toBase32 = /* @__PURE__ */ createRfc4648Encode(BASE32_CHARSET, 5, false);

// node_modules/@atcute/cid/dist/codec.js
var CID_VERSION = 1;
var HASH_SHA256 = 18;
var CODEC_RAW = 85;
var CODEC_DCBOR = 113;
var CID_STRINGIFY_CACHE = /* @__PURE__ */ new WeakMap();
var decodeFirst = (bytes) => {
  const length = bytes.length;
  if (length < 4) {
    throw new RangeError(`cid too short`);
  }
  const version = bytes[0];
  const codec = bytes[1];
  const digestType = bytes[2];
  const digestSize = bytes[3];
  if (version !== CID_VERSION) {
    throw new RangeError(`incorrect cid version (got v${version})`);
  }
  if (codec !== CODEC_DCBOR && codec !== CODEC_RAW) {
    throw new RangeError(`incorrect cid codec (got 0x${codec.toString(16)})`);
  }
  if (digestType !== HASH_SHA256) {
    throw new RangeError(`incorrect cid digest codec (got 0x${digestType.toString(16)})`);
  }
  if (digestSize !== 32 && digestSize !== 0) {
    throw new RangeError(`incorrect cid digest size (got ${digestSize})`);
  }
  if (length < 4 + digestSize) {
    throw new RangeError(`cid too short`);
  }
  const cid = {
    version: CID_VERSION,
    codec,
    digest: {
      codec: digestType,
      contents: bytes.subarray(4, 4 + digestSize)
    },
    bytes: bytes.subarray(0, 4 + digestSize)
  };
  return [cid, bytes.subarray(4 + digestSize)];
};
var decode = (bytes) => {
  const [cid, remainder] = decodeFirst(bytes);
  if (remainder.length !== 0) {
    throw new RangeError(`cid bytes includes remainder`);
  }
  return cid;
};
var toString = (cid) => {
  let str = CID_STRINGIFY_CACHE.get(cid);
  if (str === void 0) {
    str = `b${toBase32(cid.bytes)}`;
    CID_STRINGIFY_CACHE.set(cid, str);
  }
  return str;
};
var fromBinary = (input) => {
  if (input.length !== 37 && input.length !== 5) {
    throw new RangeError(`cid bytes too short`);
  }
  if (input[0] !== 0) {
    throw new SyntaxError(`incorrect binary cid`);
  }
  const bytes = input.subarray(1);
  return decode(bytes);
};

// node_modules/@atcute/cid/dist/cid-link.js
var CID_LINK_SYMBOL = /* @__PURE__ */ Symbol.for("@atcute/cid-link-wrapper");
var CIDLINK_STRINGIFY_CACHE = /* @__PURE__ */ new WeakMap();
var CidLinkWrapper = class {
  /** @internal */
  [CID_LINK_SYMBOL] = true;
  bytes;
  constructor(bytes) {
    this.bytes = bytes;
  }
  get $link() {
    let str = CIDLINK_STRINGIFY_CACHE.get(this);
    if (str === void 0) {
      str = `b${toBase32(this.bytes)}`;
      CIDLINK_STRINGIFY_CACHE.set(this, str);
    }
    return str;
  }
  toJSON() {
    return { $link: this.$link };
  }
};
var isCidLink = (value) => {
  const val = value;
  return val instanceof CidLinkWrapper || val !== null && typeof val === "object" && typeof val.$link === "string";
};

// node_modules/@atcute/cbor/dist/bytes.js
var BYTES_SYMBOL = /* @__PURE__ */ Symbol.for("@atcute/bytes-wrapper");
var BytesWrapper = class {
  buf;
  /** @internal */
  [BYTES_SYMBOL] = true;
  constructor(buf) {
    this.buf = buf;
  }
  get $bytes() {
    return toBase643(this.buf);
  }
  toJSON() {
    return { $bytes: this.$bytes };
  }
};
var isBytes = (value) => {
  const val = value;
  return val instanceof BytesWrapper || val !== null && typeof val === "object" && typeof val.$bytes === "string";
};
var toBytes = (buf) => {
  return new BytesWrapper(buf);
};
var fromBytes = (bytes) => {
  if (bytes instanceof BytesWrapper) {
    return bytes.buf;
  }
  return fromBase643(bytes.$bytes);
};

// node_modules/@atcute/cbor/dist/decode.js
var readArgument = (state, info) => {
  if (info < 24) {
    return info;
  }
  let arg;
  switch (info) {
    case 24: {
      arg = readUint8(state);
      if (arg < 24) {
        throw new TypeError(`non-canonical argument encoding`);
      }
      break;
    }
    case 25: {
      arg = readUint16(state);
      if (arg < 256) {
        throw new TypeError(`non-canonical argument encoding`);
      }
      break;
    }
    case 26: {
      arg = readUint32(state);
      if (arg < 65536) {
        throw new TypeError(`non-canonical argument encoding`);
      }
      break;
    }
    case 27: {
      arg = readUint53(state);
      if (arg < 4294967296) {
        throw new TypeError(`non-canonical argument encoding`);
      }
      break;
    }
    default: {
      throw new Error(`invalid argument encoding; got ${info}`);
    }
  }
  return arg;
};
var readFloat64 = (state) => {
  const view = state.v ??= new DataView(state.b.buffer, state.b.byteOffset, state.b.byteLength);
  const value = view.getFloat64(state.p);
  state.p += 8;
  return value;
};
var readUint8 = (state) => {
  return state.b[state.p++];
};
var readUint16 = (state) => {
  let pos = state.p;
  const buf = state.b;
  const value = buf[pos++] << 8 | buf[pos++];
  state.p = pos;
  return value;
};
var readUint32 = (state) => {
  let pos = state.p;
  const buf = state.b;
  const value = (buf[pos++] << 24 | buf[pos++] << 16 | buf[pos++] << 8 | buf[pos++]) >>> 0;
  state.p = pos;
  return value;
};
var readUint53 = (state) => {
  const hi = readUint32(state);
  const lo = readUint32(state);
  if (hi > 2097151) {
    throw new RangeError(`can't decode integers beyond safe integer range`);
  }
  return hi * 2 ** 32 + lo;
};
var readString = (state, length) => {
  const string = decodeUtf8From(state.b, state.p, length);
  state.p += length;
  return string;
};
var readBytes = (state, length) => {
  const slice = state.b.subarray(state.p, state.p += length);
  return toBytes(slice);
};
var readCid = (state, length) => {
  const cid = fromBinary(state.b.subarray(state.p, state.p += length));
  return new CidLinkWrapper(cid.bytes);
};
var compareKeys = (a, b) => {
  return a.length - b.length || (a < b ? -1 : a > b ? 1 : 0);
};
var decodeStringKey = (state) => {
  const prelude = readUint8(state);
  const type = prelude >> 5;
  if (type !== 3) {
    throw new TypeError(`expected map to only have string keys; got type ${type}`);
  }
  const info = prelude & 31;
  const length = readArgument(state, info);
  return readString(state, length);
};
var decodeFirst2 = (buf) => {
  const len = buf.length;
  const state = {
    b: buf,
    v: null,
    p: 0
  };
  let stack = null;
  let value;
  jump: while (state.p < len) {
    const prelude = readUint8(state);
    const type = prelude >> 5;
    const info = prelude & 31;
    const arg = type === 7 ? 0 : readArgument(state, info);
    switch (type) {
      case 0: {
        value = arg;
        break;
      }
      case 1: {
        value = -1 - arg;
        break;
      }
      case 2: {
        value = readBytes(state, arg);
        break;
      }
      case 3: {
        value = readString(state, arg);
        break;
      }
      case 4: {
        if (arg > 0) {
          stack = { t: 1, c: value = new Array(arg), k: null, r: arg, n: stack };
          continue jump;
        }
        value = [];
        break;
      }
      case 5: {
        value = {};
        if (arg > 0) {
          const first = decodeStringKey(state);
          stack = { t: 0, c: value, k: first, r: arg, n: stack };
          continue jump;
        }
        break;
      }
      case 6: {
        switch (arg) {
          case 42: {
            const prelude2 = readUint8(state);
            const type2 = prelude2 >> 5;
            const info2 = prelude2 & 31;
            if (type2 !== 2) {
              throw new TypeError(`expected cid-link to be type 2 (bytes); got type ${type2}`);
            }
            const len2 = readArgument(state, info2);
            value = readCid(state, len2);
            break;
          }
          default: {
            throw new TypeError(`unsupported tag; got ${arg}`);
          }
        }
        break;
      }
      case 7: {
        switch (info) {
          case 20:
          case 21: {
            value = info === 21;
            break;
          }
          case 22: {
            value = null;
            break;
          }
          case 27: {
            value = readFloat64(state);
            break;
          }
          default: {
            throw new Error(`invalid simple value; got ${info}`);
          }
        }
        break;
      }
      default: {
        throw new TypeError(`invalid type; got ${type}`);
      }
    }
    while (stack !== null) {
      switch (stack.t) {
        case 0: {
          const obj = stack.c;
          const key = stack.k;
          if (key === "__proto__") {
            Object.defineProperty(obj, key, { enumerable: true, configurable: true, writable: true });
          }
          obj[key] = value;
          break;
        }
        case 1: {
          const arr = stack.c;
          const index = arr.length - stack.r;
          arr[index] = value;
          break;
        }
      }
      if (--stack.r) {
        if (!stack.t) {
          const prevKey = stack.k;
          stack.k = decodeStringKey(state);
          if (compareKeys(stack.k, prevKey) <= 0) {
            throw new TypeError(`map keys are not in canonical order or contain duplicates`);
          }
        }
        continue jump;
      }
      value = stack.c;
      stack = stack.n;
    }
    break;
  }
  return [value, buf.subarray(state.p)];
};
var decode2 = (buf) => {
  const [value, remainder] = decodeFirst2(buf);
  if (remainder.length !== 0) {
    throw new Error(`decoded value contains remainder`);
  }
  return value;
};

// node_modules/@atcute/repo/dist/types.js
var RepoEntry = class {
  collection;
  rkey;
  cid;
  carEntry;
  /** @internal */
  constructor(collection, rkey, cid, carEntry) {
    this.collection = collection;
    this.rkey = rkey;
    this.cid = cid;
    this.carEntry = carEntry;
  }
  /**
   * raw contents of this record
   */
  get bytes() {
    return this.carEntry.bytes;
  }
  /**
   * decoded contents of this record
   */
  get record() {
    return decode2(this.bytes);
  }
};
var isCommit = (value) => {
  if (value === null || typeof value !== "object") {
    return false;
  }
  const obj = value;
  return obj.version === 3 && typeof obj.did === "string" && isCidLink(obj.data) && typeof obj.rev === "string" && (obj.prev === null || isCidLink(obj.prev)) && isBytes(obj.sig);
};

// node_modules/@atcute/varint/dist/index.js
var MSB = 128;
var REST = 127;
var MSBALL = ~REST;
var INT = 2 ** 31;
var N1 = 2 ** 7;
var N2 = 2 ** 14;
var N3 = 2 ** 21;
var N4 = 2 ** 28;
var N5 = 2 ** 35;
var N6 = 2 ** 42;
var N7 = 2 ** 49;
var N8 = 2 ** 56;
var N9 = 2 ** 63;
var decode3 = (buf, offset = 0) => {
  let l = buf.length;
  let res = 0;
  let shift = 0;
  let counter = offset;
  let b;
  do {
    if (counter >= l) {
      throw new RangeError("could not decode varint");
    }
    b = buf[counter++];
    res += shift < 28 ? (b & REST) << shift : (b & REST) * Math.pow(2, shift);
    shift += 7;
  } while (b >= MSB);
  return [res, counter - offset];
};

// node_modules/@atcute/car/dist/types.js
var isCarV1Header = (value) => {
  if (value === null || typeof value !== "object") {
    return false;
  }
  const { version, roots } = value;
  return version === 1 && Array.isArray(roots) && roots.every((root) => root instanceof CidLinkWrapper);
};

// node_modules/@atcute/car/dist/reader.js
var fromUint8Array = (buffer) => {
  const reader = createUint8Reader(buffer);
  const header = readHeader(reader);
  return {
    header,
    roots: header.data.roots,
    *iterate() {
      while (reader.upto(8 + 36).length > 0) {
        const entryStart = reader.pos;
        const entrySize = readVarint(reader, 8);
        const cidStart = reader.pos;
        const cid = readCid2(reader);
        const bytesStart = reader.pos;
        const bytesSize = entrySize - (bytesStart - cidStart);
        const bytes = reader.exactly(bytesSize, true);
        const cidEnd = bytesStart;
        const bytesEnd = reader.pos;
        const entryEnd = bytesEnd;
        yield {
          cid,
          bytes,
          entryStart,
          entryEnd,
          cidStart,
          cidEnd,
          bytesStart,
          bytesEnd
        };
      }
    },
    [Symbol.iterator]() {
      return this.iterate();
    }
  };
};
var createUint8Reader = (buf) => {
  let pos = 0;
  return {
    get pos() {
      return pos;
    },
    seek(size) {
      if (size > buf.length - pos) {
        throw new RangeError("unexpected end of data");
      }
      pos += size;
    },
    upto(size) {
      return buf.subarray(pos, pos + size);
    },
    exactly(size, seek) {
      if (size > buf.length - pos) {
        throw new RangeError("unexpected end of data");
      }
      const slice = buf.subarray(pos, pos + size);
      if (seek) {
        pos += size;
      }
      return slice;
    }
  };
};
var readVarint = (reader, size) => {
  const buf = reader.upto(size);
  if (buf.length === 0) {
    throw new RangeError(`unexpected end of data`);
  }
  const [int, read] = decode3(buf);
  reader.seek(read);
  return int;
};
var readHeader = (reader) => {
  const headerStart = reader.pos;
  const length = readVarint(reader, 8);
  if (length === 0) {
    throw new RangeError(`invalid car header; length=0`);
  }
  const dataStart = reader.pos;
  const rawHeader = reader.exactly(length, true);
  const data = decode2(rawHeader);
  if (!isCarV1Header(data)) {
    throw new TypeError(`expected a car v1 archive`);
  }
  const dataEnd = reader.pos;
  const headerEnd = dataEnd;
  return { data, headerStart, headerEnd, dataStart, dataEnd };
};
var readCid2 = (reader) => {
  const head = reader.exactly(4, false);
  const version = head[0];
  const codec = head[1];
  const digestType = head[2];
  const digestSize = head[3];
  if (version !== CID_VERSION) {
    throw new RangeError(`incorrect cid version (got v${version})`);
  }
  if (codec !== CODEC_DCBOR && codec !== CODEC_RAW) {
    throw new RangeError(`incorrect cid codec (got 0x${codec.toString(16)})`);
  }
  if (digestType !== HASH_SHA256) {
    throw new RangeError(`incorrect cid digest type (got 0x${digestType.toString(16)})`);
  }
  if (digestSize !== 32 && digestSize !== 0) {
    throw new RangeError(`incorrect cid digest size (got ${digestSize})`);
  }
  const bytes = reader.exactly(4 + digestSize, true);
  const digest = bytes.subarray(4, 4 + digestSize);
  const cid = {
    version,
    codec,
    digest: {
      codec: digestType,
      contents: digest
    },
    bytes
  };
  return cid;
};

// node_modules/@atcute/mst/dist/types.js
var isTreeEntry = (value) => {
  if (value === null || typeof value !== "object") {
    return false;
  }
  const obj = value;
  return typeof obj.p === "number" && isBytes(obj.k) && isCidLink(obj.v) && (obj.t === null || isCidLink(obj.t));
};
var isNodeData = (value) => {
  if (value === null || typeof value !== "object") {
    return false;
  }
  const obj = value;
  return (obj.l === null || isCidLink(obj.l)) && Array.isArray(obj.e) && obj.e.every(isTreeEntry);
};

// node_modules/@atcute/repo/dist/utils.js
var assert = (condition, message) => {
  if (!condition) {
    throw new Error(message);
  }
};

// node_modules/@atcute/repo/dist/reader.js
function* fromUint8Array2(buf) {
  const car = fromUint8Array(buf);
  const roots = car.roots;
  assert(roots.length === 1, `expected only 1 root in the car archive; got=${roots.length}`);
  const map = /* @__PURE__ */ new Map();
  for (const entry of car) {
    map.set(toString(entry.cid), entry);
  }
  assert(map.size >= 2, `expected at least 2 blocks in the archive; got=${map.size}`);
  const commit = readEntry(map, roots[0], isCommit);
  for (const { key, cid } of walkMstEntries(map, commit.data)) {
    const [collection, rkey] = key.split("/");
    const carEntry = map.get(cid.$link);
    assert(carEntry != null, `cid not found in blockmap; cid=${cid}`);
    yield new RepoEntry(collection, rkey, cid, carEntry);
  }
}
var readEntry = (map, link, validate) => {
  const cid = link.$link;
  const entry = map.get(cid);
  assert(entry != null, `cid not found in blockmap; cid=${cid}`);
  const data = decode2(entry.bytes);
  assert(validate(data), `validation failed for cid=${cid}`);
  return data;
};
function* walkMstEntries(map, pointer) {
  const data = readEntry(map, pointer, isNodeData);
  const entries = data.e;
  let lastKey = "";
  if (data.l !== null) {
    yield* walkMstEntries(map, data.l);
  }
  for (let i = 0, il = entries.length; i < il; i++) {
    const entry = entries[i];
    const key_str = decodeUtf8From(fromBytes(entry.k));
    const key = lastKey.slice(0, entry.p) + key_str;
    lastKey = key;
    yield { key, cid: entry.v };
    if (entry.t !== null) {
      yield* walkMstEntries(map, entry.t);
    }
  }
}

// src/carRepo.ts
var BSKY_RELAY = "https://bsky.network";
var CAR_DOWNLOAD_TIMEOUT_MS = 12e4;
function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
async function downloadCarFile(did, pdsUrl, onProgress, timeoutMs = CAR_DOWNLOAD_TIMEOUT_MS) {
  onProgress?.("Downloading repository...");
  const controller = new AbortController();
  const timeoutId = setTimeout(() => {
    controller.abort();
    onProgress?.("Download timed out");
  }, timeoutMs);
  try {
    if (pdsUrl) {
      try {
        const response = await fetch(
          `${pdsUrl}/xrpc/com.atproto.sync.getRepo?did=${encodeURIComponent(did)}`,
          { signal: controller.signal }
        );
        if (response.ok) {
          return await streamResponseToUint8Array(response, onProgress, controller.signal);
        }
        console.warn(`[ErgoBlock CAR] PDS fetch failed: ${response.status}, trying relay`);
      } catch (error) {
        if (error && typeof error === "object" && error.name === "AbortError") {
          throw new Error(`CAR download timed out after ${timeoutMs}ms`);
        }
        console.warn(`[ErgoBlock CAR] PDS fetch error, trying relay:`, error);
      }
    }
    const relayResponse = await fetch(
      `${BSKY_RELAY}/xrpc/com.atproto.sync.getRepo?did=${encodeURIComponent(did)}`,
      { signal: controller.signal }
    );
    if (!relayResponse.ok) {
      throw new Error(`Failed to download repo: ${relayResponse.status}`);
    }
    return await streamResponseToUint8Array(relayResponse, onProgress, controller.signal);
  } catch (error) {
    if (error && typeof error === "object" && error.name === "AbortError") {
      throw new Error(`CAR download timed out after ${timeoutMs}ms`);
    }
    throw error;
  } finally {
    clearTimeout(timeoutId);
  }
}
async function streamResponseToUint8Array(response, onProgress, abortSignal) {
  const contentLength = response.headers.get("content-length");
  const totalBytes = contentLength ? parseInt(contentLength, 10) : null;
  const reader = response.body?.getReader();
  if (!reader) {
    throw new Error("Failed to get response reader");
  }
  const chunks = [];
  let receivedBytes = 0;
  try {
    while (true) {
      if (abortSignal?.aborted) {
        reader.cancel();
        throw new Error("Download aborted");
      }
      const { done, value } = await reader.read();
      if (done) break;
      chunks.push(value);
      receivedBytes += value.length;
      if (totalBytes) {
        const percent = Math.round(receivedBytes / totalBytes * 100);
        onProgress?.(
          `Downloading... ${formatBytes(receivedBytes)} / ${formatBytes(totalBytes)} (${percent}%)`
        );
      } else {
        onProgress?.(`Downloading... ${formatBytes(receivedBytes)}`);
      }
    }
  } catch (error) {
    reader.cancel();
    throw error;
  }
  const result = new Uint8Array(receivedBytes);
  let offset = 0;
  for (const chunk of chunks) {
    result.set(chunk, offset);
    offset += chunk.length;
  }
  return result;
}
function parseCarForBlocks(carData) {
  const repo = fromUint8Array2(carData);
  const blocks = [];
  for (const entry of repo) {
    if (entry.collection !== "app.bsky.graph.block") {
      continue;
    }
    try {
      const record = decode2(entry.bytes);
      if (record.$type === "app.bsky.graph.block") {
        const block = record;
        if (block.subject) {
          blocks.push(block.subject);
        }
      }
    } catch (error) {
      console.warn("[ErgoBlock CAR] Failed to decode block entry:", error);
    }
  }
  return blocks;
}
function parseCarForLists(carData, creatorDid, targetListUris) {
  const repo = fromUint8Array2(carData);
  const listMetadata = {};
  const listItems = {};
  for (const entry of repo) {
    try {
      if (entry.collection === "app.bsky.graph.list") {
        const record = decode2(entry.bytes);
        if (record.$type === "app.bsky.graph.list") {
          const list = record;
          const listUri = `at://${creatorDid}/app.bsky.graph.list/${entry.rkey}`;
          if (targetListUris && !targetListUris.has(listUri)) {
            continue;
          }
          listMetadata[listUri] = {
            name: list.name,
            description: list.description,
            purpose: list.purpose,
            createdAt: new Date(list.createdAt).getTime(),
            rkey: entry.rkey
          };
          listItems[listUri] = [];
        }
      } else if (entry.collection === "app.bsky.graph.listitem") {
        const record = decode2(entry.bytes);
        if (record.$type === "app.bsky.graph.listitem") {
          const item = record;
          if (targetListUris && !targetListUris.has(item.list)) {
            continue;
          }
          if (!listItems[item.list]) {
            listItems[item.list] = [];
          }
          listItems[item.list].push(item.subject);
        }
      }
    } catch (error) {
      console.warn("[ErgoBlock CAR] Failed to decode list entry:", error);
    }
  }
  const lists = {};
  for (const [uri, metadata] of Object.entries(listMetadata)) {
    lists[uri] = {
      uri,
      name: metadata.name,
      description: metadata.description,
      purpose: metadata.purpose,
      createdAt: metadata.createdAt,
      members: listItems[uri] || []
    };
  }
  for (const [uri, members] of Object.entries(listItems)) {
    if (!lists[uri] && members.length > 0) {
      lists[uri] = {
        uri,
        name: "Unknown List",
        purpose: "app.bsky.graph.defs#curatelist",
        createdAt: 0,
        members
      };
    }
  }
  return { lists, creatorDid };
}
function parseCarForListsWithTimestamps(carData, creatorDid, targetListUris) {
  const repo = fromUint8Array2(carData);
  const listMetadata = {};
  const listItems = {};
  for (const entry of repo) {
    try {
      if (entry.collection === "app.bsky.graph.list") {
        const record = decode2(entry.bytes);
        if (record.$type === "app.bsky.graph.list") {
          const list = record;
          const listUri = `at://${creatorDid}/app.bsky.graph.list/${entry.rkey}`;
          if (targetListUris && !targetListUris.has(listUri)) {
            continue;
          }
          listMetadata[listUri] = {
            name: list.name,
            description: list.description,
            rkey: entry.rkey
          };
          listItems[listUri] = [];
        }
      } else if (entry.collection === "app.bsky.graph.listitem") {
        const record = decode2(entry.bytes);
        if (record.$type === "app.bsky.graph.listitem") {
          const item = record;
          if (targetListUris && !targetListUris.has(item.list)) {
            continue;
          }
          if (!listItems[item.list]) {
            listItems[item.list] = [];
          }
          listItems[item.list].push({
            did: item.subject,
            addedAt: new Date(item.createdAt).getTime(),
            rkey: entry.rkey
          });
        }
      }
    } catch (error) {
      console.warn("[ErgoBlock CAR] Failed to decode list entry:", error);
    }
  }
  const lists = {};
  for (const [uri, metadata] of Object.entries(listMetadata)) {
    lists[uri] = {
      uri,
      name: metadata.name,
      description: metadata.description,
      members: listItems[uri] || []
    };
  }
  for (const [uri, members] of Object.entries(listItems)) {
    if (!lists[uri] && members.length > 0) {
      lists[uri] = {
        uri,
        name: "Unknown List",
        members
      };
    }
  }
  return { lists, creatorDid };
}
async function fetchListsFromCarWithTimestamps(did, pdsUrl, targetListUris, onProgress) {
  const carData = await downloadCarFile(did, pdsUrl, onProgress);
  onProgress?.("Parsing lists...");
  return parseCarForListsWithTimestamps(carData, did, targetListUris);
}
async function fetchListsFromCar(did, pdsUrl, targetListUris, onProgress) {
  const carData = await downloadCarFile(did, pdsUrl, onProgress);
  onProgress?.("Parsing lists...");
  return parseCarForLists(carData, did, targetListUris);
}
async function getLatestCommit(did, pdsUrl) {
  const endpoints = [
    pdsUrl ? `${pdsUrl}/xrpc/com.atproto.sync.getLatestCommit?did=${encodeURIComponent(did)}` : null,
    `${BSKY_RELAY}/xrpc/com.atproto.sync.getLatestCommit?did=${encodeURIComponent(did)}`
  ].filter(Boolean);
  for (const url of endpoints) {
    try {
      const response = await fetch(url);
      if (response.ok) {
        const data = await response.json();
        return data;
      }
    } catch {
    }
  }
  return null;
}
function parseCarForPosts(carData, did) {
  const repo = fromUint8Array2(carData);
  const posts = [];
  for (const entry of repo) {
    if (entry.collection !== "app.bsky.feed.post") {
      continue;
    }
    try {
      const record = decode2(entry.bytes);
      if (record.$type === "app.bsky.feed.post") {
        const post = record;
        posts.push({
          uri: `at://${did}/app.bsky.feed.post/${entry.rkey}`,
          cid: "",
          text: post.text || "",
          createdAt: post.createdAt,
          reply: post.reply ? {
            parent: { uri: post.reply.parent.uri },
            root: post.reply.root ? { uri: post.reply.root.uri } : void 0
          } : void 0,
          embed: post.embed ? {
            $type: post.embed.$type,
            record: post.embed.record ? { uri: post.embed.record.uri } : void 0
          } : void 0
        });
      }
    } catch (error) {
      console.warn("[ErgoBlock CAR] Failed to decode entry:", error);
    }
  }
  return { posts, creatorDid: did };
}
function parseCarForPostsInternal(carData, did) {
  const repo = fromUint8Array2(carData);
  const posts = [];
  for (const entry of repo) {
    if (entry.collection !== "app.bsky.feed.post") {
      continue;
    }
    try {
      const record = decode2(entry.bytes);
      if (record.$type === "app.bsky.feed.post") {
        const post = record;
        posts.push({
          uri: `at://${did}/app.bsky.feed.post/${entry.rkey}`,
          cid: "",
          // CID not needed for interaction detection
          text: post.text || "",
          createdAt: post.createdAt,
          reply: post.reply ? {
            parent: { uri: post.reply.parent.uri },
            root: post.reply.root ? { uri: post.reply.root.uri } : void 0
          } : void 0,
          embed: post.embed ? {
            $type: post.embed.$type,
            record: post.embed.record ? { uri: post.embed.record.uri } : void 0
          } : void 0
        });
      }
    } catch (error) {
      console.warn("[ErgoBlock CAR] Failed to decode entry:", error);
    }
  }
  return posts;
}
async function fetchAndParseRepo(did, pdsUrl, onProgress) {
  const carData = await downloadCarFile(did, pdsUrl, onProgress);
  onProgress?.("Parsing repository...");
  const posts = parseCarForPostsInternal(carData, did);
  const blocks = parseCarForBlocks(carData);
  onProgress?.(`Found ${posts.length} posts, ${blocks.length} blocks`);
  return {
    posts,
    blocks,
    fetchedAt: Date.now()
  };
}
async function getRecordCountsFromCar(did, pdsUrl, onProgress) {
  const carData = await downloadCarFile(did, pdsUrl, onProgress);
  onProgress?.("Counting records...");
  const counts = {
    "app.bsky.graph.follow": 0,
    "app.bsky.graph.block": 0,
    "app.bsky.graph.listitem": 0,
    "app.bsky.graph.list": 0,
    "app.bsky.feed.post": 0,
    "app.bsky.feed.like": 0,
    "app.bsky.feed.repost": 0,
    "app.bsky.actor.profile": 0
  };
  const repo = fromUint8Array2(carData);
  for (const entry of repo) {
    const collection = entry.collection;
    if (collection in counts) {
      counts[collection]++;
    } else {
      counts[collection] = (counts[collection] || 0) + 1;
    }
  }
  onProgress?.("Done");
  return counts;
}
async function getCarFileSize(did, pdsUrl) {
  const endpoints = [
    pdsUrl ? `${pdsUrl}/xrpc/com.atproto.sync.getRepo?did=${encodeURIComponent(did)}` : null,
    `${BSKY_RELAY}/xrpc/com.atproto.sync.getRepo?did=${encodeURIComponent(did)}`
  ].filter(Boolean);
  for (const url of endpoints) {
    try {
      const response = await fetch(url, { method: "HEAD" });
      if (response.ok) {
        const contentLength = response.headers.get("content-length");
        if (contentLength) {
          return parseInt(contentLength, 10);
        }
      }
    } catch {
    }
  }
  return null;
}
function parseCarForAllGraphOperations(carData, creatorDid) {
  const repo = fromUint8Array2(carData);
  const blocks = [];
  const follows = [];
  const listitems = [];
  const listNames = {};
  for (const entry of repo) {
    try {
      if (entry.collection === "app.bsky.graph.list") {
        const record = decode2(entry.bytes);
        if (record.$type === "app.bsky.graph.list") {
          const list = record;
          const listUri = `at://${creatorDid}/app.bsky.graph.list/${entry.rkey}`;
          listNames[listUri] = list.name;
        }
      }
    } catch {
    }
  }
  const repo2 = fromUint8Array2(carData);
  for (const entry of repo2) {
    try {
      if (entry.collection === "app.bsky.graph.block") {
        const record = decode2(entry.bytes);
        if (record.$type === "app.bsky.graph.block") {
          const block = record;
          if (block.subject && block.createdAt) {
            blocks.push({
              type: "block",
              did: block.subject,
              rkey: entry.rkey,
              createdAt: new Date(block.createdAt).getTime()
            });
          }
        }
      } else if (entry.collection === "app.bsky.graph.follow") {
        const record = decode2(entry.bytes);
        if (record.$type === "app.bsky.graph.follow") {
          const follow = record;
          if (follow.subject && follow.createdAt) {
            follows.push({
              type: "follow",
              did: follow.subject,
              rkey: entry.rkey,
              createdAt: new Date(follow.createdAt).getTime()
            });
          }
        }
      } else if (entry.collection === "app.bsky.graph.listitem") {
        const record = decode2(entry.bytes);
        if (record.$type === "app.bsky.graph.listitem") {
          const item = record;
          if (item.subject && item.createdAt) {
            listitems.push({
              type: "listitem",
              did: item.subject,
              rkey: entry.rkey,
              createdAt: new Date(item.createdAt).getTime(),
              listUri: item.list,
              listName: listNames[item.list] || "Unknown List"
            });
          }
        }
      }
    } catch (error) {
      console.warn("[ErgoBlock CAR] Failed to decode graph operation:", error);
    }
  }
  return { blocks, follows, listitems };
}
function detectMassOperations(operations, settings) {
  const clusters = [];
  const timeWindowMs = settings.timeWindowMinutes * 60 * 1e3;
  const operationGroups = [
    { type: "block", ops: operations.blocks },
    { type: "follow", ops: operations.follows },
    { type: "listitem", ops: operations.listitems }
  ];
  for (const group of operationGroups) {
    if (group.ops.length < settings.minOperationCount) {
      continue;
    }
    const sorted = [...group.ops].sort((a, b) => a.createdAt - b.createdAt);
    const used = /* @__PURE__ */ new Set();
    for (let i = 0; i < sorted.length; i++) {
      if (used.has(sorted[i].rkey)) {
        continue;
      }
      const windowStart = sorted[i].createdAt;
      const windowEnd = windowStart + timeWindowMs;
      const windowOps = [];
      for (let j = i; j < sorted.length && sorted[j].createdAt <= windowEnd; j++) {
        if (!used.has(sorted[j].rkey)) {
          windowOps.push(sorted[j]);
        }
      }
      if (windowOps.length >= settings.minOperationCount) {
        for (const op of windowOps) {
          used.add(op.rkey);
        }
        clusters.push({
          id: generateId("cluster"),
          type: group.type,
          operations: windowOps,
          startTime: windowOps[0].createdAt,
          endTime: windowOps[windowOps.length - 1].createdAt,
          count: windowOps.length
        });
      }
    }
  }
  clusters.sort((a, b) => b.startTime - a.startTime);
  return clusters;
}
function parseCarForFollowsAndBlocks(carData) {
  const repo = fromUint8Array2(carData);
  const follows = [];
  const blocks = [];
  for (const entry of repo) {
    try {
      if (entry.collection === "app.bsky.graph.follow") {
        const record = decode2(entry.bytes);
        if (record.$type === "app.bsky.graph.follow") {
          const follow = record;
          if (follow.subject) {
            follows.push(follow.subject);
          }
        }
      } else if (entry.collection === "app.bsky.graph.block") {
        const record = decode2(entry.bytes);
        if (record.$type === "app.bsky.graph.block") {
          const block = record;
          if (block.subject) {
            blocks.push(block.subject);
          }
        }
      }
    } catch (error) {
      console.warn("[ErgoBlock CAR] Failed to decode graph entry:", error);
    }
  }
  return { follows, blocks };
}
async function fetchExternalUserGraph(did, pdsUrl, onProgress) {
  const carData = await downloadCarFile(did, pdsUrl, onProgress);
  onProgress?.("Parsing follows and blocks...");
  return parseCarForFollowsAndBlocks(carData);
}

// src/carCache.ts
var DB_NAME = "ergoblock-car-cache";
var DB_VERSION = 1;
var STORES = {
  METADATA: "metadata",
  POSTS: "posts",
  GRAPH_OPS: "graphOps",
  LISTS: "lists"
};
var dbPromise = null;
function openDatabase() {
  if (dbPromise) {
    return dbPromise;
  }
  dbPromise = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, DB_VERSION);
    request.onerror = () => {
      console.error("[CarCache] Failed to open database:", request.error);
      dbPromise = null;
      reject(request.error);
    };
    request.onsuccess = () => {
      resolve(request.result);
    };
    request.onupgradeneeded = (event) => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains(STORES.METADATA)) {
        db.createObjectStore(STORES.METADATA, { keyPath: "did" });
      }
      if (!db.objectStoreNames.contains(STORES.POSTS)) {
        db.createObjectStore(STORES.POSTS, { keyPath: "did" });
      }
      if (!db.objectStoreNames.contains(STORES.GRAPH_OPS)) {
        db.createObjectStore(STORES.GRAPH_OPS, { keyPath: "did" });
      }
      if (!db.objectStoreNames.contains(STORES.LISTS)) {
        db.createObjectStore(STORES.LISTS, { keyPath: "did" });
      }
    };
  });
  return dbPromise;
}
async function withTransaction(storeNames, mode, callback) {
  const db = await openDatabase();
  const transaction = db.transaction(storeNames, mode);
  return callback(transaction);
}
async function getCarCacheMetadata(did) {
  try {
    return await withTransaction(STORES.METADATA, "readonly", (tx) => {
      return new Promise((resolve, reject) => {
        const store = tx.objectStore(STORES.METADATA);
        const request = store.get(did);
        request.onsuccess = () => resolve(request.result || null);
        request.onerror = () => reject(request.error);
      });
    });
  } catch (error) {
    console.error("[CarCache] Failed to get metadata:", error);
    return null;
  }
}
async function getCachedCarData(did) {
  try {
    const db = await openDatabase();
    const tx = db.transaction(
      [STORES.METADATA, STORES.POSTS, STORES.GRAPH_OPS, STORES.LISTS],
      "readonly"
    );
    const [metadata, postsData, graphOpsData, listsData] = await Promise.all([
      new Promise((resolve, reject) => {
        const request = tx.objectStore(STORES.METADATA).get(did);
        request.onsuccess = () => resolve(request.result || null);
        request.onerror = () => reject(request.error);
      }),
      new Promise((resolve, reject) => {
        const request = tx.objectStore(STORES.POSTS).get(did);
        request.onsuccess = () => resolve(request.result || null);
        request.onerror = () => reject(request.error);
      }),
      new Promise((resolve, reject) => {
        const request = tx.objectStore(STORES.GRAPH_OPS).get(did);
        request.onsuccess = () => resolve(request.result || null);
        request.onerror = () => reject(request.error);
      }),
      new Promise((resolve, reject) => {
        const request = tx.objectStore(STORES.LISTS).get(did);
        request.onsuccess = () => resolve(request.result || null);
        request.onerror = () => reject(request.error);
      })
    ]);
    if (!metadata) {
      return null;
    }
    return {
      did,
      rev: metadata.rev,
      posts: postsData?.posts || [],
      blocks: graphOpsData?.blocks || [],
      follows: graphOpsData?.follows || [],
      listitems: graphOpsData?.listitems || [],
      lists: listsData?.lists || []
    };
  } catch (error) {
    console.error("[CarCache] Failed to get cached data:", error);
    return null;
  }
}
async function saveCarData(did, rev, sizeBytes, data) {
  try {
    const db = await openDatabase();
    const tx = db.transaction(
      [STORES.METADATA, STORES.POSTS, STORES.GRAPH_OPS, STORES.LISTS],
      "readwrite"
    );
    const metadata = {
      did,
      rev,
      downloadedAt: Date.now(),
      sizeBytes,
      collections: {
        posts: data.posts.length,
        blocks: data.blocks.length,
        follows: data.follows.length,
        listitems: data.listitems.length,
        lists: data.lists.length
      }
    };
    await Promise.all([
      new Promise((resolve, reject) => {
        const request = tx.objectStore(STORES.METADATA).put(metadata);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      }),
      new Promise((resolve, reject) => {
        const request = tx.objectStore(STORES.POSTS).put({ did, posts: data.posts });
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      }),
      new Promise((resolve, reject) => {
        const request = tx.objectStore(STORES.GRAPH_OPS).put({
          did,
          blocks: data.blocks,
          follows: data.follows,
          listitems: data.listitems
        });
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      }),
      new Promise((resolve, reject) => {
        const request = tx.objectStore(STORES.LISTS).put({ did, lists: data.lists });
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      })
    ]);
    console.log(`[CarCache] Saved cache for ${did} (rev: ${rev.slice(0, 8)}...)`);
  } catch (error) {
    console.error("[CarCache] Failed to save data:", error);
    throw error;
  }
}
async function invalidateCarCache(did) {
  try {
    const db = await openDatabase();
    const tx = db.transaction(
      [STORES.METADATA, STORES.POSTS, STORES.GRAPH_OPS, STORES.LISTS],
      "readwrite"
    );
    await Promise.all([
      new Promise((resolve, reject) => {
        const request = tx.objectStore(STORES.METADATA).delete(did);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      }),
      new Promise((resolve, reject) => {
        const request = tx.objectStore(STORES.POSTS).delete(did);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      }),
      new Promise((resolve, reject) => {
        const request = tx.objectStore(STORES.GRAPH_OPS).delete(did);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      }),
      new Promise((resolve, reject) => {
        const request = tx.objectStore(STORES.LISTS).delete(did);
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      })
    ]);
    console.log(`[CarCache] Invalidated cache for ${did}`);
  } catch (error) {
    console.error("[CarCache] Failed to invalidate cache:", error);
    throw error;
  }
}

// src/carService.ts
var BSKY_RELAY2 = "https://bsky.network";
var CAR_DOWNLOAD_TIMEOUT_MS2 = 12e4;
var CACHE_TTL_MS = 24 * 60 * 60 * 1e3;
var carFetchCoalescer = new RequestCoalescer();
function formatBytes2(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}
function createProgress(did, stage, message, options) {
  const bytesDownloaded = options?.bytesDownloaded || 0;
  const bytesTotal = options?.bytesTotal ?? null;
  const percentComplete = bytesTotal && bytesTotal > 0 ? Math.round(bytesDownloaded / bytesTotal * 100) : null;
  return {
    did,
    stage,
    bytesDownloaded,
    bytesTotal,
    percentComplete,
    message,
    isIncremental: options?.isIncremental || false,
    startedAt: Date.now(),
    error: options?.error
  };
}
async function checkCarCacheStatus(did, pdsUrl) {
  const cached = await getCarCacheMetadata(did);
  const latestCommit = await getLatestCommit(did, pdsUrl);
  if (!cached) {
    return {
      hasCached: false,
      isStale: true,
      latestRev: latestCommit?.rev
    };
  }
  const cacheAge = Date.now() - cached.downloadedAt;
  const isExpired = cacheAge > CACHE_TTL_MS;
  return {
    hasCached: true,
    isStale: isExpired,
    // Only stale if older than 24 hours
    cachedRev: cached.rev,
    latestRev: latestCommit?.rev,
    cachedAt: cached.downloadedAt,
    cachedSize: cached.sizeBytes,
    recordCounts: cached.collections
  };
}
async function downloadCarWithProgress(did, pdsUrl, since, onProgress) {
  const isIncremental = !!since;
  const sinceParam = since ? `&since=${encodeURIComponent(since)}` : "";
  onProgress(
    createProgress(
      did,
      "downloading",
      isIncremental ? "Downloading changes..." : "Downloading repository...",
      { isIncremental }
    )
  );
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), CAR_DOWNLOAD_TIMEOUT_MS2);
  try {
    let response = null;
    if (pdsUrl) {
      try {
        const url = `${pdsUrl}/xrpc/com.atproto.sync.getRepo?did=${encodeURIComponent(did)}${sinceParam}`;
        const pdsResponse = await fetch(url, { signal: controller.signal });
        if (pdsResponse.ok) {
          response = pdsResponse;
        } else if (pdsResponse.status === 400 && since) {
          console.warn("[CarService] PDS does not support incremental sync");
          throw new Error("Incremental not supported");
        }
      } catch (error) {
        if (error instanceof Error && error.message === "Incremental not supported") {
          throw error;
        }
        console.warn("[CarService] PDS fetch failed, trying relay");
      }
    }
    if (!response) {
      const url = `${BSKY_RELAY2}/xrpc/com.atproto.sync.getRepo?did=${encodeURIComponent(did)}${sinceParam}`;
      const relayResponse = await fetch(url, { signal: controller.signal });
      if (!relayResponse.ok) {
        if (relayResponse.status === 400 && since) {
          throw new Error("Incremental not supported");
        }
        throw new Error(`Failed to download repo: ${relayResponse.status}`);
      }
      response = relayResponse;
    }
    const contentLength = response.headers.get("content-length");
    const totalBytes = contentLength ? parseInt(contentLength, 10) : null;
    const reader = response.body?.getReader();
    if (!reader) {
      throw new Error("Failed to get response reader");
    }
    const chunks = [];
    let receivedBytes = 0;
    try {
      while (true) {
        if (controller.signal.aborted) {
          reader.cancel();
          throw new Error("Download aborted");
        }
        const { done, value } = await reader.read();
        if (done) break;
        chunks.push(value);
        receivedBytes += value.length;
        const message = totalBytes ? `Downloading... ${formatBytes2(receivedBytes)} / ${formatBytes2(totalBytes)}` : `Downloading... ${formatBytes2(receivedBytes)}`;
        onProgress(
          createProgress(did, "downloading", message, {
            bytesDownloaded: receivedBytes,
            bytesTotal: totalBytes,
            isIncremental
          })
        );
      }
    } catch (error) {
      reader.cancel();
      throw error;
    }
    const result = new Uint8Array(receivedBytes);
    let offset = 0;
    for (const chunk of chunks) {
      result.set(chunk, offset);
      offset += chunk.length;
    }
    return { data: result, sizeBytes: receivedBytes };
  } finally {
    clearTimeout(timeoutId);
  }
}
function parseCarData(carData, did, onProgress) {
  onProgress(createProgress(did, "parsing", "Parsing posts..."));
  const postsResult = parseCarForPosts(carData, did);
  onProgress(createProgress(did, "parsing", "Parsing graph operations..."));
  const graphOps = parseCarForAllGraphOperations(carData, did);
  onProgress(createProgress(did, "parsing", "Parsing lists..."));
  const listsResult = parseCarForLists(carData, did);
  const lists = Object.values(listsResult.lists);
  return {
    posts: postsResult.posts,
    blocks: graphOps.blocks,
    follows: graphOps.follows,
    listitems: graphOps.listitems,
    lists
  };
}
async function getCarDataSmart(options) {
  const { did } = options;
  return carFetchCoalescer.execute(did, async () => {
    return getCarDataSmartInternal(options);
  });
}
async function getCarDataSmartInternal(options) {
  const { did, pdsUrl, forceRefresh = false, preferCache = false, onProgress } = options;
  const reportProgress = onProgress || (() => {
  });
  reportProgress(createProgress(did, "checking", "Checking cache..."));
  const cached = forceRefresh ? null : await getCachedCarData(did);
  const cachedMeta = forceRefresh ? null : await getCarCacheMetadata(did);
  if (cached && cachedMeta) {
    const cacheAge = Date.now() - cachedMeta.downloadedAt;
    const isFresh = cacheAge <= CACHE_TTL_MS;
    if (isFresh || preferCache) {
      const reason = isFresh ? "within 24h TTL" : "preferCache=true";
      console.log(
        `[CarService] Using cached data for ${did} (${reason}, rev: ${cachedMeta.rev.slice(0, 8)}...)`
      );
      reportProgress(createProgress(did, "complete", "Using cached data"));
      return {
        data: cached,
        wasIncremental: false,
        wasCached: true,
        downloadSize: 0
      };
    }
  }
  reportProgress(createProgress(did, "checking", "Checking repository version..."));
  const latestCommit = await getLatestCommit(did, pdsUrl);
  if (cached && cachedMeta && latestCommit && cachedMeta.rev === latestCommit.rev) {
    console.log(`[CarService] Cache rev matches latest for ${did}, refreshing timestamp`);
    await saveCarData(did, cachedMeta.rev, cachedMeta.sizeBytes, {
      posts: cached.posts,
      blocks: cached.blocks,
      follows: cached.follows,
      listitems: cached.listitems,
      lists: cached.lists
    });
    reportProgress(createProgress(did, "complete", "Using cached data"));
    return {
      data: cached,
      wasIncremental: false,
      wasCached: true,
      downloadSize: 0
    };
  }
  let downloadResult = null;
  let wasIncremental = false;
  if (cachedMeta && latestCommit) {
    try {
      console.log(`[CarService] Attempting incremental sync from ${cachedMeta.rev.slice(0, 8)}...`);
      downloadResult = await downloadCarWithProgress(did, pdsUrl, cachedMeta.rev, reportProgress);
      wasIncremental = true;
    } catch (error) {
      if (error instanceof Error && error.message === "Incremental not supported") {
        console.log("[CarService] Incremental sync not supported, doing full download");
      } else {
        console.warn("[CarService] Incremental sync failed:", error);
      }
    }
  }
  if (!downloadResult) {
    downloadResult = await downloadCarWithProgress(did, pdsUrl, null, reportProgress);
    wasIncremental = false;
  }
  let parsedData;
  try {
    parsedData = parseCarData(downloadResult.data, did, reportProgress);
  } catch (parseError) {
    const errorMessage = parseError instanceof Error ? parseError.message : String(parseError);
    if (wasIncremental && (errorMessage.includes("cid not found") || errorMessage.includes("blockmap") || errorMessage.includes("block not found"))) {
      console.warn(
        "[CarService] Incremental CAR has incomplete block map, falling back to full download"
      );
      downloadResult = await downloadCarWithProgress(did, pdsUrl, null, reportProgress);
      wasIncremental = false;
      parsedData = parseCarData(downloadResult.data, did, reportProgress);
    } else {
      throw parseError;
    }
  }
  reportProgress(createProgress(did, "saving", "Saving to cache..."));
  const rev = latestCommit?.rev || `unknown-${Date.now()}`;
  await saveCarData(did, rev, downloadResult.sizeBytes, parsedData);
  reportProgress(createProgress(did, "complete", "Complete"));
  return {
    data: {
      did,
      rev,
      ...parsedData
    },
    wasIncremental,
    wasCached: false,
    downloadSize: downloadResult.sizeBytes
  };
}
async function getGraphOperationsSmart(options) {
  const result = await getCarDataSmart(options);
  return {
    blocks: result.data.blocks,
    follows: result.data.follows,
    listitems: result.data.listitems,
    wasCached: result.wasCached,
    wasIncremental: result.wasIncremental
  };
}

// src/clearskyCache.ts
var DB_NAME2 = "ergoblock-clearsky-cache";
var DB_VERSION2 = 1;
var STORES2 = {
  BLOCKED_BY: "blockedBy",
  QUEUE: "fetchQueue"
};
var dbPromise2 = null;
function openDatabase2() {
  if (dbPromise2) {
    return dbPromise2;
  }
  dbPromise2 = new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME2, DB_VERSION2);
    request.onerror = () => {
      console.error("[ClearskyCache] Failed to open database:", request.error);
      dbPromise2 = null;
      reject(request.error);
    };
    request.onsuccess = () => {
      resolve(request.result);
    };
    request.onupgradeneeded = (event) => {
      const db = event.target.result;
      if (!db.objectStoreNames.contains(STORES2.BLOCKED_BY)) {
        db.createObjectStore(STORES2.BLOCKED_BY, { keyPath: "targetDid" });
      }
      if (!db.objectStoreNames.contains(STORES2.QUEUE)) {
        const queueStore = db.createObjectStore(STORES2.QUEUE, { keyPath: "targetDid" });
        queueStore.createIndex("status", "status", { unique: false });
        queueStore.createIndex("priority", "priority", { unique: false });
      }
    };
  });
  return dbPromise2;
}
async function getBlockedByCache(targetDid) {
  try {
    const db = await openDatabase2();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES2.BLOCKED_BY, "readonly");
      const request = tx.objectStore(STORES2.BLOCKED_BY).get(targetDid);
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error("[ClearskyCache] Failed to get blocked-by cache:", error);
    return null;
  }
}
async function saveBlockedByCache(data) {
  try {
    const db = await openDatabase2();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES2.BLOCKED_BY, "readwrite");
      const request = tx.objectStore(STORES2.BLOCKED_BY).put(data);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error("[ClearskyCache] Failed to save blocked-by cache:", error);
    throw error;
  }
}
async function queueForFetch(targetDid, priority = 10) {
  try {
    const db = await openDatabase2();
    const existing = await getQueueEntry(targetDid);
    if (existing && (existing.status === "pending" || existing.status === "in_progress")) {
      return;
    }
    const entry = {
      targetDid,
      priority,
      queuedAt: Date.now(),
      status: "pending",
      retryCount: existing?.retryCount || 0
    };
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES2.QUEUE, "readwrite");
      const request = tx.objectStore(STORES2.QUEUE).put(entry);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error("[ClearskyCache] Failed to queue for fetch:", error);
    throw error;
  }
}
async function getQueueEntry(targetDid) {
  try {
    const db = await openDatabase2();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES2.QUEUE, "readonly");
      const request = tx.objectStore(STORES2.QUEUE).get(targetDid);
      request.onsuccess = () => resolve(request.result || null);
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error("[ClearskyCache] Failed to get queue entry:", error);
    return null;
  }
}
async function getPendingQueue() {
  try {
    const db = await openDatabase2();
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES2.QUEUE, "readonly");
      const store = tx.objectStore(STORES2.QUEUE);
      const index = store.index("status");
      const request = index.getAll("pending");
      request.onsuccess = () => {
        const entries = request.result || [];
        entries.sort((a, b) => {
          if (a.priority !== b.priority) return a.priority - b.priority;
          return a.queuedAt - b.queuedAt;
        });
        resolve(entries);
      };
      request.onerror = () => reject(request.error);
    });
  } catch (error) {
    console.error("[ClearskyCache] Failed to get pending queue:", error);
    return [];
  }
}
async function updateQueueStatus(targetDid, status, error) {
  try {
    const db = await openDatabase2();
    const existing = await getQueueEntry(targetDid);
    if (!existing) return;
    const updated = {
      ...existing,
      status,
      lastError: error,
      retryCount: status === "failed" ? existing.retryCount + 1 : existing.retryCount
    };
    return new Promise((resolve, reject) => {
      const tx = db.transaction(STORES2.QUEUE, "readwrite");
      const request = tx.objectStore(STORES2.QUEUE).put(updated);
      request.onsuccess = () => resolve();
      request.onerror = () => reject(request.error);
    });
  } catch (error2) {
    console.error("[ClearskyCache] Failed to update queue status:", error2);
    throw error2;
  }
}
async function clearClearskyCache() {
  try {
    const db = await openDatabase2();
    const tx = db.transaction([STORES2.BLOCKED_BY, STORES2.QUEUE], "readwrite");
    await Promise.all([
      new Promise((resolve, reject) => {
        const request = tx.objectStore(STORES2.BLOCKED_BY).clear();
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      }),
      new Promise((resolve, reject) => {
        const request = tx.objectStore(STORES2.QUEUE).clear();
        request.onsuccess = () => resolve();
        request.onerror = () => reject(request.error);
      })
    ]);
    console.log("[ClearskyCache] Cleared all cache");
  } catch (error) {
    console.error("[ClearskyCache] Failed to clear cache:", error);
    throw error;
  }
}

// src/clearskyService.ts
var CLEARSKY_API_BASE = "https://public.api.clearsky.services";
var CACHE_TTL_MS2 = 24 * 60 * 60 * 1e3;
var REQUEST_DELAY_MS = 500;
var RATE_LIMIT_BACKOFF_MS = 5e3;
var MAX_RETRIES = 3;
var MAX_PAGES = 100;
async function fetchBlockedByFromClearsky(targetDidOrHandle, onProgress) {
  const blockerDids = [];
  let offset = 0;
  let pageCount = 0;
  const PAGE_SIZE = 100;
  try {
    let hasMore = true;
    while (hasMore && pageCount < MAX_PAGES) {
      const url = offset > 0 ? `${CLEARSKY_API_BASE}/api/v1/anon/single-blocklist/${encodeURIComponent(targetDidOrHandle)}?cursor=${offset}` : `${CLEARSKY_API_BASE}/api/v1/anon/single-blocklist/${encodeURIComponent(targetDidOrHandle)}`;
      const response = await fetch(url);
      if (!response.ok) {
        if (response.status === 404) {
          console.log(`[Clearsky] User not found: ${targetDidOrHandle}`);
          return { blockerDids: [], complete: true };
        }
        if (response.status === 429) {
          console.warn(`[Clearsky] Rate limited, waiting ${RATE_LIMIT_BACKOFF_MS / 1e3}s...`);
          await sleep(RATE_LIMIT_BACKOFF_MS);
          continue;
        }
        throw new Error(`Clearsky API error: ${response.status}`);
      }
      const data = await response.json();
      const entriesThisPage = data.data?.blocklist?.length || 0;
      if (data.data?.blocklist) {
        for (const entry of data.data.blocklist) {
          blockerDids.push(entry.did);
        }
        onProgress?.(blockerDids.length);
      }
      pageCount++;
      if (entriesThisPage >= PAGE_SIZE) {
        offset = blockerDids.length;
        await sleep(REQUEST_DELAY_MS);
      } else {
        hasMore = false;
      }
    }
    const complete = !hasMore;
    console.log(
      `[Clearsky] Fetched ${blockerDids.length} blockers for ${targetDidOrHandle} (${pageCount} pages, complete: ${complete})`,
      blockerDids.slice(0, 5)
    );
    return { blockerDids, complete };
  } catch (error) {
    console.error("[Clearsky] Failed to fetch blocked-by:", error);
    throw error;
  }
}
async function getCachedBlockedBy(targetDid) {
  const cached = await getBlockedByCache(targetDid);
  if (!cached) return null;
  if (Date.now() - cached.fetchedAt > CACHE_TTL_MS2) {
    console.log(`[Clearsky] Cache expired for ${targetDid}`);
    return null;
  }
  return cached;
}
async function getFollowsWhoBlock(targetDid, myFollowDids, forceRefresh = false) {
  if (!forceRefresh) {
    const cached = await getCachedBlockedBy(targetDid);
    if (cached) {
      const blockerSet2 = new Set(cached.blockerDids);
      const followsWhoBlock2 = [...myFollowDids].filter((did) => blockerSet2.has(did));
      return {
        count: followsWhoBlock2.length,
        dids: followsWhoBlock2,
        totalBlockers: cached.totalCount,
        cached: true,
        fetchedAt: cached.fetchedAt
      };
    }
  }
  const { blockerDids, complete } = await fetchBlockedByFromClearsky(targetDid);
  const cacheEntry = {
    targetDid,
    blockerDids,
    totalCount: blockerDids.length,
    fetchedAt: Date.now(),
    complete
  };
  await saveBlockedByCache(cacheEntry);
  const blockerSet = new Set(blockerDids);
  const followSet = new Set(myFollowDids);
  const followsWhoBlock = [];
  if (followSet.size <= blockerSet.size) {
    for (const did of followSet) {
      if (blockerSet.has(did)) {
        followsWhoBlock.push(did);
      }
    }
  } else {
    for (const did of blockerSet) {
      if (followSet.has(did)) {
        followsWhoBlock.push(did);
      }
    }
  }
  return {
    count: followsWhoBlock.length,
    dids: followsWhoBlock,
    totalBlockers: blockerDids.length,
    cached: false,
    fetchedAt: cacheEntry.fetchedAt
  };
}
async function getFollowsWhoBlockCached(targetDid, myFollowDids) {
  const cached = await getCachedBlockedBy(targetDid);
  if (!cached) return null;
  const blockerSet = new Set(cached.blockerDids);
  const followsWhoBlock = [...myFollowDids].filter((did) => blockerSet.has(did));
  return {
    count: followsWhoBlock.length,
    dids: followsWhoBlock,
    totalBlockers: cached.totalCount,
    cached: true,
    fetchedAt: cached.fetchedAt
  };
}
async function processBlockedByQueue(maxItems = 5) {
  const pending = await getPendingQueue();
  const toProcess = pending.slice(0, maxItems);
  if (toProcess.length === 0) {
    return 0;
  }
  console.log(`[Clearsky] Processing ${toProcess.length} queued fetches`);
  let processed = 0;
  for (const entry of toProcess) {
    try {
      await updateQueueStatus(entry.targetDid, "in_progress");
      const cached = await getCachedBlockedBy(entry.targetDid);
      if (cached) {
        await updateQueueStatus(entry.targetDid, "completed");
        processed++;
        continue;
      }
      const { blockerDids, complete } = await fetchBlockedByFromClearsky(entry.targetDid);
      await saveBlockedByCache({
        targetDid: entry.targetDid,
        blockerDids,
        totalCount: blockerDids.length,
        fetchedAt: Date.now(),
        complete
      });
      await updateQueueStatus(entry.targetDid, "completed");
      processed++;
      await sleep(REQUEST_DELAY_MS * 2);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      console.error(`[Clearsky] Failed to fetch ${entry.targetDid}:`, errorMessage);
      if (entry.retryCount >= MAX_RETRIES) {
        await updateQueueStatus(entry.targetDid, "failed", errorMessage);
      } else {
        await updateQueueStatus(entry.targetDid, "pending", errorMessage);
      }
    }
  }
  return processed;
}
async function hasQueuedItems() {
  const pending = await getPendingQueue();
  return pending.length > 0;
}
async function prewarmBlockedByCache(targetDids, highPriority = false) {
  let queued = 0;
  let alreadyCached = 0;
  for (const did of targetDids) {
    const cached = await getCachedBlockedBy(did);
    if (cached) {
      alreadyCached++;
    } else {
      await queueForFetch(did, highPriority ? 1 : 10);
      queued++;
    }
  }
  console.log(`[Clearsky] Prewarm: ${queued} queued, ${alreadyCached} already cached`);
  return { queued, alreadyCached };
}

// src/background.ts
var ALARM_NAME = "checkExpirations";
var SYNC_ALARM_NAME = "syncWithBluesky";
var FOLLOWS_SYNC_ALARM_NAME = "followsSync";
var CLEARSKY_QUEUE_ALARM_NAME = "clearskyQueue";
var SYNC_INTERVAL_MINUTES = 60;
var FOLLOWS_SYNC_INTERVAL_MINUTES = 120;
var CLEARSKY_QUEUE_INTERVAL_MINUTES = 2;
var PAGINATION_DELAY = 100;
var syncMutex = new Mutex();
var blocklistAuditMutex = new Mutex();
var followsSyncMutex = new Mutex();
var clearskyQueueMutex = new Mutex();
async function getAuthToken() {
  const result = await browser_default.storage.local.get("authToken");
  return result.authToken || null;
}
async function requestFreshAuth() {
  try {
    const tabs = await browser_default.tabs.query({ url: "*://*.bsky.app/*" });
    if (tabs.length === 0) {
      console.log("[ErgoBlock BG] No Bluesky tabs found for auth refresh");
      return null;
    }
    for (const tab of tabs) {
      if (tab.id) {
        try {
          const response = await browser_default.tabs.sendMessage(tab.id, { type: "REQUEST_AUTH" });
          if (response?.auth) {
            await browser_default.storage.local.set({ authToken: response.auth, authStatus: "valid" });
            console.log("[ErgoBlock BG] Got fresh auth from tab", tab.id);
            return response.auth;
          }
        } catch {
          continue;
        }
      }
    }
    console.log("[ErgoBlock BG] Could not get fresh auth from any tab");
    return null;
  } catch (error) {
    console.error("[ErgoBlock BG] Error requesting fresh auth:", error);
    return null;
  }
}
function isExpiredTokenError(error) {
  const message = error.message.toLowerCase();
  return message.includes("expiredtoken") || message.includes("token has expired") || message.includes("expired token");
}
async function refreshSession(_auth) {
  console.log("[ErgoBlock BG] Access token expired, requesting fresh auth from tab");
  return requestFreshAuth();
}
async function bgApiRequest(endpoint, method, body, token, pdsUrl) {
  const doRequest = async (accessJwt) => {
    const result = await executeApiRequest(
      endpoint,
      method,
      body,
      { accessJwt, pdsUrl },
      pdsUrl
      // Force PDS for background operations to ensure write consistency
    );
    return result;
  };
  try {
    const result = await doRequest(token);
    await browser_default.storage.local.set({ authStatus: "valid" });
    return result;
  } catch (error) {
    if (error instanceof Error) {
      if (isExpiredTokenError(error)) {
        console.log("[ErgoBlock BG] Token expired, attempting refresh...");
        const auth = await getAuthToken();
        if (!auth) {
          console.error("[ErgoBlock BG] No auth available for refresh");
          await browser_default.storage.local.set({ authStatus: "invalid" });
          throw error;
        }
        const newAuth = await refreshSession(auth);
        if (newAuth) {
          console.log("[ErgoBlock BG] Retrying request with refreshed token...");
          try {
            const result = await doRequest(newAuth.accessJwt);
            await browser_default.storage.local.set({ authStatus: "valid" });
            return result;
          } catch (retryError) {
            console.error("[ErgoBlock BG] Retry after refresh failed:", retryError);
            throw retryError;
          }
        } else {
          console.error("[ErgoBlock BG] Token refresh failed, marking session invalid");
          await browser_default.storage.local.set({ authStatus: "invalid" });
          throw error;
        }
      }
      if (error.message.includes("401") || error.message.includes("Auth error")) {
        console.error("[ErgoBlock BG] Auth failed (401), marking session invalid");
        await browser_default.storage.local.set({ authStatus: "invalid" });
      }
    }
    throw error;
  }
}
async function unblockUser(did, token, ownerDid, pdsUrl, rkey) {
  if (rkey) {
    console.log("[ErgoBlock BG] Unblocking using direct rkey:", rkey);
    await bgApiRequest(
      "com.atproto.repo.deleteRecord",
      "POST",
      {
        repo: ownerDid,
        collection: "app.bsky.graph.block",
        rkey
      },
      token,
      pdsUrl
    );
    return true;
  }
  console.log("[ErgoBlock BG] Unblocking using list scan (legacy)...");
  let cursor;
  let foundRkey;
  while (!foundRkey) {
    const url = cursor ? `com.atproto.repo.listRecords?repo=${ownerDid}&collection=app.bsky.graph.block&limit=100&cursor=${cursor}` : `com.atproto.repo.listRecords?repo=${ownerDid}&collection=app.bsky.graph.block&limit=100`;
    const blocks = await bgApiRequest(url, "GET", null, token, pdsUrl);
    const blockRecord = blocks?.records?.find((r) => r.value.subject === did);
    if (blockRecord) {
      foundRkey = blockRecord.uri.split("/").pop();
      break;
    }
    if (!blocks?.cursor) {
      console.log("[ErgoBlock BG] No block record found for", did);
      return false;
    }
    cursor = blocks.cursor;
  }
  if (!foundRkey) {
    console.log("[ErgoBlock BG] Could not determine rkey for", did);
    return false;
  }
  await bgApiRequest(
    "com.atproto.repo.deleteRecord",
    "POST",
    {
      repo: ownerDid,
      collection: "app.bsky.graph.block",
      rkey: foundRkey
    },
    token,
    pdsUrl
  );
  return true;
}
async function unmuteUser(did, token, pdsUrl) {
  await bgApiRequest("app.bsky.graph.unmuteActor", "POST", { actor: did }, token, pdsUrl);
  return true;
}
async function blockUser(did, token, ownerDid, pdsUrl) {
  const record = {
    $type: "app.bsky.graph.block",
    subject: did,
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  return bgApiRequest(
    "com.atproto.repo.createRecord",
    "POST",
    {
      repo: ownerDid,
      collection: "app.bsky.graph.block",
      record
    },
    token,
    pdsUrl
  );
}
async function sendNotification(type, handle, action, error) {
  const options = await getOptions();
  if (!options.notificationsEnabled) {
    return;
  }
  let title;
  let message;
  if (type === "expired_success") {
    title = "\u2705 Temporary action expired";
    message = `Your temporary ${action} of @${handle} has been lifted`;
  } else {
    title = "\u26A0\uFE0F Action failed";
    message = `Failed to ${action} @${handle}: ${error || "Unknown error"}`;
  }
  await browser_default.notifications.create({
    type: "basic",
    iconUrl: "icons/icon128.png",
    title,
    message,
    silent: !options.notificationSound
  });
}
async function fetchAllBlocks(auth) {
  const allBlocks = [];
  let cursor;
  do {
    let endpoint = "app.bsky.graph.getBlocks?limit=100";
    if (cursor) {
      endpoint += `&cursor=${encodeURIComponent(cursor)}`;
    }
    const response = await bgApiRequest(
      endpoint,
      "GET",
      null,
      auth.accessJwt,
      auth.pdsUrl
    );
    if (response?.blocks) {
      allBlocks.push(...response.blocks);
    }
    cursor = response?.cursor;
    if (cursor) {
      await sleep(PAGINATION_DELAY);
    }
  } while (cursor);
  return allBlocks;
}
async function fetchAllBlockRecords(auth) {
  const allRecords = [];
  let cursor;
  do {
    let endpoint = `com.atproto.repo.listRecords?repo=${auth.did}&collection=app.bsky.graph.block&limit=100`;
    if (cursor) {
      endpoint += `&cursor=${encodeURIComponent(cursor)}`;
    }
    const response = await bgApiRequest(
      endpoint,
      "GET",
      null,
      auth.accessJwt,
      auth.pdsUrl
    );
    if (response?.records) {
      allRecords.push(...response.records);
    }
    cursor = response?.cursor;
    if (cursor) {
      await sleep(PAGINATION_DELAY);
    }
  } while (cursor);
  return allRecords;
}
async function fetchAllMutes(auth) {
  const allMutes = [];
  let cursor;
  do {
    let endpoint = "app.bsky.graph.getMutes?limit=100";
    if (cursor) {
      endpoint += `&cursor=${encodeURIComponent(cursor)}`;
    }
    const response = await bgApiRequest(
      endpoint,
      "GET",
      null,
      auth.accessJwt,
      auth.pdsUrl
    );
    if (response?.mutes) {
      allMutes.push(...response.mutes);
    }
    cursor = response?.cursor;
    if (cursor) {
      await sleep(PAGINATION_DELAY);
    }
  } while (cursor);
  return allMutes;
}
async function fetchProfiles(dids, accessJwt, pdsUrl = "https://bsky.social") {
  const result = [];
  const batchSize = 25;
  const publicApi = "https://public.api.bsky.app";
  for (let i = 0; i < dids.length; i += batchSize) {
    const batch = dids.slice(i, i + batchSize);
    const params = batch.map((d) => `actors=${encodeURIComponent(d)}`).join("&");
    try {
      const response = await executeApiRequest(
        `app.bsky.actor.getProfiles?${params}`,
        "GET",
        null,
        { accessJwt, pdsUrl },
        publicApi
      );
      if (response?.profiles) {
        result.push(...response.profiles);
      }
    } catch (error) {
      console.error("[ErgoBlock BG] Error fetching profiles:", error);
    }
    if (i + batchSize < dids.length) {
      await sleep(200);
    }
  }
  return result;
}
async function fetchViewerStates(auth, dids) {
  const result = /* @__PURE__ */ new Map();
  const batchSize = 25;
  for (let i = 0; i < dids.length; i += batchSize) {
    const batch = dids.slice(i, i + batchSize);
    const params = batch.map((d) => `actors=${encodeURIComponent(d)}`).join("&");
    try {
      const response = await bgApiRequest(
        `app.bsky.actor.getProfiles?${params}`,
        "GET",
        null,
        auth.accessJwt,
        auth.pdsUrl
      );
      if (response?.profiles) {
        for (const profile of response.profiles) {
          if (profile.viewer) {
            result.set(profile.did, profile.viewer);
          }
        }
      }
    } catch (error) {
      console.error("[ErgoBlock BG] Error fetching viewer states:", error);
    }
    if (i + batchSize < dids.length) {
      await sleep(200);
    }
  }
  return result;
}
async function syncBlocks(auth) {
  const now = Date.now();
  let added = 0;
  let removed = 0;
  const newBlocks = [];
  const [bskyBlocks, blockRecords] = await Promise.all([
    fetchAllBlocks(auth),
    fetchAllBlockRecords(auth)
  ]);
  const bskyBlockDids = new Set(bskyBlocks.map((b) => b.did));
  const recordMap = /* @__PURE__ */ new Map();
  for (const record of blockRecords) {
    const rkey = record.uri.split("/").pop();
    if (rkey) {
      recordMap.set(record.value.subject, {
        createdAt: new Date(record.value.createdAt).getTime(),
        rkey
      });
    }
  }
  const [tempBlocks, permanentBlocks] = await Promise.all([getTempBlocks(), getPermanentBlocks()]);
  const newBlockDids = bskyBlocks.filter((b) => !permanentBlocks[b.did] && !tempBlocks[b.did]).map((b) => b.did);
  console.log(
    `[ErgoBlock BG] Fetching viewer states for ${newBlockDids.length} new blocks (skipping ${bskyBlocks.length - newBlockDids.length} existing)`
  );
  const viewerStates = newBlockDids.length > 0 ? await fetchViewerStates(auth, newBlockDids) : /* @__PURE__ */ new Map();
  const newPermanentBlocks = {};
  for (const block of bskyBlocks) {
    if (tempBlocks[block.did]) {
      continue;
    }
    const recordData = recordMap.get(block.did);
    const viewer = viewerStates.get(block.did) || permanentBlocks[block.did]?.viewer;
    newPermanentBlocks[block.did] = {
      did: block.did,
      handle: block.handle,
      displayName: block.displayName,
      avatar: block.avatar,
      createdAt: permanentBlocks[block.did]?.createdAt || recordData?.createdAt,
      syncedAt: permanentBlocks[block.did]?.syncedAt || now,
      rkey: recordData?.rkey || permanentBlocks[block.did]?.rkey,
      viewer
    };
    if (!permanentBlocks[block.did]) {
      added++;
      newBlocks.push({ did: block.did, handle: block.handle });
    }
  }
  for (const did of Object.keys(tempBlocks)) {
    if (!bskyBlockDids.has(did)) {
      console.log("[ErgoBlock BG] Temp block removed externally:", tempBlocks[did].handle);
      await removeTempBlock(did);
      await addHistoryEntry({
        did,
        handle: tempBlocks[did].handle,
        action: "unblocked",
        timestamp: now,
        trigger: "removed",
        // User removed externally
        success: true
      });
      removed++;
    }
  }
  await setPermanentBlocks(newPermanentBlocks);
  return { added, removed, newBlocks };
}
async function syncMutes(auth) {
  const now = Date.now();
  let added = 0;
  let removed = 0;
  const bskyMutes = await fetchAllMutes(auth);
  const bskyMuteDids = new Set(bskyMutes.map((m) => m.did));
  const [tempMutes, permanentMutes] = await Promise.all([getTempMutes(), getPermanentMutes()]);
  const newMuteDids = bskyMutes.filter((m) => !permanentMutes[m.did] && !tempMutes[m.did]).map((m) => m.did);
  console.log(
    `[ErgoBlock BG] Fetching viewer states for ${newMuteDids.length} new mutes (skipping ${bskyMutes.length - newMuteDids.length} existing)`
  );
  const viewerStates = newMuteDids.length > 0 ? await fetchViewerStates(auth, newMuteDids) : /* @__PURE__ */ new Map();
  const newPermanentMutes = {};
  for (const mute of bskyMutes) {
    if (tempMutes[mute.did]) {
      continue;
    }
    const viewer = viewerStates.get(mute.did) || permanentMutes[mute.did]?.viewer;
    newPermanentMutes[mute.did] = {
      did: mute.did,
      handle: mute.handle,
      displayName: mute.displayName,
      avatar: mute.avatar,
      syncedAt: permanentMutes[mute.did]?.syncedAt || now,
      viewer
    };
    if (!permanentMutes[mute.did]) {
      added++;
    }
  }
  for (const did of Object.keys(tempMutes)) {
    if (!bskyMuteDids.has(did)) {
      console.log("[ErgoBlock BG] Temp mute removed externally:", tempMutes[did].handle);
      await removeTempMute(did);
      await addHistoryEntry({
        did,
        handle: tempMutes[did].handle,
        action: "unmuted",
        timestamp: now,
        trigger: "removed",
        // User removed externally
        success: true
      });
      removed++;
    }
  }
  await setPermanentMutes(newPermanentMutes);
  return { added, removed };
}
var PLC_DIRECTORY = "https://plc.directory";
var pdsCache = new LRUCache(1e3, 4 * 60 * 60 * 1e3);
async function resolvePdsUrl(did) {
  const cached = pdsCache.get(did);
  if (cached) {
    return cached;
  }
  try {
    const response = await fetch(`${PLC_DIRECTORY}/${did}`);
    if (!response.ok) {
      logger.error(`Failed to resolve DID ${did}: ${response.status}`);
      return null;
    }
    const didDoc = await response.json();
    const pdsService = didDoc.service?.find(
      (s) => s.id === "#atproto_pds" || s.type === "AtprotoPersonalDataServer"
    );
    if (!pdsService?.serviceEndpoint) {
      logger.error(`No PDS service found for ${did}`);
      return null;
    }
    pdsCache.set(did, pdsService.serviceEndpoint);
    return pdsService.serviceEndpoint;
  } catch (error) {
    logger.error(`Error resolving PDS for ${did}:`, error);
    return null;
  }
}
function rawRecordToFeedPost(record, targetDid) {
  return {
    uri: record.uri,
    cid: record.cid,
    author: { did: targetDid, handle: "" },
    // Handle not available from raw records
    record: {
      text: record.value.text,
      createdAt: record.value.createdAt,
      reply: record.value.reply,
      embed: record.value.embed
    }
  };
}
function parsedPostToRawRecord(post, _authorDid) {
  return {
    uri: post.uri,
    cid: post.cid,
    value: {
      $type: "app.bsky.feed.post",
      text: post.text,
      createdAt: post.createdAt,
      reply: post.reply,
      embed: post.embed
    }
  };
}
function isInteractionWithUser(record, loggedInDid, loggedInHandle) {
  const value = record.value;
  if (value.reply?.parent?.uri?.includes(loggedInDid)) {
    return true;
  }
  if (value.embed?.$type === "app.bsky.embed.record" && value.embed.record?.uri?.includes(loggedInDid)) {
    return true;
  }
  if (loggedInHandle && textContainsMention(value.text, loggedInHandle)) {
    return true;
  }
  return false;
}
function isSearchPostInteraction(post, loggedInDid, loggedInHandle) {
  const record = post.record;
  if (record.reply?.parent?.uri?.includes(loggedInDid)) {
    return true;
  }
  if (record.embed?.$type === "app.bsky.embed.record" && record.embed.record?.uri?.includes(loggedInDid)) {
    return true;
  }
  if (loggedInHandle && textContainsMention(record.text, loggedInHandle)) {
    return true;
  }
  return false;
}
async function findBlockContextPost(targetDid, targetHandle, loggedInDid, loggedInHandle, _exhaustive = false) {
  const searchTheirPosts = async () => {
    const pdsUrl = await resolvePdsUrl(targetDid);
    try {
      console.log(`[ErgoBlock BG] Fetching CAR for ${targetDid}...`);
      const repoData = await fetchAndParseRepo(targetDid, pdsUrl);
      console.log(`[ErgoBlock BG] Searching ${repoData.posts.length} posts for ${targetDid}`);
      for (const post of repoData.posts) {
        const record = parsedPostToRawRecord(post, targetDid);
        if (isInteractionWithUser(record, loggedInDid, loggedInHandle)) {
          console.log(`[ErgoBlock BG] Found context (their post) for ${targetDid}: ${post.uri}`);
          return rawRecordToFeedPost(record, targetDid);
        }
      }
      console.log(`[ErgoBlock BG] No interactions in their posts for ${targetDid}`);
      return null;
    } catch (error) {
      console.error(`[ErgoBlock BG] CAR fetch failed for ${targetDid}:`, error);
      return null;
    }
  };
  const searchMyPosts = async () => {
    try {
      const myPosts = await getMyPosts(loggedInDid);
      for (const record of myPosts) {
        if (isInteractionWithUser(record, targetDid, targetHandle)) {
          console.log(`[ErgoBlock BG] Found context (my post) for ${targetDid}: ${record.uri}`);
          return rawRecordToFeedPost(record, loggedInDid);
        }
      }
      console.log(`[ErgoBlock BG] No interactions in my posts for ${targetDid}`);
      return null;
    } catch (error) {
      console.error(`[ErgoBlock BG] Error searching my posts:`, error);
      return null;
    }
  };
  const [theirPost, myPost] = await Promise.all([searchTheirPosts(), searchMyPosts()]);
  if (theirPost !== null && myPost !== null) {
    const theirTime = new Date(theirPost.record.createdAt).getTime();
    const myTime = new Date(myPost.record.createdAt).getTime();
    if (theirTime >= myTime) {
      return { post: theirPost, blockedBy: false };
    } else {
      return { post: myPost, blockedBy: false };
    }
  }
  return { post: theirPost ?? myPost, blockedBy: false };
}
async function findContextWithFallback(targetDid, targetHandle, loggedInDid, loggedInHandle, _exhaustive = false) {
  return findBlockContextPost(targetDid, targetHandle, loggedInDid, loggedInHandle);
}
async function getLoggedInHandle(auth) {
  try {
    const result = await browser_default.storage.local.get("authToken");
    const storedAuth = result.authToken;
    if (storedAuth?.handle) {
      return storedAuth.handle;
    }
    const response = await bgApiRequest(
      `app.bsky.actor.getProfile?actor=${encodeURIComponent(auth.did)}`,
      "GET",
      null,
      auth.accessJwt,
      auth.pdsUrl
    );
    return response?.handle;
  } catch {
    return void 0;
  }
}
async function performFullSync() {
  if (syncMutex.isLocked) {
    logger.info("Sync already in progress, skipping");
    return { success: false, error: "Sync already in progress" };
  }
  return syncMutex.runExclusive(async () => {
    const auth = await getAuthToken();
    if (!auth?.accessJwt || !auth?.did || !auth?.pdsUrl) {
      logger.info("No auth token available, skipping sync");
      return { success: false, error: "Not authenticated" };
    }
    logger.info("Starting full sync with Bluesky...");
    await updateSyncState({ syncInProgress: true, lastError: void 0 });
    try {
      const results = await Promise.allSettled([syncBlocks(auth), syncMutes(auth)]);
      const blockSettled = results[0];
      const muteSettled = results[1];
      const blockResult = blockSettled.status === "fulfilled" ? blockSettled.value : { added: 0, removed: 0, newBlocks: [] };
      const muteResult = muteSettled.status === "fulfilled" ? muteSettled.value : { added: 0, removed: 0 };
      if (blockSettled.status === "rejected") {
        logger.error("Block sync failed:", blockSettled.reason);
      }
      if (muteSettled.status === "rejected") {
        logger.error("Mute sync failed:", muteSettled.reason);
      }
      await updateSyncState({
        syncInProgress: false,
        lastBlockSync: Date.now(),
        lastMuteSync: Date.now(),
        lastError: blockSettled.status === "rejected" || muteSettled.status === "rejected" ? "Partial sync failure" : void 0
      });
      logger.info("Sync complete:", {
        blocks: { added: blockResult.added, removed: blockResult.removed },
        mutes: muteResult
      });
      return {
        success: blockSettled.status === "fulfilled" && muteSettled.status === "fulfilled",
        blocks: { added: blockResult.added, removed: blockResult.removed },
        mutes: muteResult,
        error: blockSettled.status === "rejected" || muteSettled.status === "rejected" ? "Partial sync failure - check console for details" : void 0
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      logger.error("Sync failed:", errorMessage);
      await updateSyncState({
        syncInProgress: false,
        lastError: errorMessage
      });
      return { success: false, error: errorMessage };
    }
  });
}
async function setupSyncAlarm() {
  await browser_default.alarms.clear(SYNC_ALARM_NAME);
  await browser_default.alarms.create(SYNC_ALARM_NAME, {
    periodInMinutes: SYNC_INTERVAL_MINUTES,
    delayInMinutes: 1
    // First sync 1 minute after startup
  });
  console.log("[ErgoBlock BG] Sync alarm set up with interval:", SYNC_INTERVAL_MINUTES, "minutes");
}
var followsCache = { data: null, fetchedAt: 0 };
var followersCache = { data: null, fetchedAt: 0 };
var FOLLOW_CACHE_TTL_MS = 60 * 60 * 1e3;
async function fetchAllFollows(auth) {
  if (followsCache.data && Date.now() - followsCache.fetchedAt < FOLLOW_CACHE_TTL_MS) {
    console.log(`[ErgoBlock BG] Using cached follows (${followsCache.data.length} entries)`);
    return followsCache.data;
  }
  const allFollows = [];
  let cursor;
  do {
    const currentAuth = await getAuthToken() || auth;
    let endpoint = `app.bsky.graph.getFollows?actor=${encodeURIComponent(auth.did)}&limit=100`;
    if (cursor) {
      endpoint += `&cursor=${encodeURIComponent(cursor)}`;
    }
    const response = await bgApiRequest(
      endpoint,
      "GET",
      null,
      currentAuth.accessJwt,
      currentAuth.pdsUrl
    );
    if (response?.follows) {
      allFollows.push(...response.follows);
    }
    cursor = response?.cursor;
    if (cursor) {
      await sleep(PAGINATION_DELAY);
    }
  } while (cursor);
  followsCache.data = allFollows;
  followsCache.fetchedAt = Date.now();
  console.log(`[ErgoBlock BG] Cached ${allFollows.length} follows`);
  return allFollows;
}
async function fetchAllFollowers(auth) {
  if (followersCache.data && Date.now() - followersCache.fetchedAt < FOLLOW_CACHE_TTL_MS) {
    console.log(`[ErgoBlock BG] Using cached followers (${followersCache.data.length} entries)`);
    return followersCache.data;
  }
  const allFollowers = [];
  let cursor;
  do {
    const currentAuth = await getAuthToken() || auth;
    let endpoint = `app.bsky.graph.getFollowers?actor=${encodeURIComponent(auth.did)}&limit=100`;
    if (cursor) {
      endpoint += `&cursor=${encodeURIComponent(cursor)}`;
    }
    const response = await bgApiRequest(
      endpoint,
      "GET",
      null,
      currentAuth.accessJwt,
      currentAuth.pdsUrl
    );
    if (response?.followers) {
      allFollowers.push(...response.followers);
    }
    cursor = response?.cursor;
    if (cursor) {
      await sleep(PAGINATION_DELAY);
    }
  } while (cursor);
  followersCache.data = allFollowers;
  followersCache.fetchedAt = Date.now();
  console.log(`[ErgoBlock BG] Cached ${allFollowers.length} followers`);
  return allFollowers;
}
async function syncFollowsOnly() {
  if (followsSyncMutex.isLocked) {
    logger.info("Follows sync already in progress");
    return;
  }
  await followsSyncMutex.runExclusive(async () => {
    try {
      const auth = await getAuthToken();
      if (!auth?.accessJwt || !auth?.did || !auth?.pdsUrl) {
        logger.info("Not authenticated, skipping follows sync");
        return;
      }
      const existingData = await getFollowsHandles();
      const oneHourAgo = Date.now() - 60 * 60 * 1e3;
      if (existingData.syncedAt > oneHourAgo && existingData.handles.length > 0) {
        logger.info("Follows data is fresh, skipping sync");
        return;
      }
      const existingGraph = await getSocialGraph();
      if (existingGraph.follows.length > 0 || existingGraph.followers.length > 0) {
        logger.info("Clearing old socialGraph to free storage space...");
        await browser_default.storage.local.remove("socialGraph");
      }
      logger.info("Syncing follows for repost filter...");
      const follows = await fetchAllFollows(auth);
      logger.info(`Fetched ${follows.length} follows`);
      const handles = follows.map((f) => f.handle);
      await setFollowsHandles(handles, Date.now());
      logger.info("Follows sync complete");
    } catch (error) {
      logger.error("Follows sync failed:", error);
    }
  });
}
function setupFollowsSyncAlarm() {
  browser_default.alarms.create(FOLLOWS_SYNC_ALARM_NAME, {
    delayInMinutes: 1,
    // First sync after 1 minute (give time for auth)
    periodInMinutes: FOLLOWS_SYNC_INTERVAL_MINUTES
  });
}
async function processClearskyQueue() {
  if (clearskyQueueMutex.isLocked) {
    logger.debug("Clearsky queue processing already in progress");
    return;
  }
  const hasItems = await hasQueuedItems();
  if (!hasItems) {
    return;
  }
  await clearskyQueueMutex.runExclusive(async () => {
    try {
      logger.info("Processing Clearsky blocked-by queue...");
      const processed = await processBlockedByQueue(3);
      if (processed > 0) {
        logger.info(`Processed ${processed} Clearsky queue items`);
      }
    } catch (error) {
      logger.error("Clearsky queue processing failed:", error);
    }
  });
}
function setupClearskyQueueAlarm() {
  browser_default.alarms.create(CLEARSKY_QUEUE_ALARM_NAME, {
    delayInMinutes: 2,
    // First run after 2 minutes
    periodInMinutes: CLEARSKY_QUEUE_INTERVAL_MINUTES
  });
}
async function fetchSubscribedBlocklists(auth) {
  const allLists = [];
  let cursor;
  do {
    let endpoint = "app.bsky.graph.getListBlocks?limit=100";
    if (cursor) {
      endpoint += `&cursor=${encodeURIComponent(cursor)}`;
    }
    const response = await bgApiRequest(
      endpoint,
      "GET",
      null,
      auth.accessJwt,
      auth.pdsUrl
    );
    if (response?.lists) {
      allLists.push(...response.lists);
    }
    cursor = response?.cursor;
    if (cursor) {
      await sleep(PAGINATION_DELAY);
    }
  } while (cursor);
  cursor = void 0;
  do {
    let endpoint = "app.bsky.graph.getListMutes?limit=100";
    if (cursor) {
      endpoint += `&cursor=${encodeURIComponent(cursor)}`;
    }
    const response = await bgApiRequest(
      endpoint,
      "GET",
      null,
      auth.accessJwt,
      auth.pdsUrl
    );
    if (response?.lists) {
      const modlists = response.lists.filter((l) => l.purpose === "app.bsky.graph.defs#modlist");
      allLists.push(...modlists);
    }
    cursor = response?.cursor;
    if (cursor) {
      await sleep(PAGINATION_DELAY);
    }
  } while (cursor);
  return allLists;
}
async function fetchListMembers(auth, listUri) {
  const allMembers = [];
  let cursor;
  do {
    let endpoint = `app.bsky.graph.getList?list=${encodeURIComponent(listUri)}&limit=100`;
    if (cursor) {
      endpoint += `&cursor=${encodeURIComponent(cursor)}`;
    }
    const response = await bgApiRequest(
      endpoint,
      "GET",
      null,
      auth.accessJwt,
      auth.pdsUrl
    );
    if (response?.items) {
      for (const item of response.items) {
        allMembers.push(item.subject);
      }
    }
    cursor = response?.cursor;
    if (cursor) {
      await sleep(PAGINATION_DELAY);
    }
  } while (cursor);
  return allMembers;
}
async function performBlocklistAuditSync() {
  if (blocklistAuditMutex.isLocked) {
    logger.info("Blocklist audit sync already in progress");
    return { success: false, error: "Sync already in progress" };
  }
  return blocklistAuditMutex.runExclusive(async () => {
    const auth = await getAuthToken();
    if (!auth?.accessJwt || !auth?.did || !auth?.pdsUrl) {
      return { success: false, error: "Not authenticated" };
    }
    logger.info("Starting blocklist audit sync...");
    await updateBlocklistAuditState({ syncInProgress: true, lastError: void 0 });
    try {
      logger.info("Fetching follows, followers, and blocklists...");
      const [follows, followers, blocklists] = await Promise.all([
        fetchAllFollows(auth),
        fetchAllFollowers(auth),
        fetchSubscribedBlocklists(auth)
      ]);
      logger.info(
        `Found ${follows.length} follows, ${followers.length} followers, ${blocklists.length} blocklists`
      );
      const followerDids = new Set(followers.map((f) => f.did));
      const allRelations = /* @__PURE__ */ new Map();
      for (const f of follows) {
        allRelations.set(f.did, {
          did: f.did,
          handle: f.handle,
          displayName: f.displayName,
          // avatar intentionally omitted - fetched on-demand in UI
          relationship: followerDids.has(f.did) ? "mutual" : "following"
        });
      }
      for (const f of followers) {
        if (!allRelations.has(f.did)) {
          allRelations.set(f.did, {
            did: f.did,
            handle: f.handle,
            displayName: f.displayName,
            // avatar intentionally omitted - fetched on-demand in UI
            relationship: "follower"
          });
        }
      }
      const followHandles = follows.map((f) => f.handle);
      await setFollowsHandles(followHandles, Date.now());
      logger.info(`Saved ${followHandles.length} follow handles`);
      const storedBlocklists = blocklists.map((l) => ({
        uri: l.uri,
        name: l.name,
        description: l.description,
        // avatar intentionally omitted - fetched on-demand in UI
        creator: {
          did: l.creator.did,
          handle: l.creator.handle,
          displayName: l.creator.displayName
        },
        listItemCount: l.listItemCount,
        syncedAt: Date.now()
      }));
      await setSubscribedBlocklists(storedBlocklists);
      logger.info("Checking blocklists for conflicts...");
      const conflictGroups = [];
      const dismissedLists = await getDismissedConflicts();
      for (const list of blocklists) {
        logger.debug(`Checking list: ${list.name}`);
        const members = await fetchListMembers(auth, list.uri);
        const conflicts = [];
        for (const member of members) {
          const relation = allRelations.get(member.did);
          if (relation) {
            conflicts.push({
              user: relation,
              listUri: list.uri,
              listName: list.name,
              listCreatorHandle: list.creator.handle
            });
          }
        }
        if (conflicts.length > 0) {
          conflictGroups.push({
            list: {
              uri: list.uri,
              name: list.name,
              description: list.description,
              // avatar intentionally omitted - fetched on-demand in UI
              creator: {
                did: list.creator.did,
                handle: list.creator.handle,
                displayName: list.creator.displayName
              },
              listItemCount: list.listItemCount,
              syncedAt: Date.now()
            },
            conflicts,
            dismissed: dismissedLists.has(list.uri)
          });
          logger.info(`Found ${conflicts.length} conflicts in ${list.name}`);
        }
        await sleep(PAGINATION_DELAY);
      }
      await setBlocklistConflicts(conflictGroups);
      const totalConflicts = conflictGroups.reduce((sum, g) => sum + g.conflicts.length, 0);
      await updateBlocklistAuditState({
        syncInProgress: false,
        lastSyncAt: Date.now(),
        followCount: follows.length,
        followerCount: followers.length,
        blocklistCount: blocklists.length,
        conflictCount: totalConflicts
      });
      logger.info(`Blocklist audit complete: ${totalConflicts} conflicts found`);
      return { success: true, conflictCount: totalConflicts };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      logger.error("Blocklist audit sync failed:", errorMessage);
      await updateBlocklistAuditState({
        syncInProgress: false,
        lastError: errorMessage
      });
      return { success: false, error: errorMessage };
    }
  });
}
async function handleUnsubscribeFromBlocklist(listUri) {
  try {
    const auth = await getAuthToken();
    if (!auth?.accessJwt || !auth?.did || !auth?.pdsUrl) {
      return { success: false, error: "Not authenticated" };
    }
    const records = await bgApiRequest(
      `com.atproto.repo.listRecords?repo=${auth.did}&collection=app.bsky.graph.listblock&limit=100`,
      "GET",
      null,
      auth.accessJwt,
      auth.pdsUrl
    );
    const record = records?.records?.find((r) => r.value.subject === listUri);
    if (!record) {
      const muteRecords = await bgApiRequest(
        `com.atproto.repo.listRecords?repo=${auth.did}&collection=app.bsky.graph.listmute&limit=100`,
        "GET",
        null,
        auth.accessJwt,
        auth.pdsUrl
      );
      const muteRecord = muteRecords?.records?.find((r) => r.value.subject === listUri);
      if (!muteRecord) {
        console.log("[ErgoBlock BG] No subscription record found for", listUri);
        return { success: false, error: "Subscription not found" };
      }
      const rkey = muteRecord.uri.split("/").pop();
      if (rkey) {
        await bgApiRequest(
          "com.atproto.repo.deleteRecord",
          "POST",
          {
            repo: auth.did,
            collection: "app.bsky.graph.listmute",
            rkey
          },
          auth.accessJwt,
          auth.pdsUrl
        );
      }
    } else {
      const rkey = record.uri.split("/").pop();
      if (rkey) {
        await bgApiRequest(
          "com.atproto.repo.deleteRecord",
          "POST",
          {
            repo: auth.did,
            collection: "app.bsky.graph.listblock",
            rkey
          },
          auth.accessJwt,
          auth.pdsUrl
        );
      }
    }
    console.log("[ErgoBlock BG] Unsubscribed from blocklist:", listUri);
    return { success: true };
  } catch (error) {
    console.error("[ErgoBlock BG] Unsubscribe failed:", error);
    return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
  }
}
async function handleCopyBlocklistAsIndividualBlocks(listUri) {
  try {
    const auth = await getAuthToken();
    if (!auth?.accessJwt || !auth?.did || !auth?.pdsUrl) {
      return { success: false, error: "Not authenticated" };
    }
    console.log("[ErgoBlock BG] Copying blocklist as individual blocks:", listUri);
    const members = await fetchListMembers(auth, listUri);
    console.log(`[ErgoBlock BG] Found ${members.length} members in blocklist`);
    if (members.length === 0) {
      return { success: true, blocked: 0, skipped: 0 };
    }
    const socialGraph = await getSocialGraph();
    const followDids = new Set(socialGraph.follows.map((f) => f.did));
    console.log(`[ErgoBlock BG] User follows ${followDids.size} accounts`);
    const permanentBlocks = await getPermanentBlocks();
    const tempBlocks = await getTempBlocks();
    const existingBlockDids = /* @__PURE__ */ new Set([
      ...Object.keys(permanentBlocks),
      ...Object.keys(tempBlocks)
    ]);
    console.log(`[ErgoBlock BG] User has ${existingBlockDids.size} existing blocks`);
    let blocked = 0;
    let skipped = 0;
    for (const member of members) {
      if (followDids.has(member.did)) {
        console.log(`[ErgoBlock BG] Skipping ${member.handle} (followed)`);
        skipped++;
        continue;
      }
      if (existingBlockDids.has(member.did)) {
        console.log(`[ErgoBlock BG] Skipping ${member.did} (already blocked)`);
        skipped++;
        continue;
      }
      try {
        const record = {
          $type: "app.bsky.graph.block",
          subject: member.did,
          createdAt: (/* @__PURE__ */ new Date()).toISOString()
        };
        const response = await bgApiRequest(
          "com.atproto.repo.createRecord",
          "POST",
          {
            repo: auth.did,
            collection: "app.bsky.graph.block",
            record
          },
          auth.accessJwt,
          auth.pdsUrl
        );
        if (response) {
          blocked++;
          await addHistoryEntry({
            did: member.did,
            handle: member.handle || member.did,
            action: "blocked",
            timestamp: Date.now(),
            trigger: "manual",
            success: true
          });
        } else {
          skipped++;
        }
        await sleep(100);
      } catch (error) {
        console.error(`[ErgoBlock BG] Failed to block ${member.did}:`, error);
        skipped++;
      }
    }
    console.log(
      `[ErgoBlock BG] Copy blocklist complete: ${blocked} blocked, ${skipped} skipped`
    );
    return { success: true, blocked, skipped };
  } catch (error) {
    console.error("[ErgoBlock BG] Copy blocklist as blocks failed:", error);
    return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
  }
}
var MAX_CONCURRENT_EXPIRATIONS = 5;
async function processExpiredBlock(did, data, auth) {
  console.log("[ErgoBlock BG] Unblocking expired:", data.handle);
  try {
    await unblockUser(did, auth.accessJwt, auth.did, auth.pdsUrl, data.rkey);
    await removeTempBlock(did);
    await addHistoryEntry({
      did,
      handle: data.handle,
      action: "unblocked",
      timestamp: Date.now(),
      trigger: "auto_expire",
      success: true,
      duration: data.createdAt ? Date.now() - data.createdAt : void 0
    });
    console.log("[ErgoBlock BG] Successfully unblocked:", data.handle);
    await sendNotification("expired_success", data.handle, "block");
    return { success: true, authError: false };
  } catch (error) {
    console.error("[ErgoBlock BG] Failed to unblock:", data.handle, error);
    const isAuthError = error instanceof Error && (error.message.includes("401") || error.message.includes("Auth error"));
    if (!isAuthError) {
      await addHistoryEntry({
        did,
        handle: data.handle,
        action: "unblocked",
        timestamp: Date.now(),
        trigger: "auto_expire",
        success: false,
        error: error instanceof Error ? error.message : "Unknown error"
      });
      await sendNotification(
        "expired_failure",
        data.handle,
        "block",
        error instanceof Error ? error.message : "Unknown error"
      );
    }
    return { success: false, authError: isAuthError };
  }
}
async function processExpiredMute(did, data, auth) {
  console.log("[ErgoBlock BG] Unmuting expired:", data.handle);
  try {
    await unmuteUser(did, auth.accessJwt, auth.pdsUrl);
    await removeTempMute(did);
    await addHistoryEntry({
      did,
      handle: data.handle,
      action: "unmuted",
      timestamp: Date.now(),
      trigger: "auto_expire",
      success: true,
      duration: data.createdAt ? Date.now() - data.createdAt : void 0
    });
    console.log("[ErgoBlock BG] Successfully unmuted:", data.handle);
    await sendNotification("expired_success", data.handle, "mute");
    return { success: true, authError: false };
  } catch (error) {
    console.error("[ErgoBlock BG] Failed to unmute:", data.handle, error);
    const isAuthError = error instanceof Error && (error.message.includes("401") || error.message.includes("Auth error"));
    if (!isAuthError) {
      await addHistoryEntry({
        did,
        handle: data.handle,
        action: "unmuted",
        timestamp: Date.now(),
        trigger: "auto_expire",
        success: false,
        error: error instanceof Error ? error.message : "Unknown error"
      });
      await sendNotification(
        "expired_failure",
        data.handle,
        "mute",
        error instanceof Error ? error.message : "Unknown error"
      );
    }
    return { success: false, authError: isAuthError };
  }
}
async function processBatch(items, processor, maxConcurrent) {
  const results = [];
  for (let i = 0; i < items.length; i += maxConcurrent) {
    const batch = items.slice(i, i + maxConcurrent);
    const batchResults = await Promise.all(batch.map(processor));
    results.push(...batchResults);
  }
  return results;
}
async function checkExpirations() {
  console.log("[ErgoBlock BG] Checking expirations...");
  await cleanupExpiredPostContexts();
  let auth = await getAuthToken();
  if (!auth?.accessJwt || !auth?.did || !auth?.pdsUrl) {
    console.log("[ErgoBlock BG] No auth token available, trying to get fresh auth...");
    auth = await requestFreshAuth();
    if (!auth) {
      console.log("[ErgoBlock BG] Could not get auth, skipping check");
      await browser_default.storage.local.set({ authStatus: "invalid" });
      return;
    }
  }
  console.log("[ErgoBlock BG] Using PDS:", auth.pdsUrl);
  const now = Date.now();
  const blocks = await getTempBlocks();
  const mutes = await getTempMutes();
  const expiredBlocks = Object.entries(blocks).filter(([, data]) => data.expiresAt <= now).map(([did, data]) => ({ did, data }));
  const expiredMutes = Object.entries(mutes).filter(([, data]) => data.expiresAt <= now).map(([did, data]) => ({ did, data }));
  console.log(
    `[ErgoBlock BG] Found ${expiredBlocks.length} expired blocks, ${expiredMutes.length} expired mutes`
  );
  let currentAuth = auth;
  if (expiredBlocks.length > 0) {
    let blockResults = await processBatch(
      expiredBlocks,
      ({ did, data }) => processExpiredBlock(did, data, currentAuth),
      MAX_CONCURRENT_EXPIRATIONS
    );
    if (blockResults.some((r) => r.authError)) {
      console.log("[ErgoBlock BG] Auth error during block expiration, requesting fresh auth...");
      const freshAuth = await requestFreshAuth();
      if (freshAuth) {
        currentAuth = freshAuth;
        const failedBlocks = expiredBlocks.filter((_, i) => blockResults[i].authError);
        if (failedBlocks.length > 0) {
          console.log(`[ErgoBlock BG] Retrying ${failedBlocks.length} blocks with fresh auth`);
          const retryResults = await processBatch(
            failedBlocks,
            ({ did, data }) => processExpiredBlock(did, data, currentAuth),
            MAX_CONCURRENT_EXPIRATIONS
          );
          blockResults = retryResults;
        }
      }
    }
    const stillFailed = blockResults.filter((r) => r.authError).length;
    if (stillFailed > 0) {
      console.log(
        `[ErgoBlock BG] ${stillFailed} blocks still failed after retry - will try again on next check`
      );
    }
  }
  if (expiredMutes.length > 0) {
    let muteResults = await processBatch(
      expiredMutes,
      ({ did, data }) => processExpiredMute(did, data, currentAuth),
      MAX_CONCURRENT_EXPIRATIONS
    );
    if (muteResults.some((r) => r.authError)) {
      console.log("[ErgoBlock BG] Auth error during mute expiration, requesting fresh auth...");
      const freshAuth = await requestFreshAuth();
      if (freshAuth) {
        currentAuth = freshAuth;
        const failedMutes = expiredMutes.filter((_, i) => muteResults[i].authError);
        if (failedMutes.length > 0) {
          console.log(`[ErgoBlock BG] Retrying ${failedMutes.length} mutes with fresh auth`);
          const retryResults = await processBatch(
            failedMutes,
            ({ did, data }) => processExpiredMute(did, data, currentAuth),
            MAX_CONCURRENT_EXPIRATIONS
          );
          muteResults = retryResults;
        }
      }
    }
    const stillFailed = muteResults.filter((r) => r.authError).length;
    if (stillFailed > 0) {
      console.log(
        `[ErgoBlock BG] ${stillFailed} mutes still failed after retry - will try again on next check`
      );
    }
  }
  logger.info("Expiration check complete");
  await processPendingRollbacks();
}
async function processPendingRollbacks() {
  const rollbacks = await getProcessableRollbacks();
  if (rollbacks.length === 0) return;
  logger.info(`Processing ${rollbacks.length} pending rollbacks`);
  const authResult = await browser_default.storage.local.get(["authToken"]);
  const auth = authResult.authToken;
  if (!auth?.accessJwt) {
    logger.warn("No auth token available for rollback processing");
    return;
  }
  for (const rollback of rollbacks) {
    try {
      logger.info(`Processing rollback: ${rollback.type} for ${rollback.handle}`);
      if (rollback.type === "unblock") {
        await executeApiRequest(
          `com.atproto.repo.deleteRecord`,
          "POST",
          {
            repo: auth.pdsUrl ? void 0 : rollback.did,
            // Will be set by executeApiRequest
            collection: "app.bsky.graph.block",
            rkey: rollback.rkey
          },
          auth
        );
      } else if (rollback.type === "unmute") {
        await executeApiRequest(
          "app.bsky.graph.unmuteActor",
          "POST",
          { actor: rollback.did },
          auth
        );
      }
      await removePendingRollback(rollback.id);
      logger.info(`Rollback successful for ${rollback.handle}`);
    } catch (error) {
      await updatePendingRollback(rollback.id, {
        attempts: rollback.attempts + 1,
        lastAttempt: Date.now(),
        error: error instanceof Error ? error.message : "Unknown error"
      });
      logger.error(`Rollback failed for ${rollback.handle}:`, error);
    }
  }
  const cleaned = await cleanupOldRollbacks();
  if (cleaned > 0) {
    logger.info(`Cleaned up ${cleaned} old rollbacks`);
  }
}
async function setupAlarm() {
  const options = await getOptions();
  const intervalMinutes = Math.max(1, Math.min(10, options.checkInterval));
  await browser_default.alarms.clear(ALARM_NAME);
  await browser_default.alarms.create(ALARM_NAME, {
    periodInMinutes: intervalMinutes
  });
  console.log("[ErgoBlock BG] Alarm set up with interval:", intervalMinutes, "minutes");
}
var DELAYED_BLOCK_ALARM_PREFIX = "delayed_block_";
browser_default.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === ALARM_NAME) {
    return checkExpirations();
  }
  if (alarm.name === SYNC_ALARM_NAME) {
    return performFullSync();
  }
  if (alarm.name === FOLLOWS_SYNC_ALARM_NAME) {
    return syncFollowsOnly();
  }
  if (alarm.name === CLEARSKY_QUEUE_ALARM_NAME) {
    return processClearskyQueue();
  }
  if (alarm.name.startsWith(DELAYED_BLOCK_ALARM_PREFIX)) {
    const did = alarm.name.slice(DELAYED_BLOCK_ALARM_PREFIX.length);
    return executeDelayedBlock(did);
  }
});
async function handleUnblockRequest(did) {
  try {
    const auth = await getAuthToken();
    if (!auth?.accessJwt || !auth?.did || !auth?.pdsUrl) {
      return { success: false, error: "Not authenticated" };
    }
    const [tempBlocks, permanentBlocks] = await Promise.all([
      getTempBlocks(),
      getPermanentBlocks()
    ]);
    const rkey = tempBlocks[did]?.rkey || permanentBlocks[did]?.rkey;
    await unblockUser(did, auth.accessJwt, auth.did, auth.pdsUrl, rkey);
    return { success: true };
  } catch (error) {
    console.error("[ErgoBlock BG] Unblock failed:", error);
    return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
  }
}
async function handleUnmuteRequest(did) {
  try {
    const auth = await getAuthToken();
    if (!auth?.accessJwt || !auth?.pdsUrl) {
      return { success: false, error: "Not authenticated" };
    }
    await unmuteUser(did, auth.accessJwt, auth.pdsUrl);
    return { success: true };
  } catch (error) {
    console.error("[ErgoBlock BG] Unmute failed:", error);
    return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
  }
}
async function rectifyFailedAmnestyUnblocks() {
  const result = { success: true, checked: 0, fixed: 0, failed: 0, fixedHandles: [] };
  try {
    const auth = await getAuthToken();
    if (!auth?.accessJwt || !auth?.did || !auth?.pdsUrl) {
      console.log("[ErgoBlock BG] Rectify: Not authenticated, skipping");
      return result;
    }
    const reviews = await getAmnestyReviews();
    const unblockedReviews = reviews.filter(
      (r) => r.decision === "unblocked" && r.type === "block"
    );
    if (unblockedReviews.length === 0) {
      console.log("[ErgoBlock BG] Rectify: No unblocked reviews to check");
      return result;
    }
    console.log(`[ErgoBlock BG] Rectify: Checking ${unblockedReviews.length} amnesty unblocks...`);
    const blockedDids = /* @__PURE__ */ new Set();
    const blockRkeys = /* @__PURE__ */ new Map();
    let cursor;
    do {
      const url = cursor ? `com.atproto.repo.listRecords?repo=${auth.did}&collection=app.bsky.graph.block&limit=100&cursor=${cursor}` : `com.atproto.repo.listRecords?repo=${auth.did}&collection=app.bsky.graph.block&limit=100`;
      const blocks = await bgApiRequest(url, "GET", null, auth.accessJwt, auth.pdsUrl);
      for (const record of blocks?.records || []) {
        const did = record.value.subject;
        const rkey = record.uri.split("/").pop();
        blockedDids.add(did);
        if (rkey) {
          blockRkeys.set(did, rkey);
        }
      }
      cursor = blocks?.cursor;
    } while (cursor);
    const failedUnblocks = unblockedReviews.filter((r) => blockedDids.has(r.did));
    result.checked = unblockedReviews.length;
    if (failedUnblocks.length === 0) {
      console.log("[ErgoBlock BG] Rectify: All amnesty unblocks were successful");
      return result;
    }
    console.log(`[ErgoBlock BG] Rectify: Found ${failedUnblocks.length} failed unblocks, fixing...`);
    for (const review of failedUnblocks) {
      const rkey = blockRkeys.get(review.did);
      if (!rkey) {
        console.log(`[ErgoBlock BG] Rectify: No rkey for @${review.handle}, skipping`);
        result.failed++;
        continue;
      }
      try {
        await bgApiRequest(
          "com.atproto.repo.deleteRecord",
          "POST",
          {
            repo: auth.did,
            collection: "app.bsky.graph.block",
            rkey
          },
          auth.accessJwt,
          auth.pdsUrl
        );
        await Promise.all([removeTempBlock(review.did), removePermanentBlock(review.did)]);
        console.log(`[ErgoBlock BG] Rectify: Unblocked @${review.handle}`);
        result.fixed++;
        result.fixedHandles.push(review.handle);
      } catch (error) {
        console.error(`[ErgoBlock BG] Rectify: Failed to unblock @${review.handle}:`, error);
        result.failed++;
      }
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
    if (result.fixed > 0) {
      const options = await getOptions();
      if (options.notificationSound !== void 0) {
        const handleList = result.fixedHandles.slice(0, 3).map((h) => `@${h}`).join(", ");
        const suffix = result.fixed > 3 ? ` and ${result.fixed - 3} more` : "";
        await browser_default.notifications.create({
          type: "basic",
          iconUrl: "icons/icon128.png",
          title: "\u2713 Amnesty unblocks fixed",
          message: `Successfully unblocked ${handleList}${suffix}`,
          silent: !options.notificationSound
        });
      }
    }
    console.log(`[ErgoBlock BG] Rectify complete: ${result.fixed} fixed, ${result.failed} failed`);
    return result;
  } catch (error) {
    console.error("[ErgoBlock BG] Rectify error:", error);
    return result;
  }
}
async function handleTempUnblockForView(did) {
  try {
    const auth = await getAuthToken();
    if (!auth?.accessJwt || !auth?.did || !auth?.pdsUrl) {
      return { success: false, error: "Not authenticated" };
    }
    const permanentBlocks = await getPermanentBlocks();
    const blockData = permanentBlocks[did];
    const rkey = blockData?.rkey;
    console.log(
      "[ErgoBlock BG] Permanent block data for",
      did,
      ":",
      blockData ? { rkey: blockData.rkey, handle: blockData.handle } : "not found"
    );
    const tempBlocks = await getTempBlocks();
    const tempBlockData = tempBlocks[did];
    const tempRkey = tempBlockData?.rkey;
    console.log(
      "[ErgoBlock BG] Temp block data for",
      did,
      ":",
      tempBlockData ? { rkey: tempBlockData.rkey, handle: tempBlockData.handle } : "not found"
    );
    const rkeyToUse = rkey || tempRkey;
    console.log("[ErgoBlock BG] Using rkey:", rkeyToUse || "(none - will scan)");
    await unblockUser(did, auth.accessJwt, auth.did, auth.pdsUrl, rkeyToUse);
    console.log("[ErgoBlock BG] Temp unblocked for viewing:", did);
    return { success: true };
  } catch (error) {
    console.error("[ErgoBlock BG] Temp unblock for view failed:", error);
    return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
  }
}
async function handleReblockUser(did) {
  try {
    const auth = await getAuthToken();
    if (!auth?.accessJwt || !auth?.did || !auth?.pdsUrl) {
      return { success: false, error: "Not authenticated" };
    }
    const result = await blockUser(did, auth.accessJwt, auth.did, auth.pdsUrl);
    console.log("[ErgoBlock BG] Re-blocked user:", did, "result:", result);
    if (result) {
      const rkey = result.uri.split("/").pop();
      if (rkey) {
        const permanentBlocks = await getPermanentBlocks();
        if (permanentBlocks[did]) {
          permanentBlocks[did].rkey = rkey;
          await setPermanentBlocks(permanentBlocks);
        }
      }
    }
    return { success: true };
  } catch (error) {
    console.error("[ErgoBlock BG] Reblock failed:", error);
    return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
  }
}
async function handleFindContext(did, handle) {
  try {
    const auth = await getAuthToken();
    if (!auth?.accessJwt || !auth?.did || !auth?.pdsUrl) {
      return { success: false, error: "Not authenticated" };
    }
    const existingContexts = await getPostContexts();
    if (existingContexts.some((c) => c.targetDid === did)) {
      return { success: true, found: true };
    }
    const loggedInHandle = await getLoggedInHandle(auth);
    const result = await findContextWithFallback(did, handle, auth.did, loggedInHandle, true);
    if (result.post) {
      await addPostContext({
        id: generateId("manual"),
        postUri: result.post.uri,
        postAuthorDid: result.post.author.did,
        postAuthorHandle: result.post.author.handle || handle,
        postText: result.post.record.text,
        postCreatedAt: new Date(result.post.record.createdAt).getTime(),
        targetHandle: handle,
        targetDid: did,
        actionType: "block",
        permanent: true,
        timestamp: Date.now(),
        guessed: true
        // Mark as auto-detected since it was found, not captured during block
      });
      console.log(`[ErgoBlock BG] Manually found context for: ${handle}`);
      return { success: true, found: true };
    }
    console.log(`[ErgoBlock BG] No context found for: ${handle}`);
    return { success: true, found: false };
  } catch (error) {
    console.error("[ErgoBlock BG] Find context failed:", error);
    return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
  }
}
async function handleScheduleDelayedBlock(did, handle, blockDurationMs, permanent, delaySeconds, mutedFirst) {
  try {
    const clampedDelay = Math.max(10, Math.min(3600, delaySeconds));
    const entry = {
      did,
      handle,
      blockDurationMs,
      executeAt: Date.now() + clampedDelay * 1e3,
      permanent,
      mutedFirst
    };
    await addPendingDelayedBlock(entry);
    const alarmName = `${DELAYED_BLOCK_ALARM_PREFIX}${did}`;
    await browser_default.alarms.create(alarmName, {
      when: entry.executeAt
    });
    console.log(
      `[ErgoBlock BG] Scheduled delayed block for @${handle} in ${clampedDelay}s (permanent: ${permanent})`
    );
    return { success: true, delaySeconds: clampedDelay };
  } catch (error) {
    console.error("[ErgoBlock BG] Failed to schedule delayed block:", error);
    return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
  }
}
async function executeDelayedBlock(did) {
  try {
    const entry = await getPendingDelayedBlock(did);
    if (!entry) {
      console.log("[ErgoBlock BG] No pending delayed block found for:", did);
      return;
    }
    const auth = await getAuthToken();
    if (!auth?.accessJwt || !auth?.did || !auth?.pdsUrl) {
      console.error("[ErgoBlock BG] Not authenticated for delayed block execution");
      return;
    }
    const options = await getOptions();
    if (entry.mutedFirst && options.lastWordMuteEnabled) {
      try {
        await unmuteUser(did, auth.accessJwt, auth.pdsUrl);
        console.log("[ErgoBlock BG] Last Word: Unmuted user before block:", entry.handle);
      } catch (unmuteErr) {
        console.error("[ErgoBlock BG] Failed to unmute before block:", unmuteErr);
      }
    }
    const blockResult = await blockUser(did, auth.accessJwt, auth.did, auth.pdsUrl);
    console.log("[ErgoBlock BG] Last Word: Blocked user:", entry.handle, "result:", blockResult);
    if (!entry.permanent && entry.blockDurationMs > 0) {
      let rkey;
      if (blockResult?.uri) {
        const parts = blockResult.uri.split("/");
        rkey = parts[parts.length - 1];
      }
      await addTempBlock(did, entry.handle, entry.blockDurationMs, rkey);
      console.log(
        "[ErgoBlock BG] Last Word: Added temp block for",
        entry.handle,
        "duration:",
        entry.blockDurationMs
      );
    }
    await addHistoryEntry({
      did,
      handle: entry.handle,
      action: "blocked",
      timestamp: Date.now(),
      trigger: "manual",
      // It was initiated manually, just delayed
      success: true,
      duration: entry.permanent ? void 0 : entry.blockDurationMs
    });
    await removePendingDelayedBlock(did);
    console.log("[ErgoBlock BG] Last Word: Block executed successfully for:", entry.handle);
  } catch (error) {
    console.error("[ErgoBlock BG] Failed to execute delayed block:", error);
    await removePendingDelayedBlock(did);
  }
}
function classifyRawInteractionType(record, otherDid) {
  const value = record.value;
  if (value.reply?.parent?.uri?.includes(otherDid)) {
    return "reply";
  }
  if (value.embed?.$type === "app.bsky.embed.record" && value.embed.record?.uri?.includes(otherDid)) {
    return "quote";
  }
  return "mention";
}
var myPostsCache = null;
var MY_POSTS_CACHE_TTL = 60 * 60 * 1e3;
async function getMyPosts(loggedInDid) {
  if (myPostsCache && myPostsCache.did === loggedInDid && Date.now() - myPostsCache.fetchedAt < MY_POSTS_CACHE_TTL) {
    console.log(
      `[ErgoBlock BG] Using cached posts for logged-in user (${myPostsCache.posts.length} posts)`
    );
    return myPostsCache.posts;
  }
  console.log("[ErgoBlock BG] Fetching logged-in user posts via CAR...");
  const pdsUrl = await resolvePdsUrl(loggedInDid);
  try {
    const repoData = await fetchAndParseRepo(loggedInDid, pdsUrl);
    const posts = repoData.posts.map((post) => parsedPostToRawRecord(post, loggedInDid));
    console.log(`[ErgoBlock BG] Cached ${posts.length} posts for logged-in user (via CAR)`);
    myPostsCache = { did: loggedInDid, posts, fetchedAt: repoData.fetchedAt };
    return posts;
  } catch (error) {
    console.error("[ErgoBlock BG] CAR fetch failed for logged-in user:", error);
    return [];
  }
}
async function findAllInteractions(targetDid, targetHandle, loggedInDid, loggedInHandle) {
  console.log(
    `[ErgoBlock BG] Finding all interactions via CAR: ${targetHandle} <-> ${loggedInHandle || loggedInDid}`
  );
  const interactions = [];
  const seenUris = /* @__PURE__ */ new Set();
  const fetchTargetPosts = async () => {
    const pdsUrl = await resolvePdsUrl(targetDid);
    try {
      console.log(`[ErgoBlock BG] Fetching CAR for ${targetHandle}...`);
      const repoData = await fetchAndParseRepo(targetDid, pdsUrl);
      let foundCount = 0;
      for (const post of repoData.posts) {
        if (seenUris.has(post.uri)) continue;
        const record = parsedPostToRawRecord(post, targetDid);
        if (isInteractionWithUser(record, loggedInDid, loggedInHandle)) {
          seenUris.add(post.uri);
          foundCount++;
          interactions.push({
            uri: post.uri,
            text: post.text.slice(0, 300),
            createdAt: new Date(post.createdAt).getTime(),
            type: classifyRawInteractionType(record, loggedInDid),
            author: "them",
            authorHandle: targetHandle
          });
        }
      }
      console.log(
        `[ErgoBlock BG] ${targetHandle}: searched ${repoData.posts.length} posts, found ${foundCount} interactions`
      );
    } catch (error) {
      console.error(`[ErgoBlock BG] CAR fetch failed for ${targetHandle}:`, error);
    }
  };
  const searchMyPosts = async () => {
    const myPosts = await getMyPosts(loggedInDid);
    let foundCount = 0;
    for (const record of myPosts) {
      if (seenUris.has(record.uri)) continue;
      if (isInteractionWithUser(record, targetDid, targetHandle)) {
        seenUris.add(record.uri);
        foundCount++;
        interactions.push({
          uri: record.uri,
          text: record.value.text.slice(0, 300),
          createdAt: new Date(record.value.createdAt).getTime(),
          type: classifyRawInteractionType(record, targetDid),
          author: "you",
          authorHandle: loggedInHandle || loggedInDid
        });
      }
    }
    console.log(
      `[ErgoBlock BG] ${loggedInHandle || "you"}: searched ${myPosts.length} cached posts, found ${foundCount} interactions`
    );
  };
  try {
    await Promise.all([fetchTargetPosts(), searchMyPosts()]);
    interactions.sort((a, b) => b.createdAt - a.createdAt);
    console.log(`[ErgoBlock BG] Found ${interactions.length} total interactions`);
    return interactions;
  } catch (error) {
    console.error("[ErgoBlock BG] findAllInteractions error:", error);
    return [];
  }
}
async function handleFetchAllInteractions(did, handle) {
  try {
    const auth = await getAuthToken();
    if (!auth?.accessJwt || !auth?.did || !auth?.pdsUrl) {
      console.log("[ErgoBlock BG] FETCH_ALL_INTERACTIONS: Not authenticated");
      return { success: false, error: "Not authenticated" };
    }
    const loggedInHandle = await getLoggedInHandle(auth);
    console.log(
      `[ErgoBlock BG] FETCH_ALL_INTERACTIONS: ${handle} (${did}) <-> ${loggedInHandle} (${auth.did})`
    );
    const interactions = await findAllInteractions(did, handle, auth.did, loggedInHandle);
    console.log(
      `[ErgoBlock BG] FETCH_ALL_INTERACTIONS: Returning ${interactions.length} interactions`
    );
    return { success: true, interactions };
  } catch (error) {
    console.error("[ErgoBlock BG] Fetch all interactions failed:", error);
    return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
  }
}
async function handleFetchOwnedLists() {
  try {
    const auth = await getAuthToken();
    if (!auth?.accessJwt || !auth?.did || !auth?.pdsUrl) {
      return { success: false, error: "Not authenticated" };
    }
    console.log("[ErgoBlock BG] Fetching owned lists from CAR...");
    const result = await fetchListsFromCar(auth.did, auth.pdsUrl);
    const ownedLists = Object.values(result.lists).map((list) => ({
      uri: list.uri,
      name: list.name,
      purpose: list.purpose === "app.bsky.graph.defs#modlist" ? "modlist" : "curatelist",
      description: list.description,
      listItemCount: list.members.length,
      createdAt: list.createdAt
    }));
    console.log(`[ErgoBlock BG] Fetched ${ownedLists.length} owned lists from CAR`);
    return { success: true, lists: ownedLists };
  } catch (error) {
    console.error("[ErgoBlock BG] Fetch owned lists failed:", error);
    return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
  }
}
async function handleFetchListMembersWithTimestamps(listUri) {
  try {
    const auth = await getAuthToken();
    if (!auth?.accessJwt || !auth?.did || !auth?.pdsUrl) {
      return { success: false, error: "Not authenticated" };
    }
    const listResponse = await executeApiRequest(
      `app.bsky.graph.getList?list=${encodeURIComponent(listUri)}&limit=1`,
      "GET",
      null,
      { accessJwt: auth.accessJwt, pdsUrl: auth.pdsUrl }
    );
    const listName = listResponse?.list?.name || "Unknown List";
    const targetListUris = /* @__PURE__ */ new Set([listUri]);
    const parsedLists = await fetchListsFromCarWithTimestamps(
      auth.did,
      auth.pdsUrl,
      targetListUris
    );
    const parsedList = parsedLists.lists[listUri];
    if (!parsedList || parsedList.members.length === 0) {
      return { success: true, members: [] };
    }
    const memberDids = parsedList.members.map((m) => m.did);
    const profiles = await fetchProfiles(memberDids, auth.accessJwt);
    const profileMap = new Map(profiles.map((p) => [p.did, p]));
    const members = parsedList.members.map((m) => {
      const profile = profileMap.get(m.did);
      return {
        did: m.did,
        handle: profile?.handle || m.did,
        displayName: profile?.displayName,
        avatar: profile?.avatar,
        listUri,
        listName,
        addedAt: m.addedAt,
        listitemRkey: m.rkey
      };
    });
    members.sort((a, b) => b.addedAt - a.addedAt);
    console.log(`[ErgoBlock BG] Fetched ${members.length} members with timestamps for ${listName}`);
    return { success: true, members };
  } catch (error) {
    console.error("[ErgoBlock BG] Fetch list members with timestamps failed:", error);
    return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
  }
}
async function handleRemoveFromList(rkey) {
  try {
    const auth = await getAuthToken();
    if (!auth?.accessJwt || !auth?.did || !auth?.pdsUrl) {
      return { success: false, error: "Not authenticated" };
    }
    await executeApiRequest(
      "com.atproto.repo.deleteRecord",
      "POST",
      {
        repo: auth.did,
        collection: "app.bsky.graph.listitem",
        rkey
      },
      { accessJwt: auth.accessJwt, pdsUrl: auth.pdsUrl }
    );
    console.log(`[ErgoBlock BG] Removed list item with rkey: ${rkey}`);
    return { success: true };
  } catch (error) {
    console.error("[ErgoBlock BG] Remove from list failed:", error);
    return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
  }
}
async function handleFindInteractionsBefore(targetDid, beforeTimestamp) {
  try {
    const auth = await getAuthToken();
    if (!auth?.accessJwt || !auth?.did || !auth?.pdsUrl) {
      return { success: false, error: "Not authenticated" };
    }
    const profiles = await fetchProfiles([targetDid], auth.accessJwt);
    const targetHandle = profiles[0]?.handle || targetDid;
    const loggedInHandle = await getLoggedInHandle(auth);
    const allInteractions = await findAllInteractions(
      targetDid,
      targetHandle,
      auth.did,
      loggedInHandle
    );
    const filteredInteractions = allInteractions.filter((i) => i.createdAt < beforeTimestamp);
    console.log(
      `[ErgoBlock BG] Found ${filteredInteractions.length} interactions before ${new Date(beforeTimestamp).toISOString()}`
    );
    return { success: true, interactions: filteredInteractions };
  } catch (error) {
    console.error("[ErgoBlock BG] Find interactions before failed:", error);
    return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
  }
}
async function fetchCandidateFollowers(candidateDid) {
  const followerDids = /* @__PURE__ */ new Set();
  let cursor;
  do {
    let url = `https://public.api.bsky.app/xrpc/app.bsky.graph.getFollowers?actor=${encodeURIComponent(candidateDid)}&limit=100`;
    if (cursor) {
      url += `&cursor=${encodeURIComponent(cursor)}`;
    }
    try {
      const response = await fetch(url);
      if (!response.ok) break;
      const data = await response.json();
      if (data.followers) {
        for (const f of data.followers) {
          followerDids.add(f.did);
        }
      }
      cursor = data.cursor;
      if (cursor) {
        await sleep(PAGINATION_DELAY);
      }
    } catch {
      break;
    }
  } while (cursor);
  return followerDids;
}
async function fetchCandidateBlocks(candidateDid) {
  try {
    const pdsUrl = await resolvePdsUrl(candidateDid);
    console.log(`[ErgoBlock BG] Fetching CAR for ${candidateDid} to get their blocks...`);
    const repoData = await fetchAndParseRepo(candidateDid, pdsUrl);
    console.log(`[ErgoBlock BG] Candidate ${candidateDid} blocks ${repoData.blocks.length} people:`, repoData.blocks.slice(0, 5));
    return new Set(repoData.blocks);
  } catch (error) {
    console.error(`[ErgoBlock BG] Failed to fetch candidate blocks:`, error);
    return /* @__PURE__ */ new Set();
  }
}
async function handleGetFollowRelationships(candidateDid) {
  try {
    const auth = await getAuthToken();
    if (!auth?.accessJwt || !auth?.did || !auth?.pdsUrl) {
      return { success: false, error: "Not authenticated" };
    }
    console.log(`[ErgoBlock BG] Fetching follow relationships for ${candidateDid}`);
    const [myFollows, myFollowers, candidateFollowers, candidateBlocks] = await Promise.all([
      fetchAllFollows(auth),
      fetchAllFollowers(auth),
      fetchCandidateFollowers(candidateDid),
      fetchCandidateBlocks(candidateDid)
    ]);
    console.log(
      `[ErgoBlock BG] Got ${myFollows.length} follows, ${myFollowers.length} followers, candidate has ${candidateFollowers.size} followers and ${candidateBlocks.size} blocks`
    );
    const followsWhoFollowThem = [];
    const followersWhoFollowThem = [];
    const followsTheyBlock = [];
    for (const f of myFollows) {
      if (candidateFollowers.has(f.did)) {
        followsWhoFollowThem.push({
          did: f.did,
          handle: f.handle,
          displayName: f.displayName,
          avatar: f.avatar
        });
      }
      if (candidateBlocks.has(f.did)) {
        followsTheyBlock.push({
          did: f.did,
          handle: f.handle,
          displayName: f.displayName,
          avatar: f.avatar
        });
      }
    }
    for (const f of myFollowers) {
      if (candidateFollowers.has(f.did)) {
        followersWhoFollowThem.push({
          did: f.did,
          handle: f.handle,
          displayName: f.displayName,
          avatar: f.avatar
        });
      }
    }
    console.log(
      `[ErgoBlock BG] Follow relationships: ${followsWhoFollowThem.length} follows follow them, ${followersWhoFollowThem.length} followers follow them, ${followsTheyBlock.length} follows they block`
    );
    return {
      success: true,
      followsWhoFollowThem,
      followersWhoFollowThem,
      followsTheyBlock
    };
  } catch (error) {
    console.error("[ErgoBlock BG] Get follow relationships failed:", error);
    return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
  }
}
async function handleGetFollowsWhoFollowThem(candidateDid) {
  try {
    const auth = await getAuthToken();
    if (!auth?.accessJwt || !auth?.did || !auth?.pdsUrl) {
      return { success: false, error: "Not authenticated" };
    }
    const [myFollows, candidateFollowers] = await Promise.all([
      fetchAllFollows(auth),
      fetchCandidateFollowers(candidateDid)
    ]);
    const users = [];
    for (const f of myFollows) {
      if (candidateFollowers.has(f.did)) {
        users.push({
          did: f.did,
          handle: f.handle,
          displayName: f.displayName,
          avatar: f.avatar
        });
      }
    }
    console.log(`[ErgoBlock BG] Follows who follow them: ${users.length}`);
    return { success: true, users };
  } catch (error) {
    console.error("[ErgoBlock BG] Get follows who follow them failed:", error);
    return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
  }
}
async function handleGetFollowersWhoFollowThem(candidateDid) {
  try {
    const auth = await getAuthToken();
    if (!auth?.accessJwt || !auth?.did || !auth?.pdsUrl) {
      return { success: false, error: "Not authenticated" };
    }
    const [myFollowers, candidateFollowers] = await Promise.all([
      fetchAllFollowers(auth),
      fetchCandidateFollowers(candidateDid)
    ]);
    const users = [];
    for (const f of myFollowers) {
      if (candidateFollowers.has(f.did)) {
        users.push({
          did: f.did,
          handle: f.handle,
          displayName: f.displayName,
          avatar: f.avatar
        });
      }
    }
    console.log(`[ErgoBlock BG] Followers who follow them: ${users.length}`);
    return { success: true, users };
  } catch (error) {
    console.error("[ErgoBlock BG] Get followers who follow them failed:", error);
    return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
  }
}
async function handleGetFollowsTheyBlock(candidateDid) {
  try {
    const auth = await getAuthToken();
    if (!auth?.accessJwt || !auth?.did || !auth?.pdsUrl) {
      return { success: false, error: "Not authenticated" };
    }
    const [myFollows, candidateBlocks] = await Promise.all([
      fetchAllFollows(auth),
      fetchCandidateBlocks(candidateDid)
    ]);
    const users = [];
    for (const f of myFollows) {
      if (candidateBlocks.has(f.did)) {
        users.push({
          did: f.did,
          handle: f.handle,
          displayName: f.displayName,
          avatar: f.avatar
        });
      }
    }
    console.log(`[ErgoBlock BG] Follows they block: ${users.length}`, users.map((u) => u.handle));
    return { success: true, users };
  } catch (error) {
    console.error("[ErgoBlock BG] Get follows they block failed:", error);
    return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
  }
}
async function handleGetFollowsWhoBlockThem(candidateDid) {
  try {
    const auth = await getAuthToken();
    if (!auth?.accessJwt || !auth?.did || !auth?.pdsUrl) {
      return { success: false, error: "Not authenticated" };
    }
    const myFollows = await fetchAllFollows(auth);
    const myFollowDids = new Set(myFollows.map((f) => f.did));
    const result = await getFollowsWhoBlock(candidateDid, myFollowDids);
    const users = [];
    for (const did of result.dids) {
      const follow = myFollows.find((f) => f.did === did);
      if (follow) {
        users.push({
          did: follow.did,
          handle: follow.handle,
          displayName: follow.displayName,
          avatar: follow.avatar
        });
      }
    }
    console.log(
      `[ErgoBlock BG] Follows who block them: ${result.count} (total blockers: ${result.totalBlockers}, cached: ${result.cached})`,
      users.map((u) => u.handle)
    );
    return {
      success: true,
      count: result.count,
      users,
      totalBlockers: result.totalBlockers,
      cached: result.cached
    };
  } catch (error) {
    console.error("[ErgoBlock BG] Get follows who block them failed:", error);
    return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
  }
}
async function handleGetFollowsWhoBlockThemCached(candidateDid) {
  try {
    const auth = await getAuthToken();
    if (!auth?.accessJwt || !auth?.did) {
      return { success: false, cached: false, error: "Not authenticated" };
    }
    const myFollows = await fetchAllFollows(auth);
    const myFollowDids = new Set(myFollows.map((f) => f.did));
    const result = await getFollowsWhoBlockCached(candidateDid, myFollowDids);
    if (!result) {
      return { success: true, cached: false };
    }
    return {
      success: true,
      count: result.count,
      cached: true
    };
  } catch (error) {
    console.error("[ErgoBlock BG] Get cached follows who block failed:", error);
    return {
      success: false,
      cached: false,
      error: error instanceof Error ? error.message : "Unknown error"
    };
  }
}
async function handlePrewarmClearskyCache(targetDids) {
  try {
    const result = await prewarmBlockedByCache(targetDids);
    console.log(
      `[ErgoBlock BG] Prewarm Clearsky: ${result.queued} queued, ${result.alreadyCached} cached`
    );
    if (result.queued > 0) {
      processBlockedByQueue(3).catch((err) => {
        console.error("[ErgoBlock BG] Immediate queue processing failed:", err);
      });
    }
    return { success: true, ...result };
  } catch (error) {
    console.error("[ErgoBlock BG] Prewarm Clearsky cache failed:", error);
    return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
  }
}
async function handleScanMassOps(settings, forceRefresh = false) {
  try {
    const auth = await getAuthToken();
    if (!auth?.accessJwt || !auth?.did || !auth?.pdsUrl) {
      return { success: false, error: "Not authenticated" };
    }
    console.log("[ErgoBlock BG] Starting mass ops scan with settings:", settings);
    const result = await getGraphOperationsSmart({
      did: auth.did,
      pdsUrl: auth.pdsUrl,
      forceRefresh,
      preferCache: !forceRefresh,
      onProgress: async (progress) => {
        console.log(`[ErgoBlock BG] Mass ops scan: ${progress.message}`);
        await setCarDownloadProgress({
          did: progress.did,
          stage: progress.stage,
          bytesDownloaded: progress.bytesDownloaded,
          bytesTotal: progress.bytesTotal,
          percentComplete: progress.percentComplete,
          message: progress.message,
          isIncremental: progress.isIncremental,
          startedAt: progress.startedAt,
          error: progress.error
        });
      }
    });
    const allClusters = detectMassOperations(
      {
        blocks: result.blocks,
        follows: result.follows,
        listitems: result.listitems
      },
      settings
    );
    const dismissedClusters = await getDismissedMassOpsClusters();
    const clusters = allClusters.filter(
      (cluster) => !isClusterDismissed(cluster, dismissedClusters)
    );
    await saveMassOpsScanResult({
      clusters,
      scannedAt: Date.now(),
      operationCounts: {
        blocks: result.blocks.length,
        follows: result.follows.length,
        listitems: result.listitems.length
      }
    });
    await clearCarDownloadProgress();
    console.log(
      `[ErgoBlock BG] Mass ops scan complete: ${clusters.length} clusters found, ${result.blocks.length} blocks, ${result.follows.length} follows, ${result.listitems.length} list items (cached: ${result.wasCached}, incremental: ${result.wasIncremental})`
    );
    return { success: true };
  } catch (error) {
    console.error("[ErgoBlock BG] Mass ops scan failed:", error);
    await clearCarDownloadProgress();
    return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
  }
}
async function handleUndoMassOperations(operations) {
  const auth = await getAuthToken();
  if (!auth?.accessJwt || !auth?.did || !auth?.pdsUrl) {
    return { success: false, undone: 0, failed: operations.length, errors: ["Not authenticated"] };
  }
  let undone = 0;
  let failed = 0;
  const errors = [];
  console.log(`[ErgoBlock BG] Undoing ${operations.length} mass operations`);
  for (const op of operations) {
    try {
      const collection = op.type === "block" ? "app.bsky.graph.block" : op.type === "follow" ? "app.bsky.graph.follow" : "app.bsky.graph.listitem";
      const response = await bgApiRequest(
        "com.atproto.repo.deleteRecord",
        "POST",
        {
          repo: auth.did,
          collection,
          rkey: op.rkey
        },
        auth.accessJwt,
        auth.pdsUrl
      );
      if (response) {
        undone++;
        if (op.type === "block" || op.type === "follow") {
          await addHistoryEntry({
            did: op.did,
            handle: op.did,
            // We don't have handle here, use DID
            action: op.type === "block" ? "unblocked" : "unblocked",
            // Use unblocked for follows too
            timestamp: Date.now(),
            trigger: "manual",
            success: true
          });
        }
      } else {
        failed++;
        errors.push(`Failed to delete ${op.type} for ${op.did}`);
      }
      await sleep(350);
    } catch (error) {
      failed++;
      const errorMsg = error instanceof Error ? error.message : "Unknown error";
      errors.push(`${op.type} ${op.did}: ${errorMsg}`);
      console.error(`[ErgoBlock BG] Failed to undo ${op.type} for ${op.did}:`, error);
    }
  }
  console.log(`[ErgoBlock BG] Mass ops undo complete: ${undone} undone, ${failed} failed`);
  return { success: failed === 0, undone, failed, errors };
}
async function handleFetchCopyUserData(handle) {
  console.log(`[ErgoBlock BG] Fetching Copy User data for: ${handle}`);
  try {
    const profile = await bgApiRequestPublic(
      `app.bsky.actor.getProfile?actor=${encodeURIComponent(handle)}`
    );
    if (!profile) {
      return { success: false, error: `User not found: ${handle}` };
    }
    const targetDid = profile.did;
    console.log(`[ErgoBlock BG] Resolved ${handle} to DID: ${targetDid}`);
    const pdsUrl = await resolvePdsUrl(targetDid);
    console.log(`[ErgoBlock BG] Target PDS: ${pdsUrl || "using relay"}`);
    const graphData = await fetchExternalUserGraph(targetDid, pdsUrl, (message) => {
      console.log(`[ErgoBlock BG] Copy User progress: ${message}`);
    });
    console.log(
      `[ErgoBlock BG] Found ${graphData.follows.length} follows, ${graphData.blocks.length} blocks`
    );
    return {
      success: true,
      did: targetDid,
      profile,
      follows: graphData.follows,
      blocks: graphData.blocks
    };
  } catch (error) {
    console.error("[ErgoBlock BG] Failed to fetch Copy User data:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Unknown error"
    };
  }
}
async function handleExecuteCopyUserFollows(dids) {
  const auth = await getAuthToken();
  if (!auth?.accessJwt || !auth?.did || !auth?.pdsUrl) {
    return { success: false, error: "Not authenticated" };
  }
  console.log(`[ErgoBlock BG] Executing Copy User follows for ${dids.length} users`);
  console.log("[ErgoBlock BG] Fetching existing follows to avoid duplicates...");
  const existingFollows = await fetchAllFollows(auth);
  const existingFollowDids = new Set(existingFollows.map((f) => f.did));
  console.log(`[ErgoBlock BG] Found ${existingFollowDids.size} existing follows`);
  const didsToFollow = dids.filter((did) => !existingFollowDids.has(did));
  const alreadyFollowing = dids.length - didsToFollow.length;
  if (alreadyFollowing > 0) {
    console.log(`[ErgoBlock BG] Skipping ${alreadyFollowing} users already followed`);
  }
  if (didsToFollow.length === 0) {
    console.log("[ErgoBlock BG] All selected users are already followed");
    return { success: true, succeeded: 0, failed: 0, errors: [], skipped: alreadyFollowing };
  }
  console.log(`[ErgoBlock BG] Will follow ${didsToFollow.length} new users`);
  let succeeded = 0;
  let failed = 0;
  const errors = [];
  for (const did of didsToFollow) {
    try {
      const record = {
        $type: "app.bsky.graph.follow",
        subject: did,
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      console.log(`[ErgoBlock BG] Following ${did} (${succeeded + failed + 1}/${didsToFollow.length})...`);
      const response = await bgApiRequest(
        "com.atproto.repo.createRecord",
        "POST",
        {
          repo: auth.did,
          collection: "app.bsky.graph.follow",
          record
        },
        auth.accessJwt,
        auth.pdsUrl
      );
      if (response) {
        succeeded++;
        console.log(`[ErgoBlock BG] Followed ${did} successfully: ${response.uri}`);
      } else {
        failed++;
        console.error(`[ErgoBlock BG] Follow returned null for ${did}`);
        errors.push(`Failed to follow ${did}`);
      }
      await sleep(100);
    } catch (error) {
      failed++;
      const errorMsg = error instanceof Error ? error.message : "Unknown error";
      errors.push(`${did}: ${errorMsg}`);
      console.error(`[ErgoBlock BG] Failed to follow ${did}:`, error);
    }
  }
  followsCache.data = null;
  followsCache.fetchedAt = 0;
  console.log(
    `[ErgoBlock BG] Copy User follows complete: ${succeeded} succeeded, ${failed} failed, ${alreadyFollowing} skipped (already following)`
  );
  return { success: failed === 0, succeeded, failed, errors, skipped: alreadyFollowing };
}
async function handleExecuteCopyUserBlocks(dids) {
  const auth = await getAuthToken();
  if (!auth?.accessJwt || !auth?.did || !auth?.pdsUrl) {
    return { success: false, error: "Not authenticated" };
  }
  console.log(`[ErgoBlock BG] Executing Copy User blocks for ${dids.length} users`);
  let succeeded = 0;
  let failed = 0;
  const errors = [];
  for (const did of dids) {
    try {
      const record = {
        $type: "app.bsky.graph.block",
        subject: did,
        createdAt: (/* @__PURE__ */ new Date()).toISOString()
      };
      console.log(`[ErgoBlock BG] Blocking ${did} (${succeeded + failed + 1}/${dids.length})...`);
      const response = await bgApiRequest(
        "com.atproto.repo.createRecord",
        "POST",
        {
          repo: auth.did,
          collection: "app.bsky.graph.block",
          record
        },
        auth.accessJwt,
        auth.pdsUrl
      );
      if (response) {
        succeeded++;
        console.log(`[ErgoBlock BG] Blocked ${did} successfully: ${response.uri}`);
        await addHistoryEntry({
          did,
          handle: did,
          // We don't have handle here, use DID
          action: "blocked",
          timestamp: Date.now(),
          trigger: "manual",
          success: true
        });
      } else {
        failed++;
        console.error(`[ErgoBlock BG] Block returned null for ${did}`);
        errors.push(`Failed to block ${did}`);
      }
      await sleep(100);
    } catch (error) {
      failed++;
      const errorMsg = error instanceof Error ? error.message : "Unknown error";
      errors.push(`${did}: ${errorMsg}`);
      console.error(`[ErgoBlock BG] Failed to block ${did}:`, error);
    }
  }
  console.log(`[ErgoBlock BG] Copy User blocks complete: ${succeeded} succeeded, ${failed} failed`);
  return { success: failed === 0, succeeded, failed, errors };
}
async function handleScanDuplicateFollows(deleteDuplicates) {
  const auth = await getAuthToken();
  if (!auth?.accessJwt || !auth?.did || !auth?.pdsUrl) {
    return { success: false, error: "Not authenticated" };
  }
  console.log("[ErgoBlock BG] Scanning for duplicate follow records...");
  const allRecords = [];
  let cursor;
  do {
    let endpoint = `com.atproto.repo.listRecords?repo=${auth.did}&collection=app.bsky.graph.follow&limit=100`;
    if (cursor) {
      endpoint += `&cursor=${encodeURIComponent(cursor)}`;
    }
    const response = await bgApiRequest(
      endpoint,
      "GET",
      null,
      auth.accessJwt,
      auth.pdsUrl
    );
    if (response?.records) {
      allRecords.push(...response.records);
    }
    cursor = response?.cursor;
    if (cursor) {
      await sleep(PAGINATION_DELAY);
    }
  } while (cursor);
  console.log(`[ErgoBlock BG] Found ${allRecords.length} total follow records`);
  const recordsBySubject = /* @__PURE__ */ new Map();
  for (const record of allRecords) {
    const subject = record.value.subject;
    const existing = recordsBySubject.get(subject) || [];
    existing.push(record);
    recordsBySubject.set(subject, existing);
  }
  const duplicates = [];
  for (const [did, records] of recordsBySubject.entries()) {
    if (records.length > 1) {
      records.sort((a, b) => new Date(a.value.createdAt).getTime() - new Date(b.value.createdAt).getTime());
      duplicates.push({ did, records });
    }
  }
  const totalDuplicateRecords = duplicates.reduce((sum, d) => sum + d.records.length - 1, 0);
  console.log(`[ErgoBlock BG] Found ${duplicates.length} DIDs with duplicates (${totalDuplicateRecords} extra records)`);
  if (!deleteDuplicates) {
    return {
      success: true,
      totalRecords: allRecords.length,
      uniqueFollows: recordsBySubject.size,
      duplicateDids: duplicates.length,
      duplicateRecords: totalDuplicateRecords,
      duplicateDetails: duplicates.map((d) => ({
        did: d.did,
        count: d.records.length,
        uris: d.records.map((r) => r.uri)
      }))
    };
  }
  console.log("[ErgoBlock BG] Deleting duplicate follow records...");
  let deleted = 0;
  let deleteFailed = 0;
  const deleteErrors = [];
  for (const { did, records } of duplicates) {
    for (let i = 1; i < records.length; i++) {
      const record = records[i];
      const rkey = record.uri.split("/").pop();
      if (!rkey) {
        deleteErrors.push(`Invalid URI for ${did}: ${record.uri}`);
        deleteFailed++;
        continue;
      }
      try {
        console.log(`[ErgoBlock BG] Deleting duplicate follow for ${did}: ${record.uri}`);
        await bgApiRequest(
          "com.atproto.repo.deleteRecord",
          "POST",
          {
            repo: auth.did,
            collection: "app.bsky.graph.follow",
            rkey
          },
          auth.accessJwt,
          auth.pdsUrl
        );
        deleted++;
        await sleep(100);
      } catch (error) {
        const errorMsg = error instanceof Error ? error.message : "Unknown error";
        deleteErrors.push(`Failed to delete ${record.uri}: ${errorMsg}`);
        deleteFailed++;
        console.error(`[ErgoBlock BG] Failed to delete duplicate:`, error);
      }
    }
  }
  followsCache.data = null;
  followsCache.fetchedAt = 0;
  console.log(`[ErgoBlock BG] Duplicate cleanup complete: ${deleted} deleted, ${deleteFailed} failed`);
  return {
    success: deleteFailed === 0,
    totalRecords: allRecords.length,
    uniqueFollows: recordsBySubject.size,
    duplicateDids: duplicates.length,
    duplicateRecords: totalDuplicateRecords,
    deleted,
    deleteFailed,
    deleteErrors
  };
}
async function handleGetPdsRecordCounts() {
  const auth = await getAuthToken();
  if (!auth?.did || !auth?.pdsUrl) {
    return { success: false, error: "Not authenticated" };
  }
  console.log("[ErgoBlock BG] Fetching PDS record counts via CAR...");
  try {
    const counts = await getRecordCountsFromCar(auth.did, auth.pdsUrl);
    const collections = [
      { id: "app.bsky.graph.follow", label: "Follows" },
      { id: "app.bsky.graph.block", label: "Blocks" },
      { id: "app.bsky.graph.listitem", label: "List Items" },
      { id: "app.bsky.graph.list", label: "Lists" },
      { id: "app.bsky.feed.post", label: "Posts" },
      { id: "app.bsky.feed.like", label: "Likes" },
      { id: "app.bsky.feed.repost", label: "Reposts" },
      { id: "app.bsky.actor.profile", label: "Profile" }
    ];
    console.log("[ErgoBlock BG] Record counts:", counts);
    return {
      success: true,
      counts,
      collections: collections.map((c) => ({ id: c.id, label: c.label, count: counts[c.id] || 0 }))
    };
  } catch (error) {
    console.error("[ErgoBlock BG] Failed to get record counts:", error);
    return { success: false, error: error instanceof Error ? error.message : "Failed to fetch CAR" };
  }
}
async function handleDebugFindOrphanBlocks() {
  const auth = await getAuthToken();
  if (!auth?.accessJwt || !auth?.did || !auth?.pdsUrl) {
    return { success: false, error: "Not authenticated" };
  }
  console.log("[ErgoBlock BG] DEBUG: Finding orphan block records...");
  try {
    console.log("[ErgoBlock BG] Fetching CAR data...");
    const carResult = await getGraphOperationsSmart({
      did: auth.did,
      pdsUrl: auth.pdsUrl,
      forceRefresh: true,
      onProgress: (p) => console.log(`[ErgoBlock BG] CAR: ${p.message}`)
    });
    const carBlockDids = new Set(carResult.blocks.map((b) => b.did));
    const carBlocksByDid = new Map(carResult.blocks.map((b) => [b.did, b]));
    console.log(`[ErgoBlock BG] CAR has ${carBlockDids.size} block records`);
    console.log("[ErgoBlock BG] Fetching API blocks...");
    const apiBlocks = [];
    let cursor;
    do {
      const response = await bgApiRequest(
        `app.bsky.graph.getBlocks?limit=100${cursor ? `&cursor=${cursor}` : ""}`,
        "GET",
        null,
        auth.accessJwt,
        auth.pdsUrl
      );
      if (response?.blocks) {
        apiBlocks.push(...response.blocks.map((b) => b.did));
        cursor = response.cursor;
      } else {
        break;
      }
    } while (cursor);
    const apiBlockDids = new Set(apiBlocks);
    console.log(`[ErgoBlock BG] API reports ${apiBlockDids.size} active blocks`);
    const orphanDids = [...carBlockDids].filter((did) => !apiBlockDids.has(did));
    console.log(`[ErgoBlock BG] Found ${orphanDids.length} orphan block records`);
    const orphanDetails = orphanDids.map((did) => {
      const record = carBlocksByDid.get(did);
      return {
        did,
        rkey: record.rkey,
        createdAt: new Date(record.createdAt).toISOString()
      };
    });
    orphanDetails.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
    console.log("[ErgoBlock BG] First 20 orphans (oldest):");
    orphanDetails.slice(0, 20).forEach((o, i) => {
      console.log(`  ${i + 1}. ${o.did} (rkey: ${o.rkey}, created: ${o.createdAt})`);
    });
    if (orphanDetails.length > 40) {
      console.log(`[ErgoBlock BG] ... ${orphanDetails.length - 40} more ...`);
    }
    console.log("[ErgoBlock BG] Last 20 orphans (newest):");
    orphanDetails.slice(-20).forEach((o, i) => {
      console.log(`  ${orphanDetails.length - 20 + i + 1}. ${o.did} (rkey: ${o.rkey}, created: ${o.createdAt})`);
    });
    if (orphanDetails.length > 0) {
      const firstDate = orphanDetails[0].createdAt;
      const lastDate = orphanDetails[orphanDetails.length - 1].createdAt;
      console.log(`[ErgoBlock BG] Orphan date range: ${firstDate} to ${lastDate}`);
    }
    console.log("[ErgoBlock BG] Checking if orphans are deleted accounts (sampling first 10)...");
    const sampleOrphans = orphanDetails.slice(0, 10);
    for (const orphan of sampleOrphans) {
      try {
        const response = await fetch(
          `https://public.api.bsky.app/xrpc/app.bsky.actor.getProfile?actor=${encodeURIComponent(orphan.did)}`
        );
        if (response.ok) {
          const profile = await response.json();
          console.log(`  ${orphan.did}: ACTIVE - @${profile.handle}`);
        } else if (response.status === 400) {
          const error = await response.json();
          console.log(`  ${orphan.did}: ${error.message || "Invalid/deleted"}`);
        } else {
          console.log(`  ${orphan.did}: HTTP ${response.status}`);
        }
      } catch (e) {
        console.log(`  ${orphan.did}: Error - ${e}`);
      }
      await sleep(100);
    }
    return {
      success: true,
      carCount: carBlockDids.size,
      apiCount: apiBlockDids.size,
      orphanCount: orphanDids.length,
      orphans: orphanDetails
    };
  } catch (error) {
    console.error("[ErgoBlock BG] Failed to find orphan blocks:", error);
    return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
  }
}
async function bgApiRequestPublic(endpoint) {
  const BSKY_PUBLIC_API2 = "https://public.api.bsky.app";
  try {
    const response = await fetch(`${BSKY_PUBLIC_API2}/xrpc/${endpoint}`);
    if (!response.ok) {
      console.error(`[ErgoBlock BG] Public API request failed: ${response.status}`);
      return null;
    }
    return await response.json();
  } catch (error) {
    console.error(`[ErgoBlock BG] Public API request error:`, error);
    return null;
  }
}
async function handleResolveHandle(handle) {
  try {
    const auth = await getAuthToken();
    if (!auth?.accessJwt || !auth?.pdsUrl) {
      return { success: false, error: "Not authenticated" };
    }
    const normalizedHandle = handle.startsWith("@") ? handle.slice(1) : handle;
    const profiles = await fetchProfiles([normalizedHandle], auth.accessJwt, auth.pdsUrl);
    const profile = profiles[0];
    if (!profile || !profile.did) {
      return { success: false, error: "User not found" };
    }
    return {
      success: true,
      profile: {
        did: profile.did,
        handle: profile.handle,
        displayName: profile.displayName,
        avatar: profile.avatar
      }
    };
  } catch (error) {
    console.error("[ErgoBlock BG] Failed to resolve handle:", error);
    return {
      success: false,
      error: error instanceof Error ? error.message : "Failed to resolve handle"
    };
  }
}
var messageHandler = async (rawMessage) => {
  const message = rawMessage;
  console.log("[ErgoBlock BG] Received message:", message.type);
  if (message.type === "TEMP_BLOCK_ADDED" || message.type === "TEMP_MUTE_ADDED") {
    setupAlarm();
    return void 0;
  }
  if (message.type === "SET_AUTH_TOKEN" && message.auth) {
    await browser_default.storage.local.set({ authToken: message.auth });
    return { success: true };
  }
  if (message.type === "GET_AUTH_STATUS") {
    const auth = await getAuthToken();
    return { success: true, isAuthenticated: !!auth };
  }
  if (message.type === "CHECK_NOW") {
    await checkExpirations();
    return { success: true };
  }
  if (message.type === "SYNC_NOW") {
    return await performFullSync();
  }
  if (message.type === "UNBLOCK_USER" && message.did) {
    return await handleUnblockRequest(message.did);
  }
  if (message.type === "UNMUTE_USER" && message.did) {
    return await handleUnmuteRequest(message.did);
  }
  if (message.type === "TEMP_UNBLOCK_FOR_VIEW" && message.did) {
    return await handleTempUnblockForView(message.did);
  }
  if (message.type === "REBLOCK_USER" && message.did) {
    return await handleReblockUser(message.did);
  }
  if (message.type === "FIND_CONTEXT" && message.did && message.handle) {
    return await handleFindContext(message.did, message.handle);
  }
  if (message.type === "SCHEDULE_DELAYED_BLOCK" && message.did && message.handle && message.delaySeconds !== void 0) {
    return await handleScheduleDelayedBlock(
      message.did,
      message.handle,
      message.blockDurationMs ?? -1,
      message.permanent ?? true,
      message.delaySeconds,
      message.mutedFirst ?? false
    );
  }
  if (message.type === "FETCH_ALL_INTERACTIONS" && message.did && message.handle) {
    return await handleFetchAllInteractions(message.did, message.handle);
  }
  if (message.type === "BLOCKLIST_AUDIT_SYNC") {
    return await performBlocklistAuditSync();
  }
  if (message.type === "UNSUBSCRIBE_BLOCKLIST" && message.listUri) {
    return await handleUnsubscribeFromBlocklist(message.listUri);
  }
  if (message.type === "COPY_BLOCKLIST_AS_INDIVIDUAL_BLOCKS" && message.listUri) {
    return await handleCopyBlocklistAsIndividualBlocks(message.listUri);
  }
  if (message.type === "FETCH_OWNED_LISTS") {
    return await handleFetchOwnedLists();
  }
  if (message.type === "FETCH_LIST_MEMBERS_WITH_TIMESTAMPS" && message.listUri) {
    return await handleFetchListMembersWithTimestamps(message.listUri);
  }
  if (message.type === "REMOVE_FROM_LIST" && message.rkey) {
    return await handleRemoveFromList(message.rkey);
  }
  if (message.type === "FIND_INTERACTIONS_BEFORE" && message.targetDid && message.beforeTimestamp) {
    return await handleFindInteractionsBefore(
      message.targetDid,
      message.beforeTimestamp
    );
  }
  if (message.type === "GET_FOLLOW_RELATIONSHIPS" && message.did) {
    return await handleGetFollowRelationships(message.did);
  }
  if (message.type === "GET_FOLLOWS_WHO_FOLLOW_THEM" && message.did) {
    return await handleGetFollowsWhoFollowThem(message.did);
  }
  if (message.type === "GET_FOLLOWERS_WHO_FOLLOW_THEM" && message.did) {
    return await handleGetFollowersWhoFollowThem(message.did);
  }
  if (message.type === "GET_FOLLOWS_THEY_BLOCK" && message.did) {
    return await handleGetFollowsTheyBlock(message.did);
  }
  if (message.type === "GET_FOLLOWS_WHO_BLOCK_THEM" && message.did) {
    return await handleGetFollowsWhoBlockThem(message.did);
  }
  if (message.type === "GET_FOLLOWS_WHO_BLOCK_THEM_CACHED" && message.did) {
    return await handleGetFollowsWhoBlockThemCached(message.did);
  }
  if (message.type === "PREWARM_CLEARSKY_CACHE" && message.targetDids) {
    return await handlePrewarmClearskyCache(message.targetDids);
  }
  if (message.type === "CLEAR_CLEARSKY_CACHE") {
    try {
      await clearClearskyCache();
      console.log("[ErgoBlock BG] Clearsky cache cleared");
      return { success: true };
    } catch (error) {
      console.error("[ErgoBlock BG] Failed to clear Clearsky cache:", error);
      return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
    }
  }
  if (message.type === "PREFETCH_CLEARSKY_LOOKAHEAD" && message.targetDids) {
    const targetDids = message.targetDids;
    const result = await prewarmBlockedByCache(targetDids, true);
    console.log(
      `[ErgoBlock BG] Lookahead prefetch: ${result.queued} queued, ${result.alreadyCached} cached`
    );
    if (result.queued > 0) {
      processBlockedByQueue(result.queued).catch((err) => {
        console.error("[ErgoBlock BG] Lookahead processing failed:", err);
      });
    }
    return { success: true, ...result };
  }
  if (message.type === "SCAN_MASS_OPS" && message.settings) {
    const forceRefresh = message.forceRefresh === true;
    return await handleScanMassOps(message.settings, forceRefresh);
  }
  if (message.type === "UNDO_MASS_OPERATIONS" && message.operations) {
    return await handleUndoMassOperations(message.operations);
  }
  if (message.type === "GET_MASS_OPS_SETTINGS") {
    const settings = await getMassOpsSettings();
    return { success: true, settings };
  }
  if (message.type === "SET_MASS_OPS_SETTINGS" && message.settings) {
    await setMassOpsSettings(message.settings);
    return { success: true };
  }
  if (message.type === "DISMISS_MASS_OPS_CLUSTER" && message.cluster) {
    try {
      const cluster = message.cluster;
      await dismissMassOpsCluster({
        type: cluster.type,
        startTime: cluster.startTime,
        endTime: cluster.endTime,
        count: cluster.count,
        dismissedAt: Date.now()
      });
      return { success: true };
    } catch (error) {
      return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
    }
  }
  if (message.type === "GET_DISMISSED_MASS_OPS_CLUSTERS") {
    try {
      const dismissed = await getDismissedMassOpsClusters();
      return { success: true, dismissed };
    } catch (error) {
      return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
    }
  }
  if (message.type === "RESTORE_MASS_OPS_CLUSTER" && message.cluster) {
    try {
      const cluster = message.cluster;
      const dismissed = await getDismissedMassOpsClusters();
      const filtered = dismissed.filter(
        (d) => !(d.type === cluster.type && d.startTime === cluster.startTime && d.endTime === cluster.endTime && d.count === cluster.count)
      );
      await browser_default.storage.local.set({ massOpsDismissedClusters: filtered });
      return { success: true };
    } catch (error) {
      return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
    }
  }
  if (message.type === "CHECK_CAR_CACHE_STATUS") {
    try {
      const auth = await getAuthToken();
      if (!auth?.did || !auth?.pdsUrl) {
        return { success: false, error: "Not authenticated" };
      }
      const status = await checkCarCacheStatus(auth.did, auth.pdsUrl);
      return { success: true, status };
    } catch (error) {
      return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
    }
  }
  if (message.type === "ESTIMATE_CAR_SIZE") {
    try {
      const auth = await getAuthToken();
      if (!auth?.did || !auth?.pdsUrl) {
        return { success: false, error: "Not authenticated" };
      }
      const sizeBytes = await getCarFileSize(auth.did, auth.pdsUrl);
      return { success: true, sizeBytes };
    } catch (error) {
      return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
    }
  }
  if (message.type === "INVALIDATE_CAR_CACHE") {
    try {
      const auth = await getAuthToken();
      if (!auth?.did) {
        return { success: false, error: "Not authenticated" };
      }
      await invalidateCarCache(auth.did);
      return { success: true };
    } catch (error) {
      return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
    }
  }
  if (message.type === "GET_PROFILES_BATCHED" && message.dids) {
    try {
      const auth = await getAuthToken();
      if (!auth) {
        return { success: false, error: "Not authenticated" };
      }
      const profiles = await fetchProfiles(message.dids, auth.accessJwt, auth.pdsUrl);
      const profileMap = {};
      for (const profile of profiles) {
        profileMap[profile.did] = profile;
      }
      return { success: true, profiles: profileMap };
    } catch (error) {
      return { success: false, error: error instanceof Error ? error.message : "Unknown error" };
    }
  }
  if (message.type === "FETCH_COPY_USER_DATA" && message.handle) {
    return await handleFetchCopyUserData(message.handle);
  }
  if (message.type === "EXECUTE_COPY_USER_FOLLOWS" && message.dids) {
    return await handleExecuteCopyUserFollows(message.dids);
  }
  if (message.type === "EXECUTE_COPY_USER_BLOCKS" && message.dids) {
    return await handleExecuteCopyUserBlocks(message.dids);
  }
  if (message.type === "SCAN_DUPLICATE_FOLLOWS") {
    return await handleScanDuplicateFollows(message.deleteDuplicates === true);
  }
  if (message.type === "RECTIFY_AMNESTY_UNBLOCKS") {
    return await rectifyFailedAmnestyUnblocks();
  }
  if (message.type === "GET_PDS_RECORD_COUNTS") {
    return await handleGetPdsRecordCounts();
  }
  if (message.type === "RESOLVE_HANDLE" && message.handle) {
    return await handleResolveHandle(message.handle);
  }
  if (message.type === "DEBUG_FIND_ORPHAN_BLOCKS") {
    return await handleDebugFindOrphanBlocks();
  }
  return void 0;
};
browser_default.runtime.onMessage.addListener(messageHandler);
var MAX_SYNC_DURATION_MS = 10 * 60 * 1e3;
async function clearStaleSyncState() {
  const state = await getSyncState();
  if (state.syncInProgress) {
    const now = Date.now();
    const syncStartTime = state.lastBlockSync || state.lastMuteSync || 0;
    const syncAge = now - syncStartTime;
    if (syncAge > MAX_SYNC_DURATION_MS || syncStartTime === 0) {
      console.log(
        `[ErgoBlock BG] Clearing stale syncInProgress flag (age: ${Math.round(syncAge / 1e3)}s)`
      );
      await updateSyncState({
        syncInProgress: false,
        lastError: "Sync was interrupted (service worker restart)"
      });
    } else {
      console.log(
        `[ErgoBlock BG] Sync in progress flag set (age: ${Math.round(syncAge / 1e3)}s) - may be ongoing`
      );
    }
  }
}
async function clearBloatedStorageData() {
  try {
    const existingGraph = await getSocialGraph();
    if (existingGraph.follows.length > 0 || existingGraph.followers.length > 0) {
      console.log("[ErgoBlock BG] Clearing old bloated socialGraph storage...");
      await browser_default.storage.local.remove("socialGraph");
      console.log("[ErgoBlock BG] Old socialGraph cleared");
    }
  } catch (error) {
    console.error("[ErgoBlock BG] Error clearing bloated storage:", error);
  }
}
browser_default.action.setBadgeText({ text: "" });
async function migrateBlockedByCache() {
  const MIGRATION_KEY = "clearskyBlockedByMigrationV1";
  const result = await browser_default.storage.local.get(MIGRATION_KEY);
  if (result[MIGRATION_KEY]) {
    return;
  }
  console.log("[ErgoBlock BG] Migrating: Clearing Clearsky blocked-by cache (wrong endpoint fix)");
  await clearClearskyCache();
  await browser_default.storage.local.set({ [MIGRATION_KEY]: true });
  console.log("[ErgoBlock BG] Migration complete");
}
browser_default.runtime.onInstalled.addListener(async () => {
  console.log("[ErgoBlock BG] Extension installed");
  clearStaleSyncState();
  await clearBloatedStorageData();
  await migrateBlockedByCache();
  setupAlarm();
  setupSyncAlarm();
  setupFollowsSyncAlarm();
  setupClearskyQueueAlarm();
  browser_default.action.setBadgeText({ text: "" });
  setTimeout(() => syncFollowsOnly(), 5e3);
  setTimeout(() => rectifyFailedAmnestyUnblocks(), 1e4);
});
browser_default.runtime.onStartup.addListener(async () => {
  console.log("[ErgoBlock BG] Extension started");
  clearStaleSyncState();
  await clearBloatedStorageData();
  await migrateBlockedByCache();
  setupAlarm();
  setupSyncAlarm();
  setupFollowsSyncAlarm();
  setupClearskyQueueAlarm();
  browser_default.action.setBadgeText({ text: "" });
  setTimeout(() => syncFollowsOnly(), 5e3);
  setTimeout(() => rectifyFailedAmnestyUnblocks(), 1e4);
});
clearStaleSyncState();
clearBloatedStorageData();
migrateBlockedByCache();
setupAlarm();
setupSyncAlarm();
setupFollowsSyncAlarm();
setupClearskyQueueAlarm();
setTimeout(() => syncFollowsOnly(), 5e3);
setTimeout(() => rectifyFailedAmnestyUnblocks(), 1e4);
export {
  blockUser,
  checkExpirations,
  isSearchPostInteraction,
  performBlocklistAuditSync,
  performFullSync,
  sendNotification,
  setupAlarm,
  setupSyncAlarm,
  unblockUser,
  unmuteUser
};
