// src/utils.ts
var LOG_LEVEL_PRIORITY = {
  debug: 0,
  info: 1,
  warn: 2,
  error: 3
};
var currentLogLevel = "info";
var logger = {
  debug: (message, ...args) => {
    if (LOG_LEVEL_PRIORITY[currentLogLevel] <= LOG_LEVEL_PRIORITY.debug) {
      console.debug(`[ErgoBlock] ${message}`, ...args);
    }
  },
  info: (message, ...args) => {
    if (LOG_LEVEL_PRIORITY[currentLogLevel] <= LOG_LEVEL_PRIORITY.info) {
      console.log(`[ErgoBlock] ${message}`, ...args);
    }
  },
  warn: (message, ...args) => {
    if (LOG_LEVEL_PRIORITY[currentLogLevel] <= LOG_LEVEL_PRIORITY.warn) {
      console.warn(`[ErgoBlock] ${message}`, ...args);
    }
  },
  error: (message, ...args) => {
    if (LOG_LEVEL_PRIORITY[currentLogLevel] <= LOG_LEVEL_PRIORITY.error) {
      console.error(`[ErgoBlock] ${message}`, ...args);
    }
  }
};
var RateLimiter = class {
  constructor(options = {}) {
    this.lastActionTime = 0;
    this.actionCount = 0;
    this.windowMs = options.windowMs ?? 1e4;
    this.maxActions = options.maxActions ?? 5;
    this.cooldownMs = options.cooldownMs ?? 2e3;
  }
  /**
   * Check if an action is allowed
   * @returns true if allowed, false if rate limited
   */
  canPerformAction() {
    const now = Date.now();
    if (now - this.lastActionTime > this.windowMs) {
      this.actionCount = 0;
    }
    if (now - this.lastActionTime < this.cooldownMs) {
      return false;
    }
    if (this.actionCount >= this.maxActions) {
      return false;
    }
    return true;
  }
  /**
   * Record an action
   */
  recordAction() {
    const now = Date.now();
    if (now - this.lastActionTime > this.windowMs) {
      this.actionCount = 0;
    }
    this.lastActionTime = now;
    this.actionCount++;
  }
  /**
   * Get time until next action is allowed (in ms)
   */
  getWaitTime() {
    const now = Date.now();
    const cooldownRemaining = Math.max(0, this.cooldownMs - (now - this.lastActionTime));
    if (this.actionCount >= this.maxActions) {
      const windowRemaining = Math.max(0, this.windowMs - (now - this.lastActionTime));
      return Math.max(cooldownRemaining, windowRemaining);
    }
    return cooldownRemaining;
  }
};
var actionRateLimiter = new RateLimiter({
  windowMs: 1e4,
  // 10 seconds
  maxActions: 5,
  // Max 5 blocks/mutes per 10 seconds
  cooldownMs: 1e3
  // 1 second minimum between actions
});
var CircuitBreaker = class {
  constructor(options = {}) {
    this.state = "closed";
    this.failures = 0;
    this.lastFailureTime = 0;
    this.successesSinceHalfOpen = 0;
    this.failureThreshold = options.failureThreshold ?? 5;
    this.resetTimeoutMs = options.resetTimeoutMs ?? 6e4;
    this.halfOpenSuccessThreshold = options.halfOpenSuccessThreshold ?? 2;
  }
  /**
   * Get current circuit state
   */
  getState() {
    this.updateState();
    return this.state;
  }
  /**
   * Check if circuit allows requests
   */
  isAllowed() {
    this.updateState();
    return this.state !== "open";
  }
  /**
   * Record a successful operation
   */
  recordSuccess() {
    this.updateState();
    if (this.state === "half-open") {
      this.successesSinceHalfOpen++;
      if (this.successesSinceHalfOpen >= this.halfOpenSuccessThreshold) {
        this.reset();
      }
    } else if (this.state === "closed") {
      this.failures = Math.max(0, this.failures - 1);
    }
  }
  /**
   * Record a failed operation
   */
  recordFailure() {
    this.updateState();
    if (this.state === "half-open") {
      this.trip();
    } else if (this.state === "closed") {
      this.failures++;
      this.lastFailureTime = Date.now();
      if (this.failures >= this.failureThreshold) {
        this.trip();
      }
    }
  }
  /**
   * Manually reset the circuit
   */
  reset() {
    this.state = "closed";
    this.failures = 0;
    this.successesSinceHalfOpen = 0;
    logger.info("Circuit breaker reset to closed");
  }
  trip() {
    this.state = "open";
    this.lastFailureTime = Date.now();
    logger.warn(`Circuit breaker opened after ${this.failures} failures`);
  }
  updateState() {
    if (this.state === "open") {
      const now = Date.now();
      if (now - this.lastFailureTime >= this.resetTimeoutMs) {
        this.state = "half-open";
        this.successesSinceHalfOpen = 0;
        logger.info("Circuit breaker entering half-open state");
      }
    }
  }
};
var apiCircuitBreaker = new CircuitBreaker({
  failureThreshold: 5,
  resetTimeoutMs: 6e4,
  // 1 minute
  halfOpenSuccessThreshold: 2
});
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
var ALLOWED_PDS_PATTERNS = [
  /^https:\/\/[a-zA-Z0-9-]+\.bsky\.network$/,
  /^https:\/\/bsky\.social$/,
  /^https:\/\/[a-zA-Z0-9-]+\.bsky\.social$/,
  /^https:\/\/[a-zA-Z0-9-]+\.host\.bsky\.network$/,
  // Self-hosted PDS on standard ports
  /^https:\/\/[a-zA-Z0-9][a-zA-Z0-9.-]*\.[a-zA-Z]{2,}(:\d+)?$/
];
function validatePdsUrl(url) {
  if (!url || typeof url !== "string") return null;
  let normalized = url.trim();
  normalized = normalized.replace(/\/+$/, "");
  if (!normalized.startsWith("http://") && !normalized.startsWith("https://")) {
    normalized = "https://" + normalized;
  }
  if (normalized.startsWith("http://")) {
    if (!normalized.includes("localhost") && !normalized.includes("127.0.0.1")) {
      logger.warn("Rejecting non-HTTPS PDS URL:", normalized);
      return null;
    }
  }
  let parsed;
  try {
    parsed = new URL(normalized);
  } catch {
    logger.warn("Invalid PDS URL format:", normalized);
    return null;
  }
  if (parsed.pathname !== "/" && parsed.pathname !== "") {
    logger.warn("PDS URL should not have a path:", normalized);
    return null;
  }
  if (parsed.search || parsed.hash) {
    logger.warn("PDS URL should not have query or hash:", normalized);
    return null;
  }
  const isAllowed = ALLOWED_PDS_PATTERNS.some((pattern) => pattern.test(normalized));
  const isLocalhost = parsed.hostname === "localhost" || parsed.hostname === "127.0.0.1" || parsed.hostname.endsWith(".localhost");
  if (!isAllowed && !isLocalhost) {
    logger.warn("PDS URL not in known patterns, allowing with caution:", normalized);
  }
  return `${parsed.protocol}//${parsed.host}`;
}
function isRetryableError(error) {
  const message = error.message.toLowerCase();
  if (message.includes("network") || message.includes("fetch") || message.includes("timeout") || message.includes("econnreset") || message.includes("enotfound")) {
    return true;
  }
  if (message.includes("429") || message.includes("rate limit")) {
    return true;
  }
  if (message.includes("500") || message.includes("502") || message.includes("503") || message.includes("504")) {
    return true;
  }
  if (message.includes("401") || message.includes("auth error")) {
    return false;
  }
  if (message.includes("expiredtoken") || message.includes("token has expired") || message.includes("expired token")) {
    return false;
  }
  if (message.includes("400") || message.includes("403") || message.includes("404")) {
    return false;
  }
  return false;
}
async function withRetry(fn, options = {}) {
  if (typeof fn !== "function") {
    throw new TypeError("withRetry: first argument must be a function");
  }
  const {
    maxRetries = 3,
    initialDelayMs = 1e3,
    maxDelayMs = 3e4,
    backoffMultiplier = 2,
    isRetryable = isRetryableError,
    onRetry
  } = options;
  if (maxRetries < 0 || !Number.isFinite(maxRetries)) {
    throw new TypeError("withRetry: maxRetries must be a non-negative finite number");
  }
  let lastError;
  let delay = initialDelayMs;
  for (let attempt = 0; attempt <= maxRetries; attempt++) {
    try {
      const result = fn();
      if (result && typeof result.then === "function") {
        return await result;
      }
      return result;
    } catch (error) {
      lastError = error instanceof Error ? error : new Error(String(error));
      if (attempt === maxRetries || !isRetryable(lastError)) {
        throw lastError;
      }
      const jitter = delay * 0.1 * (Math.random() * 2 - 1);
      const actualDelay = Math.min(delay + jitter, maxDelayMs);
      onRetry?.(attempt + 1, lastError, actualDelay);
      logger.info(
        `Retry ${attempt + 1}/${maxRetries} after ${Math.round(actualDelay)}ms: ${lastError.message}`
      );
      await sleep(actualDelay);
      delay = Math.min(delay * backoffMultiplier, maxDelayMs);
    }
  }
  throw lastError || new Error("Retry failed");
}
function isValidRkey(rkey) {
  if (!rkey || typeof rkey !== "string") return false;
  if (rkey.length > 512) return false;
  return /^[a-zA-Z0-9._~-]+$/.test(rkey);
}
function extractRkeyFromUri(uri) {
  if (!uri || typeof uri !== "string") return null;
  const match = uri.match(/^at:\/\/did:[^/]+\/[^/]+\/([^/?#]+)$/);
  if (!match) return null;
  const rkey = match[1];
  if (!isValidRkey(rkey)) {
    logger.warn("Invalid rkey extracted from URI:", uri);
    return null;
  }
  return rkey;
}

// src/api.ts
var DEFAULT_TIMEOUT_MS = 3e4;
var BSKY_PUBLIC_API = "https://public.api.bsky.app";
var BSKY_PDS_DEFAULT = "https://bsky.social";
var getLocalStorage = () => {
  if (typeof window !== "undefined" && window.localStorage) {
    return window.localStorage;
  }
  return null;
};
function getSession() {
  try {
    const localStorageProxy = getLocalStorage();
    if (!localStorageProxy) return null;
    const possibleKeys = Object.keys(localStorageProxy).filter(
      (k) => k.includes("BSKY") || k.includes("bsky") || k.includes("session")
    );
    logger.debug(`Found ${possibleKeys.length} potential session storage keys`);
    for (const storageKey of possibleKeys) {
      try {
        const raw = localStorageProxy.getItem(storageKey);
        if (!raw) continue;
        const parsed = JSON.parse(raw);
        let account = null;
        if (parsed?.session?.currentAccount) {
          const currentDid = parsed.session.currentAccount.did;
          account = parsed.session.accounts?.find((a) => a.did === currentDid) || null;
        }
        if (!account && parsed?.currentAccount) {
          const currentDid = parsed.currentAccount.did;
          account = parsed.accounts?.find((a) => a.did === currentDid) || null;
        }
        if (!account && parsed?.accessJwt && parsed?.did) {
          account = {
            did: parsed.did,
            handle: parsed.handle,
            accessJwt: parsed.accessJwt,
            refreshJwt: void 0,
            // May not be present in this structure
            service: parsed.service,
            pdsUrl: parsed.pdsUrl
          };
        }
        if (account && account.accessJwt && account.did) {
          logger.debug("Found valid session", account.handle ? `for @${account.handle}` : "");
          const rawPdsUrl = account.pdsUrl || account.service || BSKY_PDS_DEFAULT;
          const pdsUrl = validatePdsUrl(rawPdsUrl);
          if (!pdsUrl) {
            logger.error("Invalid PDS URL, using default:", rawPdsUrl);
          }
          const finalPdsUrl = pdsUrl || BSKY_PDS_DEFAULT;
          logger.debug("Using PDS URL:", finalPdsUrl);
          return {
            accessJwt: account.accessJwt,
            refreshJwt: account.refreshJwt,
            did: account.did,
            handle: account.handle || "",
            pdsUrl: finalPdsUrl
          };
        }
      } catch (_e) {
      }
    }
    logger.error("No valid session found in localStorage");
    return null;
  } catch (e) {
    logger.error("Failed to get session:", e);
    return null;
  }
}
async function executeApiRequest(endpoint, method, body, auth, targetBaseUrl, options = {}) {
  const {
    timeoutMs = DEFAULT_TIMEOUT_MS,
    // Default: retry GET requests, don't retry mutations (POST/DELETE) to avoid duplicates
    retry = method === "GET",
    maxRetries = 3
  } = options;
  if (!apiCircuitBreaker.isAllowed()) {
    const state = apiCircuitBreaker.getState();
    logger.warn(`Circuit breaker is ${state}, rejecting request to ${endpoint}`);
    throw new Error(`API circuit breaker is open. Service may be unavailable. Please try again later.`);
  }
  let base = targetBaseUrl;
  if (!base) {
    if (endpoint.startsWith("com.atproto.repo.")) {
      base = auth.pdsUrl;
    } else {
      base = BSKY_PUBLIC_API;
    }
  }
  if (!base) {
    throw new Error("Could not determine base URL for API request");
  }
  base = base.replace(/\/+$/, "");
  const url = `${base}/xrpc/${endpoint}`;
  const doRequest = async () => {
    logger.debug("API request:", method, url);
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const fetchOptions = {
        method,
        headers: {
          Authorization: `Bearer ${auth.accessJwt}`,
          "Content-Type": "application/json"
        },
        signal: controller.signal
      };
      if (body) {
        fetchOptions.body = JSON.stringify(body);
      }
      const response = await fetch(url, fetchOptions);
      if (!response.ok) {
        const error = await response.json().catch(() => ({}));
        const errorCode = error.error || "";
        const errorMessage = error.message || error.error || `API error: ${response.status}`;
        const isBlockError = errorCode === "BlockedActor" || errorCode === "BlockedByActor" || errorMessage.includes("blocked");
        const isExpiredToken = errorCode === "ExpiredToken" || errorMessage.toLowerCase().includes("token has expired") || errorMessage.toLowerCase().includes("expired token");
        if (isExpiredToken) {
          logger.debug("Session token expired, waiting for Bluesky to refresh...");
        } else if (!isBlockError) {
          logger.error("API error:", response.status, JSON.stringify(error));
        }
        if (response.status >= 500) {
          apiCircuitBreaker.recordFailure();
        }
        if (response.status === 401) {
          throw new Error(`Auth error: ${response.status} ${errorMessage}`);
        }
        throw new Error(`${response.status}: ${errorMessage}`);
      }
      apiCircuitBreaker.recordSuccess();
      const text = await response.text();
      return text ? JSON.parse(text) : null;
    } catch (error) {
      if (error instanceof Error && error.name === "AbortError") {
        apiCircuitBreaker.recordFailure();
        throw new Error(`Request timeout after ${timeoutMs}ms: ${url}`);
      }
      apiCircuitBreaker.recordFailure();
      throw error;
    } finally {
      clearTimeout(timeoutId);
    }
  };
  if (retry) {
    return withRetry(doRequest, {
      maxRetries,
      initialDelayMs: 1e3,
      maxDelayMs: 1e4,
      isRetryable: isRetryableError
    });
  }
  return doRequest();
}
async function apiRequest(endpoint, method = "GET", body = null, baseUrl = null) {
  const session = getSession();
  if (!session) {
    throw new Error("Not logged in to Bluesky");
  }
  return executeApiRequest(
    endpoint,
    method,
    body,
    { accessJwt: session.accessJwt, pdsUrl: session.pdsUrl },
    baseUrl || void 0
  );
}
async function blockUser(did) {
  const session = getSession();
  if (!session) throw new Error("Not logged in");
  const record = {
    $type: "app.bsky.graph.block",
    subject: did,
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  return apiRequest("com.atproto.repo.createRecord", "POST", {
    repo: session.did,
    collection: "app.bsky.graph.block",
    record
  });
}
async function unblockUser(did, rkey) {
  const session = getSession();
  if (!session) throw new Error("Not logged in");
  if (rkey) {
    if (!isValidRkey(rkey)) {
      logger.error("Invalid rkey format provided for unblock:", rkey);
      throw new Error("Invalid rkey format");
    }
    logger.info("Unblocking using direct rkey");
    return apiRequest("com.atproto.repo.deleteRecord", "POST", {
      repo: session.did,
      collection: "app.bsky.graph.block",
      rkey
    });
  }
  logger.info("Unblocking using list scan (legacy, paginated)...");
  let cursor;
  let foundRkey = null;
  do {
    let endpoint = `com.atproto.repo.listRecords?repo=${session.did}&collection=app.bsky.graph.block&limit=100`;
    if (cursor) {
      endpoint += `&cursor=${encodeURIComponent(cursor)}`;
    }
    const response = await apiRequest(endpoint);
    const blockRecord = response?.records?.find((r) => r.value.subject === did);
    if (blockRecord) {
      foundRkey = extractRkeyFromUri(blockRecord.uri);
      break;
    }
    cursor = response?.cursor;
    if (cursor) {
      await sleep(100);
    }
  } while (cursor);
  if (!foundRkey) {
    logger.info("No block record found for DID");
    return null;
  }
  return apiRequest("com.atproto.repo.deleteRecord", "POST", {
    repo: session.did,
    collection: "app.bsky.graph.block",
    rkey: foundRkey
  });
}
async function muteUser(did) {
  const session = getSession();
  if (!session) throw new Error("Not logged in");
  return apiRequest(
    "app.bsky.graph.muteActor",
    "POST",
    {
      actor: did
    },
    session.pdsUrl
  );
}
async function unmuteUser(did) {
  const session = getSession();
  if (!session) throw new Error("Not logged in");
  return apiRequest(
    "app.bsky.graph.unmuteActor",
    "POST",
    {
      actor: did
    },
    session.pdsUrl
  );
}
async function getProfile(actor) {
  return apiRequest(`app.bsky.actor.getProfile?actor=${encodeURIComponent(actor)}`);
}
async function getProfiles(actors) {
  if (actors.length === 0) return [];
  if (actors.length > 25) {
    throw new Error("getProfiles supports max 25 actors at once");
  }
  const params = actors.map((a) => `actors=${encodeURIComponent(a)}`).join("&");
  const response = await apiRequest(`app.bsky.actor.getProfiles?${params}`);
  return response?.profiles || [];
}
async function getProfilesBatched(dids, onProgress) {
  const result = /* @__PURE__ */ new Map();
  const batchSize = 25;
  for (let i = 0; i < dids.length; i += batchSize) {
    const batch = dids.slice(i, i + batchSize);
    const profiles = await getProfiles(batch);
    for (const profile of profiles) {
      result.set(profile.did, profile);
    }
    onProgress?.(Math.min(i + batchSize, dids.length), dids.length);
    if (i + batchSize < dids.length) {
      await new Promise((resolve) => setTimeout(resolve, 200));
    }
  }
  return result;
}
var PAGINATION_DELAY = 500;
async function getBlocks(cursor, limit = 100) {
  const session = getSession();
  if (!session) throw new Error("Not logged in");
  let endpoint = `app.bsky.graph.getBlocks?limit=${limit}`;
  if (cursor) {
    endpoint += `&cursor=${encodeURIComponent(cursor)}`;
  }
  const response = await apiRequest(endpoint, "GET", null, session.pdsUrl);
  return response || { blocks: [] };
}
async function getMutes(cursor, limit = 100) {
  const session = getSession();
  if (!session) throw new Error("Not logged in");
  let endpoint = `app.bsky.graph.getMutes?limit=${limit}`;
  if (cursor) {
    endpoint += `&cursor=${encodeURIComponent(cursor)}`;
  }
  const response = await apiRequest(endpoint, "GET", null, session.pdsUrl);
  return response || { mutes: [] };
}
async function getAllBlocks(onProgress) {
  const allBlocks = [];
  let cursor;
  do {
    const response = await getBlocks(cursor);
    allBlocks.push(...response.blocks);
    cursor = response.cursor;
    onProgress?.(allBlocks.length);
    if (cursor) {
      await sleep(PAGINATION_DELAY);
    }
  } while (cursor);
  console.log("[ErgoBlock] Fetched all blocks:", allBlocks.length);
  return allBlocks;
}
async function getAllMutes(onProgress) {
  const allMutes = [];
  let cursor;
  do {
    const response = await getMutes(cursor);
    allMutes.push(...response.mutes);
    cursor = response.cursor;
    onProgress?.(allMutes.length);
    if (cursor) {
      await sleep(PAGINATION_DELAY);
    }
  } while (cursor);
  console.log("[ErgoBlock] Fetched all mutes:", allMutes.length);
  return allMutes;
}
async function getBlockRecords(cursor, limit = 100) {
  const session = getSession();
  if (!session) throw new Error("Not logged in");
  let endpoint = `com.atproto.repo.listRecords?repo=${session.did}&collection=app.bsky.graph.block&limit=${limit}`;
  if (cursor) {
    endpoint += `&cursor=${encodeURIComponent(cursor)}`;
  }
  const response = await apiRequest(
    endpoint,
    "GET",
    null,
    session.pdsUrl
  );
  return response || { records: [] };
}
async function getAllBlockRecords(onProgress) {
  const allRecords = [];
  let cursor;
  do {
    const response = await getBlockRecords(cursor);
    allRecords.push(...response.records);
    cursor = response.cursor;
    onProgress?.(allRecords.length);
    if (cursor) {
      await sleep(PAGINATION_DELAY);
    }
  } while (cursor);
  console.log("[ErgoBlock] Fetched all block records:", allRecords.length);
  return allRecords;
}
async function getAuthorFeed(actor, limit = 100, cursor) {
  let endpoint = `app.bsky.feed.getAuthorFeed?actor=${encodeURIComponent(actor)}&limit=${limit}`;
  if (cursor) {
    endpoint += `&cursor=${encodeURIComponent(cursor)}`;
  }
  const response = await apiRequest(endpoint);
  return response || { feed: [] };
}
async function findRecentInteraction(targetDid, loggedInDid, limit = 100) {
  try {
    const { feed } = await getAuthorFeed(targetDid, limit);
    for (const { post } of feed) {
      if (post.record.reply?.parent?.uri?.includes(loggedInDid)) {
        return post;
      }
      if (post.record.embed?.$type === "app.bsky.embed.record" && post.record.embed.record?.uri?.includes(loggedInDid)) {
        return post;
      }
    }
    return null;
  } catch (error) {
    console.debug(
      `[ErgoBlock] Could not fetch feed for ${targetDid}:`,
      error instanceof Error ? error.message : error
    );
    return null;
  }
}
async function getFollows(actor, cursor, limit = 100) {
  let endpoint = `app.bsky.graph.getFollows?actor=${encodeURIComponent(actor)}&limit=${limit}`;
  if (cursor) {
    endpoint += `&cursor=${encodeURIComponent(cursor)}`;
  }
  const response = await apiRequest(endpoint);
  return response || { follows: [] };
}
async function getAllFollows(actor, onProgress) {
  const allFollows = [];
  let cursor;
  do {
    const response = await getFollows(actor, cursor);
    allFollows.push(...response.follows);
    cursor = response.cursor;
    onProgress?.(allFollows.length);
    if (cursor) {
      await sleep(PAGINATION_DELAY);
    }
  } while (cursor);
  console.log("[ErgoBlock] Fetched all follows:", allFollows.length);
  return allFollows;
}
async function getFollowers(actor, cursor, limit = 100) {
  let endpoint = `app.bsky.graph.getFollowers?actor=${encodeURIComponent(actor)}&limit=${limit}`;
  if (cursor) {
    endpoint += `&cursor=${encodeURIComponent(cursor)}`;
  }
  const response = await apiRequest(endpoint);
  return response || { followers: [] };
}
async function getAllFollowers(actor, onProgress) {
  const allFollowers = [];
  let cursor;
  do {
    const response = await getFollowers(actor, cursor);
    allFollowers.push(...response.followers);
    cursor = response.cursor;
    onProgress?.(allFollowers.length);
    if (cursor) {
      await sleep(PAGINATION_DELAY);
    }
  } while (cursor);
  console.log("[ErgoBlock] Fetched all followers:", allFollowers.length);
  return allFollowers;
}
async function getListBlocks(cursor, limit = 100) {
  const session = getSession();
  if (!session) throw new Error("Not logged in");
  let endpoint = `app.bsky.graph.getListBlocks?limit=${limit}`;
  if (cursor) {
    endpoint += `&cursor=${encodeURIComponent(cursor)}`;
  }
  const response = await apiRequest(endpoint, "GET", null, session.pdsUrl);
  return response || { lists: [] };
}
async function getAllListBlocks(onProgress) {
  const allLists = [];
  let cursor;
  do {
    const response = await getListBlocks(cursor);
    allLists.push(...response.lists);
    cursor = response.cursor;
    onProgress?.(allLists.length);
    if (cursor) {
      await sleep(PAGINATION_DELAY);
    }
  } while (cursor);
  console.log("[ErgoBlock] Fetched all subscribed blocklists:", allLists.length);
  return allLists;
}
async function getListMutes(cursor, limit = 100) {
  const session = getSession();
  if (!session) throw new Error("Not logged in");
  let endpoint = `app.bsky.graph.getListMutes?limit=${limit}`;
  if (cursor) {
    endpoint += `&cursor=${encodeURIComponent(cursor)}`;
  }
  const response = await apiRequest(endpoint, "GET", null, session.pdsUrl);
  return response || { lists: [] };
}
async function getAllListMutes(onProgress) {
  const allLists = [];
  let cursor;
  do {
    const response = await getListMutes(cursor);
    allLists.push(...response.lists);
    cursor = response.cursor;
    onProgress?.(allLists.length);
    if (cursor) {
      await sleep(PAGINATION_DELAY);
    }
  } while (cursor);
  console.log("[ErgoBlock] Fetched all subscribed mutelists:", allLists.length);
  return allLists;
}
async function getList(listUri, cursor, limit = 100) {
  let endpoint = `app.bsky.graph.getList?list=${encodeURIComponent(listUri)}&limit=${limit}`;
  if (cursor) {
    endpoint += `&cursor=${encodeURIComponent(cursor)}`;
  }
  const response = await apiRequest(endpoint);
  return response || { list: {}, items: [] };
}
async function getAllListMembers(listUri, onProgress) {
  const allMembers = [];
  let cursor;
  do {
    const response = await getList(listUri, cursor);
    for (const item of response.items) {
      allMembers.push(item.subject);
    }
    cursor = response.cursor;
    onProgress?.(allMembers.length);
    if (cursor) {
      await sleep(PAGINATION_DELAY);
    }
  } while (cursor);
  console.log("[ErgoBlock] Fetched all list members for", listUri, ":", allMembers.length);
  return allMembers;
}
async function getLists(actor, cursor, limit = 100) {
  let endpoint = `app.bsky.graph.getLists?actor=${encodeURIComponent(actor)}&limit=${limit}`;
  if (cursor) {
    endpoint += `&cursor=${encodeURIComponent(cursor)}`;
  }
  const response = await apiRequest(endpoint);
  return response || { lists: [] };
}
async function getActorLists(actor) {
  const allLists = [];
  let cursor;
  do {
    const response = await getLists(actor, cursor);
    for (const list of response.lists) {
      if (list.creator.did === actor) {
        allLists.push({
          uri: list.uri,
          name: list.name,
          purpose: list.purpose === "app.bsky.graph.defs#modlist" ? "modlist" : "curatelist",
          description: list.description,
          avatar: list.avatar,
          listItemCount: list.listItemCount || 0,
          createdAt: new Date(list.indexedAt).getTime()
        });
      }
    }
    cursor = response.cursor;
    if (cursor) {
      await sleep(PAGINATION_DELAY);
    }
  } while (cursor);
  console.log("[ErgoBlock] Fetched all owned lists for", actor, ":", allLists.length);
  return allLists;
}
async function unsubscribeFromBlocklist(listUri) {
  const session = getSession();
  if (!session) throw new Error("Not logged in");
  let cursor;
  let foundRkey = null;
  do {
    let endpoint = `com.atproto.repo.listRecords?repo=${session.did}&collection=app.bsky.graph.listblock&limit=100`;
    if (cursor) {
      endpoint += `&cursor=${encodeURIComponent(cursor)}`;
    }
    const response = await apiRequest(endpoint);
    const record = response?.records?.find((r) => r.value.subject === listUri);
    if (record) {
      foundRkey = extractRkeyFromUri(record.uri);
      break;
    }
    cursor = response?.cursor;
    if (cursor) {
      await sleep(100);
    }
  } while (cursor);
  if (!foundRkey) {
    logger.info("No listblock record found for list");
    return;
  }
  await apiRequest("com.atproto.repo.deleteRecord", "POST", {
    repo: session.did,
    collection: "app.bsky.graph.listblock",
    rkey: foundRkey
  });
  logger.info("Unsubscribed from blocklist");
}
async function getFollowRecords(limit = 100, cursor) {
  const session = getSession();
  if (!session) throw new Error("Not logged in");
  let endpoint = `com.atproto.repo.listRecords?repo=${encodeURIComponent(session.did)}&collection=app.bsky.graph.follow&limit=${limit}`;
  if (cursor) {
    endpoint += `&cursor=${encodeURIComponent(cursor)}`;
  }
  const response = await apiRequest(endpoint);
  return response || { records: [] };
}
async function getAllFollowRecords(onProgress) {
  const allRecords = [];
  let cursor;
  do {
    const response = await getFollowRecords(100, cursor);
    allRecords.push(...response.records);
    cursor = response.cursor;
    onProgress?.(allRecords.length);
    if (cursor) {
      await new Promise((resolve) => setTimeout(resolve, 100));
    }
  } while (cursor);
  console.log("[ErgoBlock] Fetched all follow records:", allRecords.length);
  return allRecords;
}
async function followUser(did) {
  const session = getSession();
  if (!session) throw new Error("Not logged in");
  const record = {
    $type: "app.bsky.graph.follow",
    subject: did,
    createdAt: (/* @__PURE__ */ new Date()).toISOString()
  };
  return apiRequest("com.atproto.repo.createRecord", "POST", {
    repo: session.did,
    collection: "app.bsky.graph.follow",
    record
  });
}
async function unfollowUser(did, rkey) {
  const session = getSession();
  if (!session) throw new Error("Not logged in");
  if (rkey) {
    await apiRequest("com.atproto.repo.deleteRecord", "POST", {
      repo: session.did,
      collection: "app.bsky.graph.follow",
      rkey
    });
    console.log("[ErgoBlock] Unfollowed user:", did);
    return;
  }
  const records = await apiRequest(
    `com.atproto.repo.listRecords?repo=${encodeURIComponent(session.did)}&collection=app.bsky.graph.follow&limit=100`
  );
  let foundRkey;
  let cursor = records?.cursor;
  for (const record of records?.records || []) {
    if (record.value.subject === did) {
      foundRkey = record.uri.split("/").pop();
      break;
    }
  }
  while (!foundRkey && cursor) {
    const moreRecords = await apiRequest(
      `com.atproto.repo.listRecords?repo=${encodeURIComponent(session.did)}&collection=app.bsky.graph.follow&limit=100&cursor=${encodeURIComponent(cursor)}`
    );
    for (const record of moreRecords?.records || []) {
      if (record.value.subject === did) {
        foundRkey = record.uri.split("/").pop();
        break;
      }
    }
    cursor = moreRecords?.cursor;
  }
  if (!foundRkey) {
    console.log("[ErgoBlock] No follow record found for:", did);
    return;
  }
  await apiRequest("com.atproto.repo.deleteRecord", "POST", {
    repo: session.did,
    collection: "app.bsky.graph.follow",
    rkey: foundRkey
  });
  console.log("[ErgoBlock] Unfollowed user:", did);
}
async function getNotifications(limit = 50, cursor) {
  const session = getSession();
  if (!session) throw new Error("Not logged in");
  let endpoint = `app.bsky.notification.listNotifications?limit=${limit}`;
  if (cursor) {
    endpoint += `&cursor=${encodeURIComponent(cursor)}`;
  }
  const response = await apiRequest(endpoint);
  return response || { notifications: [] };
}
async function getActorLikes(actor, limit = 50, cursor) {
  let endpoint = `app.bsky.feed.getActorLikes?actor=${encodeURIComponent(actor)}&limit=${limit}`;
  if (cursor) {
    endpoint += `&cursor=${encodeURIComponent(cursor)}`;
  }
  const response = await apiRequest(endpoint);
  return response || { feed: [] };
}
export {
  blockUser,
  executeApiRequest,
  findRecentInteraction,
  followUser,
  getActorLikes,
  getActorLists,
  getAllBlockRecords,
  getAllBlocks,
  getAllFollowRecords,
  getAllFollowers,
  getAllFollows,
  getAllListBlocks,
  getAllListMembers,
  getAllListMutes,
  getAllMutes,
  getAuthorFeed,
  getBlockRecords,
  getBlocks,
  getFollowRecords,
  getFollowers,
  getFollows,
  getList,
  getListBlocks,
  getListMutes,
  getLists,
  getMutes,
  getNotifications,
  getProfile,
  getProfiles,
  getProfilesBatched,
  getSession,
  muteUser,
  unblockUser,
  unfollowUser,
  unmuteUser,
  unsubscribeFromBlocklist
};
